<?php 
/**
* 
*/
class Mregister extends CI_Model
{
	
	public function register()
	{


		$this->load->library('form_validation');
		$this->form_validation->set_rules('$usuario', 'U', 'reqired|is_unique');
		$this->form_validation->set_rules('$contraseña', 'C', 'min_length(8)|required');
		$this->form_validation->set_rules('$correo', 'Email', 'required|valid_email');

		$name = $this->input->post('name');
		$username = $this->input->post('username');
		$pass = $this->input->post('pass');

		if ($name != NULL && $username != NULL && $pass != NULL) {
			echo("Exito");
		}
		

	}

	public function insert_users($data_array)
	{
		$this->db->set('name', $data_array["name"]);
		$this->db->set('username', $data_array['username']);
		$this->db->set('password', $data_array['password']);
		$this->db->set('email', $data_array['email']);
		$this->db->insert('Users');

		#$sql = $this->db->query('select * from Users where name = '."$data_array['name']");
		
		

		if ($this->db->get_where('Users', 'name ='.$data_array['name'])) {
			return TRUE;
		}
		else
		{
			return FALSE;
		}

	}

	public function user_activated()
	{
		return TRUE;
	}



	
}
 ?>