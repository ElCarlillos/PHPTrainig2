<?php 
$conn= $db['password'];
?>