<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-27 10:23:58 --> Config Class Initialized
INFO - 2016-06-27 10:23:58 --> Hooks Class Initialized
DEBUG - 2016-06-27 10:23:58 --> UTF-8 Support Enabled
INFO - 2016-06-27 10:23:58 --> Utf8 Class Initialized
INFO - 2016-06-27 10:23:58 --> URI Class Initialized
INFO - 2016-06-27 10:23:58 --> Router Class Initialized
INFO - 2016-06-27 10:23:58 --> Output Class Initialized
INFO - 2016-06-27 10:23:58 --> Security Class Initialized
DEBUG - 2016-06-27 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-27 10:23:58 --> Input Class Initialized
INFO - 2016-06-27 10:23:58 --> Language Class Initialized
INFO - 2016-06-27 10:23:58 --> Loader Class Initialized
INFO - 2016-06-27 10:23:58 --> Helper loaded: html_helper
INFO - 2016-06-27 10:23:58 --> Helper loaded: url_helper
INFO - 2016-06-27 10:23:58 --> Helper loaded: form_helper
INFO - 2016-06-27 10:23:58 --> Helper loaded: email_helper
INFO - 2016-06-27 10:23:58 --> Helper loaded: text_helper
INFO - 2016-06-27 10:23:58 --> Database Driver Class Initialized
INFO - 2016-06-27 10:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-27 10:23:58 --> Form Validation Class Initialized
INFO - 2016-06-27 10:23:58 --> Model Class Initialized
INFO - 2016-06-27 10:23:58 --> Controller Class Initialized
DEBUG - 2016-06-27 10:23:58 --> hola
DEBUG - 2016-06-27 10:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-06-27 10:23:58 --> File loaded: /var/www/html/Blog/application/views/Project/Login view.php
INFO - 2016-06-27 10:23:58 --> Final output sent to browser
DEBUG - 2016-06-27 10:23:58 --> Total execution time: 0.0097
INFO - 2016-06-27 10:23:58 --> Config Class Initialized
INFO - 2016-06-27 10:23:58 --> Hooks Class Initialized
DEBUG - 2016-06-27 10:23:58 --> UTF-8 Support Enabled
INFO - 2016-06-27 10:23:58 --> Utf8 Class Initialized
INFO - 2016-06-27 10:23:58 --> URI Class Initialized
INFO - 2016-06-27 10:23:58 --> Router Class Initialized
INFO - 2016-06-27 10:23:58 --> Output Class Initialized
INFO - 2016-06-27 10:23:58 --> Security Class Initialized
DEBUG - 2016-06-27 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-27 10:23:58 --> Input Class Initialized
INFO - 2016-06-27 10:23:58 --> Language Class Initialized
ERROR - 2016-06-27 10:23:58 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-27 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:25:43 --> hola
DEBUG - 2016-06-27 10:25:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 10:25:43 --> Total execution time: 0.0093
DEBUG - 2016-06-27 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 10:25:44 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-27 10:25:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:25:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 10:25:51 --> Total execution time: 0.0044
DEBUG - 2016-06-27 10:26:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:26:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 10:26:41 --> Severity: Error --> Call to undefined method MY_Form_validation::validation_errors() /var/www/html/Blog/application/controllers/Project/Clogin.php 25
DEBUG - 2016-06-27 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 10:31:38 --> Total execution time: 0.0101
DEBUG - 2016-06-27 10:37:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:37:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 10:37:28 --> Total execution time: 0.0063
DEBUG - 2016-06-27 10:37:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 10:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 10:37:29 --> hola
DEBUG - 2016-06-27 10:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 10:37:29 --> Total execution time: 0.0053
DEBUG - 2016-06-27 11:00:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 11:00:11 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/html/Blog/application/controllers/Project/Clogin.php 28
DEBUG - 2016-06-27 11:01:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:01:09 --> hola
DEBUG - 2016-06-27 11:01:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:01:09 --> Total execution time: 0.0070
DEBUG - 2016-06-27 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:01:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:01:20 --> Total execution time: 0.0143
DEBUG - 2016-06-27 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:01:23 --> hola
DEBUG - 2016-06-27 11:01:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:01:23 --> Total execution time: 0.0053
DEBUG - 2016-06-27 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:03:45 --> hola
DEBUG - 2016-06-27 11:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:03:45 --> Total execution time: 0.0088
DEBUG - 2016-06-27 11:03:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 11:03:53 --> 404 Page Not Found: Project/Login2/index
DEBUG - 2016-06-27 11:03:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:03:59 --> hola
DEBUG - 2016-06-27 11:03:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:03:59 --> Total execution time: 0.0033
DEBUG - 2016-06-27 11:04:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:04:08 --> Total execution time: 0.0041
DEBUG - 2016-06-27 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:10 --> hola
DEBUG - 2016-06-27 11:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:04:10 --> Total execution time: 0.0032
DEBUG - 2016-06-27 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 11:04:15 --> Severity: Notice --> Undefined variable: error /var/www/html/Blog/application/controllers/Project/Clogin.php 29
DEBUG - 2016-06-27 11:04:15 --> Total execution time: 0.0037
DEBUG - 2016-06-27 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:04:39 --> Total execution time: 0.0040
DEBUG - 2016-06-27 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:04:52 --> Total execution time: 0.0043
DEBUG - 2016-06-27 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:04:53 --> hola
DEBUG - 2016-06-27 11:04:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:04:53 --> Total execution time: 0.0034
DEBUG - 2016-06-27 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:05:33 --> hola
DEBUG - 2016-06-27 11:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:05:33 --> Total execution time: 0.0033
DEBUG - 2016-06-27 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:05:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:05:40 --> Total execution time: 0.0034
DEBUG - 2016-06-27 11:05:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:05:41 --> hola
DEBUG - 2016-06-27 11:05:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:05:41 --> Total execution time: 0.0032
DEBUG - 2016-06-27 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:06:11 --> hola
DEBUG - 2016-06-27 11:06:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:06:11 --> Total execution time: 0.0038
DEBUG - 2016-06-27 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:06:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:06:17 --> Total execution time: 0.0036
DEBUG - 2016-06-27 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:06:18 --> hola
DEBUG - 2016-06-27 11:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:06:18 --> Total execution time: 0.0040
DEBUG - 2016-06-27 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:06:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:06:31 --> Total execution time: 0.0040
DEBUG - 2016-06-27 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:07:00 --> hola
DEBUG - 2016-06-27 11:07:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:07:00 --> Total execution time: 0.0039
DEBUG - 2016-06-27 11:07:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:07:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:07:06 --> Total execution time: 0.0035
DEBUG - 2016-06-27 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:07:08 --> hola
DEBUG - 2016-06-27 11:07:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:07:08 --> Total execution time: 0.0032
DEBUG - 2016-06-27 11:09:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:09:00 --> hola
DEBUG - 2016-06-27 11:09:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:09:00 --> Total execution time: 0.0038
DEBUG - 2016-06-27 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:09:09 --> Total execution time: 0.0035
DEBUG - 2016-06-27 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:09:23 --> hola
DEBUG - 2016-06-27 11:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:09:23 --> Total execution time: 0.0036
DEBUG - 2016-06-27 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:09:29 --> Total execution time: 0.0034
DEBUG - 2016-06-27 11:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:09:30 --> hola
DEBUG - 2016-06-27 11:09:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:09:30 --> Total execution time: 0.0032
DEBUG - 2016-06-27 11:10:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:10:14 --> hola
DEBUG - 2016-06-27 11:10:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:10:14 --> Total execution time: 0.0035
DEBUG - 2016-06-27 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:10:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:10:19 --> Total execution time: 0.0046
DEBUG - 2016-06-27 11:10:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:10:57 --> hola
DEBUG - 2016-06-27 11:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:10:57 --> Total execution time: 0.0033
DEBUG - 2016-06-27 11:11:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:11:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:11:02 --> Total execution time: 0.0039
DEBUG - 2016-06-27 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 11:11:04 --> hola
DEBUG - 2016-06-27 11:11:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 11:11:04 --> Total execution time: 0.0031
DEBUG - 2016-06-27 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:26:29 --> hola
DEBUG - 2016-06-27 12:26:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:26:29 --> Total execution time: 0.0087
DEBUG - 2016-06-27 12:26:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:26:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:26:33 --> Total execution time: 0.0054
DEBUG - 2016-06-27 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:26:35 --> hola
DEBUG - 2016-06-27 12:26:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:26:35 --> Total execution time: 0.0085
DEBUG - 2016-06-27 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:28:58 --> hola
DEBUG - 2016-06-27 12:28:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:28:58 --> Total execution time: 0.0061
DEBUG - 2016-06-27 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:29:04 --> Total execution time: 0.0062
DEBUG - 2016-06-27 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:29:05 --> hola
DEBUG - 2016-06-27 12:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:29:05 --> Total execution time: 0.0032
DEBUG - 2016-06-27 12:31:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:31:25 --> hola
DEBUG - 2016-06-27 12:31:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:31:25 --> Total execution time: 0.0058
DEBUG - 2016-06-27 12:31:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:31:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 12:31:30 --> Severity: Error --> Call to undefined function not_empty() /var/www/html/Blog/application/controllers/Project/Clogin.php 34
DEBUG - 2016-06-27 12:32:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:32:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 12:32:13 --> Severity: Error --> Call to undefined function not_empty() /var/www/html/Blog/application/controllers/Project/Clogin.php 46
DEBUG - 2016-06-27 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:33:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 12:33:06 --> Severity: Error --> Call to undefined function callback_not_empty() /var/www/html/Blog/application/controllers/Project/Clogin.php 46
DEBUG - 2016-06-27 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:35:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:35:16 --> Total execution time: 0.0081
DEBUG - 2016-06-27 12:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:35:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:35:29 --> Total execution time: 0.0073
DEBUG - 2016-06-27 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:36:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:36:24 --> Total execution time: 0.0059
DEBUG - 2016-06-27 12:37:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:37:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:37:03 --> Total execution time: 0.0060
DEBUG - 2016-06-27 12:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:37:17 --> Total execution time: 0.0043
DEBUG - 2016-06-27 12:38:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:38:11 --> Total execution time: 0.0039
DEBUG - 2016-06-27 12:38:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 12:38:45 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/Blog/application/models/Project/MLogin.php 32
DEBUG - 2016-06-27 12:40:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:40:07 --> Total execution time: 0.0052
DEBUG - 2016-06-27 12:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:41:35 --> hola
DEBUG - 2016-06-27 12:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:41:35 --> Total execution time: 0.0066
DEBUG - 2016-06-27 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:41:36 --> hola
DEBUG - 2016-06-27 12:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:41:36 --> Total execution time: 0.0096
DEBUG - 2016-06-27 12:42:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:42:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:42:28 --> Total execution time: 0.0080
DEBUG - 2016-06-27 12:44:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:44:17 --> hola
DEBUG - 2016-06-27 12:44:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:44:17 --> Total execution time: 0.0078
DEBUG - 2016-06-27 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:44:18 --> hola
DEBUG - 2016-06-27 12:44:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:44:18 --> Total execution time: 0.0057
DEBUG - 2016-06-27 12:46:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:46:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:46:39 --> Total execution time: 0.0062
DEBUG - 2016-06-27 12:47:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:47:11 --> hola
DEBUG - 2016-06-27 12:47:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:47:12 --> Total execution time: 0.0070
DEBUG - 2016-06-27 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:47:13 --> hola
DEBUG - 2016-06-27 12:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:47:13 --> Total execution time: 0.0034
DEBUG - 2016-06-27 12:47:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 12:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 12:47:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 12:47:19 --> Total execution time: 0.0036
DEBUG - 2016-06-27 13:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:17:35 --> hola
DEBUG - 2016-06-27 13:17:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:17:35 --> Total execution time: 0.0059
DEBUG - 2016-06-27 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:18:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:18:04 --> Total execution time: 0.0034
DEBUG - 2016-06-27 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:18:08 --> hola
DEBUG - 2016-06-27 13:18:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:18:08 --> Total execution time: 0.0066
DEBUG - 2016-06-27 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:20:55 --> hola
DEBUG - 2016-06-27 13:20:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:20:55 --> Total execution time: 0.0096
DEBUG - 2016-06-27 13:21:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:21:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 13:21:09 --> Severity: Error --> Call to undefined function ms_strlen() /var/www/html/Blog/application/models/Project/MLogin.php 47
DEBUG - 2016-06-27 13:21:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:21:41 --> Total execution time: 0.0039
DEBUG - 2016-06-27 13:25:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:25:06 --> hola
DEBUG - 2016-06-27 13:25:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:25:06 --> Total execution time: 0.0063
DEBUG - 2016-06-27 13:32:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:32:56 --> hola
DEBUG - 2016-06-27 13:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:32:56 --> Total execution time: 0.0066
DEBUG - 2016-06-27 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:33:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 13:33:05 --> Severity: Notice --> Undefined variable: object /var/www/html/Blog/application/controllers/Project/Clogin.php 39
ERROR - 2016-06-27 13:33:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/Clogin.php 39
DEBUG - 2016-06-27 13:33:05 --> Total execution time: 0.0101
DEBUG - 2016-06-27 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:35:39 --> Total execution time: 0.0049
DEBUG - 2016-06-27 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:35:51 --> Total execution time: 0.0038
DEBUG - 2016-06-27 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:35:59 --> hola
DEBUG - 2016-06-27 13:35:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:35:59 --> Total execution time: 0.0066
DEBUG - 2016-06-27 13:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:36:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:36:05 --> Total execution time: 0.0056
DEBUG - 2016-06-27 13:36:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:36:07 --> hola
DEBUG - 2016-06-27 13:36:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:36:07 --> Total execution time: 0.0053
DEBUG - 2016-06-27 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:36:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:36:11 --> Total execution time: 0.0065
DEBUG - 2016-06-27 13:41:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:41:02 --> hola
DEBUG - 2016-06-27 13:41:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:41:02 --> Total execution time: 0.0062
DEBUG - 2016-06-27 13:41:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:41:03 --> hola
DEBUG - 2016-06-27 13:41:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:41:03 --> Total execution time: 0.0049
DEBUG - 2016-06-27 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:41:11 --> Total execution time: 0.0059
DEBUG - 2016-06-27 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:53:48 --> hola
DEBUG - 2016-06-27 13:53:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:53:48 --> Total execution time: 0.0049
DEBUG - 2016-06-27 13:54:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:54:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:54:04 --> Total execution time: 0.0060
DEBUG - 2016-06-27 13:54:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:54:07 --> hola
DEBUG - 2016-06-27 13:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:54:07 --> Total execution time: 0.0075
DEBUG - 2016-06-27 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:58:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 13:58:16 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/models/Project/MLogin.php 50
DEBUG - 2016-06-27 13:58:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:58:43 --> hola
DEBUG - 2016-06-27 13:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:58:43 --> Total execution time: 0.0075
DEBUG - 2016-06-27 13:59:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:59:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 13:59:04 --> Severity: Notice --> Undefined variable: number /var/www/html/Blog/application/models/Project/MLogin.php 50
DEBUG - 2016-06-27 13:59:04 --> Total execution time: 0.0066
DEBUG - 2016-06-27 13:59:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 13:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 13:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 13:59:39 --> Total execution time: 0.0039
DEBUG - 2016-06-27 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:00:03 --> hola
DEBUG - 2016-06-27 14:00:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:00:03 --> Total execution time: 0.0033
DEBUG - 2016-06-27 14:00:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:00:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:00:10 --> Total execution time: 0.0062
DEBUG - 2016-06-27 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:00:45 --> Total execution time: 0.0041
DEBUG - 2016-06-27 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 14:01:56 --> Severity: Parsing Error --> syntax error, unexpected ''campo'' (T_CONSTANT_ENCAPSED_STRING), expecting '&' or variable (T_VARIABLE) /var/www/html/Blog/application/models/Project/MLogin.php 27
DEBUG - 2016-06-27 14:10:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:10:37 --> hola
DEBUG - 2016-06-27 14:10:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:10:37 --> Total execution time: 0.0080
DEBUG - 2016-06-27 14:10:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:10:39 --> hola
DEBUG - 2016-06-27 14:10:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:10:39 --> Total execution time: 0.0033
DEBUG - 2016-06-27 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:10:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:10:46 --> Severity: Error --> Call to undefined method MLogin::not_empty() /var/www/html/Blog/application/controllers/Project/Clogin.php 37
DEBUG - 2016-06-27 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:11:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:11:15 --> Severity: Error --> Call to undefined function return_name_as_string() /var/www/html/Blog/application/models/Project/MLogin.php 47
DEBUG - 2016-06-27 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:11:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:11:44 --> Severity: Error --> Call to undefined function return_name_as_string() /var/www/html/Blog/application/models/Project/MLogin.php 53
DEBUG - 2016-06-27 14:13:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:13:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:13:08 --> Severity: Error --> Call to undefined function return_name_as_string() /var/www/html/Blog/application/models/Project/MLogin.php 53
DEBUG - 2016-06-27 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:13:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:13:43 --> Severity: Error --> Call to undefined function check_length() /var/www/html/Blog/application/models/Project/MLogin.php 55
DEBUG - 2016-06-27 14:13:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:13:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:13:53 --> Total execution time: 0.0041
DEBUG - 2016-06-27 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:14:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:14:33 --> Total execution time: 0.0044
DEBUG - 2016-06-27 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:14:41 --> hola
DEBUG - 2016-06-27 14:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:14:41 --> Total execution time: 0.0045
DEBUG - 2016-06-27 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:15:04 --> hola
DEBUG - 2016-06-27 14:15:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:15:04 --> Total execution time: 0.0064
DEBUG - 2016-06-27 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:15:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:15:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
ERROR - 2016-06-27 14:15:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
DEBUG - 2016-06-27 14:15:12 --> Total execution time: 0.0078
DEBUG - 2016-06-27 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:19:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:19:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
ERROR - 2016-06-27 14:19:10 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
DEBUG - 2016-06-27 14:19:10 --> Total execution time: 0.0053
DEBUG - 2016-06-27 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:19:12 --> hola
DEBUG - 2016-06-27 14:19:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:19:12 --> Total execution time: 0.0033
DEBUG - 2016-06-27 14:20:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:20:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:20:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
ERROR - 2016-06-27 14:20:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/models/Project/MLogin.php 48
DEBUG - 2016-06-27 14:20:41 --> Total execution time: 0.0056
DEBUG - 2016-06-27 14:21:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:21:06 --> Severity: Notice --> Undefined variable: var /var/www/html/Blog/application/models/Project/MLogin.php 56
ERROR - 2016-06-27 14:21:06 --> Severity: Notice --> Undefined variable: var /var/www/html/Blog/application/models/Project/MLogin.php 58
DEBUG - 2016-06-27 14:21:06 --> Total execution time: 0.0044
DEBUG - 2016-06-27 14:21:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 14:21:18 --> Severity: Notice --> Undefined variable: var /var/www/html/Blog/application/models/Project/MLogin.php 58
DEBUG - 2016-06-27 14:21:18 --> Total execution time: 0.0044
DEBUG - 2016-06-27 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:21:29 --> Total execution time: 0.0040
DEBUG - 2016-06-27 14:21:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:44 --> hola
DEBUG - 2016-06-27 14:21:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:21:44 --> Total execution time: 0.0061
DEBUG - 2016-06-27 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:21:48 --> Total execution time: 0.0054
DEBUG - 2016-06-27 14:21:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:21:52 --> hola
DEBUG - 2016-06-27 14:21:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:21:52 --> Total execution time: 0.0061
DEBUG - 2016-06-27 14:25:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:25:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:25:02 --> Total execution time: 0.0060
DEBUG - 2016-06-27 14:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:25:03 --> hola
DEBUG - 2016-06-27 14:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:25:03 --> Total execution time: 0.0036
DEBUG - 2016-06-27 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:28:20 --> Total execution time: 0.0061
DEBUG - 2016-06-27 14:28:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:28:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:28:28 --> Total execution time: 0.0046
DEBUG - 2016-06-27 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:28:30 --> Total execution time: 0.0033
DEBUG - 2016-06-27 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:28:55 --> Total execution time: 0.0035
DEBUG - 2016-06-27 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:28:59 --> hola
DEBUG - 2016-06-27 14:28:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:28:59 --> Total execution time: 0.0046
DEBUG - 2016-06-27 14:29:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:29:03 --> Total execution time: 0.0055
DEBUG - 2016-06-27 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:29:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:29:13 --> Total execution time: 0.0039
DEBUG - 2016-06-27 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:29:15 --> Total execution time: 0.0055
DEBUG - 2016-06-27 14:30:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:11 --> Total execution time: 0.0062
DEBUG - 2016-06-27 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:30:23 --> Total execution time: 0.0040
DEBUG - 2016-06-27 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:23 --> Total execution time: 0.0062
DEBUG - 2016-06-27 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:33 --> Total execution time: 0.0035
DEBUG - 2016-06-27 14:30:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:30:39 --> Total execution time: 0.0035
DEBUG - 2016-06-27 14:30:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:30:41 --> Total execution time: 0.0057
DEBUG - 2016-06-27 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 14:31:51 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 28
DEBUG - 2016-06-27 14:32:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 14:32:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 28
DEBUG - 2016-06-27 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:32:35 --> hola
DEBUG - 2016-06-27 14:32:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:32:35 --> Total execution time: 0.0042
DEBUG - 2016-06-27 14:32:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 14:32:42 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 28
DEBUG - 2016-06-27 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:33:04 --> Total execution time: 0.0044
DEBUG - 2016-06-27 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:33:16 --> Total execution time: 0.0069
DEBUG - 2016-06-27 14:43:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:43:57 --> Total execution time: 0.0057
DEBUG - 2016-06-27 14:44:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:44:12 --> Total execution time: 0.0069
DEBUG - 2016-06-27 14:45:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 14:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 14:45:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 14:45:07 --> Total execution time: 0.0046
DEBUG - 2016-06-27 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:11:38 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:12:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:12:10 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:12:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:12:23 --> Total execution time: 0.0051
DEBUG - 2016-06-27 15:12:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:12:42 --> Total execution time: 0.0041
DEBUG - 2016-06-27 15:13:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:13:58 --> Total execution time: 0.0038
DEBUG - 2016-06-27 15:14:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:14:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:14:23 --> Total execution time: 0.0040
DEBUG - 2016-06-27 15:14:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:14:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:14:24 --> Total execution time: 0.0033
DEBUG - 2016-06-27 15:14:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:14:26 --> 404 Page Not Found: CRegister/register
DEBUG - 2016-06-27 15:14:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:14:41 --> Total execution time: 0.0035
DEBUG - 2016-06-27 15:14:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:14:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:14:52 --> Total execution time: 0.0037
DEBUG - 2016-06-27 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:14:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:14:55 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:14:55 --> Total execution time: 0.0048
DEBUG - 2016-06-27 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:14:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:14:55 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:15:39 --> Total execution time: 0.0042
DEBUG - 2016-06-27 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:15:40 --> Total execution time: 0.0039
DEBUG - 2016-06-27 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:15:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:15:42 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:15:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:15:53 --> Total execution time: 0.0036
DEBUG - 2016-06-27 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:15:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:15:58 --> Total execution time: 0.0040
DEBUG - 2016-06-27 15:16:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:16:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:16:00 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:16:00 --> Total execution time: 0.0050
DEBUG - 2016-06-27 15:16:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:16:00 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:16:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:16:00 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:17:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:17:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:17:08 --> Total execution time: 0.0035
DEBUG - 2016-06-27 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:17:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:17:14 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:17:14 --> Total execution time: 0.0049
DEBUG - 2016-06-27 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:17:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:17:14 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:20:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:20:39 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:20:39 --> Total execution time: 0.0042
DEBUG - 2016-06-27 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:20:39 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:20:39 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:20:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:20:50 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:20:50 --> Total execution time: 0.0043
DEBUG - 2016-06-27 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:20:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:20:50 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:23:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:23:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:23:49 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:23:49 --> Total execution time: 0.0048
DEBUG - 2016-06-27 15:23:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:23:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:23:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:23:50 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:23:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:23:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:23:52 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:23:52 --> Total execution time: 0.0042
DEBUG - 2016-06-27 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:23:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:23:53 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:24:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:24:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:24:03 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:24:03 --> Total execution time: 0.0043
DEBUG - 2016-06-27 15:24:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:24:03 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:24:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:24:03 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:27:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:27:28 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:27:28 --> Total execution time: 0.0048
DEBUG - 2016-06-27 15:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:27:28 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:27:28 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:27:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 15:27:31 --> Severity: Notice --> Undefined variable: title /var/www/html/Blog/application/views/template/header.php 8
DEBUG - 2016-06-27 15:27:31 --> Total execution time: 0.0043
DEBUG - 2016-06-27 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:27:31 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:27:31 --> 404 Page Not Found: Assets/js
DEBUG - 2016-06-27 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:33:21 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:36:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:36:07 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:36:16 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:36:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:36:56 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:37:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:37:54 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:38:54 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:39:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:39:12 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:48:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 15:48:22 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 15:49:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:49:15 --> Total execution time: 0.0038
DEBUG - 2016-06-27 15:49:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:49:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:49:48 --> Total execution time: 0.0042
DEBUG - 2016-06-27 15:49:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:49:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:49:55 --> Total execution time: 0.0041
DEBUG - 2016-06-27 15:52:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:52:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:52:17 --> Total execution time: 0.0042
DEBUG - 2016-06-27 15:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:53:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:53:02 --> Total execution time: 0.0038
DEBUG - 2016-06-27 15:53:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 15:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 15:53:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 15:53:12 --> Total execution time: 0.0039
DEBUG - 2016-06-27 16:02:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:02:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:02:31 --> Severity: Error --> Call to undefined function pass_not_empty() /var/www/html/Blog/application/controllers/Project/CRegister.php 99
DEBUG - 2016-06-27 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:05:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:05:19 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:05:19 --> Total execution time: 0.0042
DEBUG - 2016-06-27 16:05:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:05:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:05:51 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:05:51 --> Total execution time: 0.0044
DEBUG - 2016-06-27 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:06:07 --> Total execution time: 0.0039
DEBUG - 2016-06-27 16:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:06:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:06:16 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:06:16 --> Total execution time: 0.0043
DEBUG - 2016-06-27 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:07:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:07:11 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:07:11 --> Total execution time: 0.0046
DEBUG - 2016-06-27 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:08:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:08:26 --> Severity: Error --> Call to undefined method Mregister::pass_not_empty() /var/www/html/Blog/application/controllers/Project/CRegister.php 47
DEBUG - 2016-06-27 16:09:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:09:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:09:54 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 51
DEBUG - 2016-06-27 16:09:54 --> Total execution time: 0.0043
DEBUG - 2016-06-27 16:11:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:11:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:11:38 --> Total execution time: 0.0044
DEBUG - 2016-06-27 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:12:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:12:04 --> Total execution time: 0.0037
DEBUG - 2016-06-27 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:12:47 --> 404 Page Not Found: Project/CRegister/CRegister
DEBUG - 2016-06-27 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:12:47 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:12:47 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 16:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:12:47 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 16:12:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:12:47 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-27 16:13:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:13:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:13:04 --> Total execution time: 0.0038
DEBUG - 2016-06-27 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:13:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:13:26 --> Total execution time: 0.0039
DEBUG - 2016-06-27 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:13:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:13:45 --> Total execution time: 0.0074
DEBUG - 2016-06-27 16:22:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:22:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/Blog/application/controllers/Project/CRegister.php 49
DEBUG - 2016-06-27 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:23:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:23:30 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/Blog/application/controllers/Project/CRegister.php 49
DEBUG - 2016-06-27 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:23:47 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:23:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:23:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:23:59 --> Severity: Error --> Call to undefined method CI_Output::append_ouput() /var/www/html/Blog/application/views/Tuto/register.php 72
DEBUG - 2016-06-27 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:24:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:24:55 --> Severity: Error --> Call to undefined method CI_Output::set_ouput() /var/www/html/Blog/application/views/Tuto/register.php 72
DEBUG - 2016-06-27 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:25:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:25:55 --> Severity: Error --> Call to undefined method CI_Output::set_ouput() /var/www/html/Blog/application/views/Tuto/register.php 72
DEBUG - 2016-06-27 16:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:26:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:26:08 --> Total execution time: 0.0038
DEBUG - 2016-06-27 16:26:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:26:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-27 16:26:20 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/views/Tuto/register.php 72
DEBUG - 2016-06-27 16:26:20 --> Total execution time: 0.0044
DEBUG - 2016-06-27 16:26:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:26:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:26:32 --> Total execution time: 0.0040
DEBUG - 2016-06-27 16:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:27:01 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:27:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:27:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 50
DEBUG - 2016-06-27 16:27:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:27:22 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 51
DEBUG - 2016-06-27 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:27:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:27:34 --> Total execution time: 0.0039
DEBUG - 2016-06-27 16:27:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:27:38 --> Total execution time: 0.0040
DEBUG - 2016-06-27 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:27:45 --> Total execution time: 0.0048
DEBUG - 2016-06-27 16:28:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:28:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:28:05 --> Total execution time: 0.0036
DEBUG - 2016-06-27 16:43:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:43:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 60
DEBUG - 2016-06-27 16:43:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 16:43:10 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 60
DEBUG - 2016-06-27 16:43:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:43:18 --> Total execution time: 0.0048
DEBUG - 2016-06-27 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:43:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:43:36 --> Total execution time: 0.0072
DEBUG - 2016-06-27 16:45:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:45:57 --> Total execution time: 0.0058
DEBUG - 2016-06-27 16:49:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:49:20 --> Total execution time: 0.0040
DEBUG - 2016-06-27 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:49:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:49:29 --> Total execution time: 0.0066
DEBUG - 2016-06-27 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:50:02 --> Total execution time: 0.0049
DEBUG - 2016-06-27 16:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:53:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:53:02 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:53:02 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:53:02 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:53:02 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:53:02 --> Total execution time: 0.0069
DEBUG - 2016-06-27 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:53:33 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:53:33 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:53:33 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:53:33 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:53:33 --> Total execution time: 0.0121
DEBUG - 2016-06-27 16:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:53:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:53:56 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:53:56 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:53:56 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:53:56 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:53:56 --> Total execution time: 0.0064
DEBUG - 2016-06-27 16:55:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:55:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:55:12 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:55:12 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:55:12 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:55:12 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:55:12 --> Total execution time: 0.0053
DEBUG - 2016-06-27 16:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:55:40 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:55:40 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:55:40 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:55:40 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:55:40 --> Total execution time: 0.0052
DEBUG - 2016-06-27 16:58:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:58:34 --> Total execution time: 0.0063
DEBUG - 2016-06-27 16:58:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:58:40 --> Total execution time: 0.0051
DEBUG - 2016-06-27 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:58:43 --> Total execution time: 0.0044
DEBUG - 2016-06-27 16:59:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:59:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:59:04 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:59:04 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:59:04 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:59:04 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:59:04 --> Total execution time: 0.0069
DEBUG - 2016-06-27 16:59:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:59:24 --> Total execution time: 0.0057
DEBUG - 2016-06-27 16:59:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 16:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 16:59:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-27 16:59:49 --> Unable to find validation rule: reqired
ERROR - 2016-06-27 16:59:49 --> Could not find the language line "form_validation_reqired"
DEBUG - 2016-06-27 16:59:49 --> Unable to find validation rule: min_length(8)
ERROR - 2016-06-27 16:59:49 --> Could not find the language line "form_validation_min_length(8)"
DEBUG - 2016-06-27 16:59:49 --> Total execution time: 0.0069
DEBUG - 2016-06-27 17:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:08:13 --> Severity: Parsing Error --> syntax error, unexpected '$pass' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 72
DEBUG - 2016-06-27 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:08:16 --> Severity: Parsing Error --> syntax error, unexpected '$pass' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 72
DEBUG - 2016-06-27 17:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:08:30 --> Total execution time: 0.0066
DEBUG - 2016-06-27 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:08:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Mregister /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:09:11 --> Total execution time: 0.0083
DEBUG - 2016-06-27 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:09:13 --> Total execution time: 0.0050
DEBUG - 2016-06-27 17:09:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:09:44 --> Total execution time: 0.0068
DEBUG - 2016-06-27 17:09:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:09:55 --> Total execution time: 0.0050
DEBUG - 2016-06-27 17:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:10:11 --> Total execution time: 0.0049
DEBUG - 2016-06-27 17:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:10:13 --> Total execution time: 0.0030
DEBUG - 2016-06-27 17:15:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:15:45 --> Total execution time: 0.0073
DEBUG - 2016-06-27 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:15:50 --> Severity: error --> Exception: Unable to locate the model you have specified: ZMregister /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-27 17:16:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:16:08 --> Severity: Notice --> Undefined variable: username /var/www/html/Blog/application/controllers/Project/CRegister.php 97
ERROR - 2016-06-27 17:16:08 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`) VALUES ('', NULL, 'carlosvanegas12')
DEBUG - 2016-06-27 17:16:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:16:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:16:31 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:16:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:16:38 --> Total execution time: 0.0061
DEBUG - 2016-06-27 17:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:16:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:16:43 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:16:44 --> Total execution time: 0.0030
DEBUG - 2016-06-27 17:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:17:35 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:17:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:17:37 --> Total execution time: 0.0035
DEBUG - 2016-06-27 17:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:18:01 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:18:03 --> Total execution time: 0.0031
DEBUG - 2016-06-27 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:18:23 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:18:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:18:25 --> Total execution time: 0.0033
DEBUG - 2016-06-27 17:23:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:23:10 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /var/www/html/Blog/application/controllers/Project/CRegister.php 121
DEBUG - 2016-06-27 17:23:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:23:47 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/Blog/application/controllers/Project/CRegister.php 90
DEBUG - 2016-06-27 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:24:01 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /var/www/html/Blog/application/controllers/Project/CRegister.php 121
DEBUG - 2016-06-27 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:24:14 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/Blog/application/controllers/Project/CRegister.php 121
DEBUG - 2016-06-27 17:24:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:24:46 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /var/www/html/Blog/application/controllers/Project/CRegister.php 121
DEBUG - 2016-06-27 17:24:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:24:55 --> Total execution time: 0.0050
DEBUG - 2016-06-27 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:25:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 17:25:02 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 17:25:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 17:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 17:25:04 --> Total execution time: 0.0053
DEBUG - 2016-06-27 22:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 22:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 22:33:16 --> Total execution time: 0.0032
DEBUG - 2016-06-27 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 22:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 22:33:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-27 22:33:20 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-27 22:33:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-27 22:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-27 22:33:23 --> Total execution time: 0.0031
