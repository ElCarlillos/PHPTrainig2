<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-06-30 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 07:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 07:51:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 07:51:40 --> Total execution time: 0.0033
DEBUG - 2016-06-30 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 08:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 08:04:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 08:04:11 --> Total execution time: 0.0043
DEBUG - 2016-06-30 08:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 08:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 08:05:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 08:05:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 08:05:25 --> Query error: Table 'Blog.username' doesn't exist - Invalid query: SELECT *
FROM `Users`, `username`
WHERE `Users,username` = 'Carlos1'
 LIMIT 1
DEBUG - 2016-06-30 08:07:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 08:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 08:07:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 08:07:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 08:07:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '"Users", "username"
WHERE "Users", "username" 'Carlos1'
 LIMIT 1' at line 2 - Invalid query: SELECT *
FROM "Users", "username"
WHERE "Users", "username" 'Carlos1'
 LIMIT 1
DEBUG - 2016-06-30 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 08:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 08:08:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 08:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 08:08:03 --> Total execution time: 0.0310
DEBUG - 2016-06-30 08:08:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 08:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 08:08:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 08:08:09 --> Total execution time: 0.0032
DEBUG - 2016-06-30 09:27:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:27:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:27:09 --> Total execution time: 0.0045
DEBUG - 2016-06-30 09:27:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:27:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:27:18 --> Total execution time: 0.0036
DEBUG - 2016-06-30 09:28:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:28:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:28:50 --> Total execution time: 0.0034
DEBUG - 2016-06-30 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:29:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:29:14 --> Total execution time: 0.0034
DEBUG - 2016-06-30 09:33:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:33:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:33:42 --> Total execution time: 0.0036
DEBUG - 2016-06-30 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:34:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:34:09 --> Total execution time: 0.0035
DEBUG - 2016-06-30 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:34:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:34:38 --> Total execution time: 0.0034
DEBUG - 2016-06-30 09:34:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:34:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:34:59 --> Total execution time: 0.3417
DEBUG - 2016-06-30 09:44:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:44:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:44:59 --> hola
DEBUG - 2016-06-30 09:44:59 --> Total execution time: 0.0044
DEBUG - 2016-06-30 09:45:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:45:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:45:56 --> hola
DEBUG - 2016-06-30 09:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:45:56 --> Total execution time: 0.0124
DEBUG - 2016-06-30 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:46:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:46:11 --> hola
DEBUG - 2016-06-30 09:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:46:11 --> Total execution time: 0.0035
DEBUG - 2016-06-30 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:29 --> 404 Page Not Found: Project/CRegister/register1
DEBUG - 2016-06-30 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:46:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:46:33 --> Total execution time: 0.0039
DEBUG - 2016-06-30 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:33 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:33 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:33 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:33 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:46:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:46:53 --> Total execution time: 0.0036
DEBUG - 2016-06-30 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:57 --> 404 Page Not Found: Project/CRegister/CRegister
DEBUG - 2016-06-30 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:46:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:46:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:46:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:46:59 --> Total execution time: 0.0032
DEBUG - 2016-06-30 09:47:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:47:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:47:12 --> Total execution time: 0.0060
DEBUG - 2016-06-30 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:14 --> 404 Page Not Found: Project/CRegister/CRegister
DEBUG - 2016-06-30 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:47:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:47:18 --> Total execution time: 0.0033
DEBUG - 2016-06-30 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:47:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:47:23 --> Total execution time: 0.0037
DEBUG - 2016-06-30 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:23 --> 404 Page Not Found: Assets/css
ERROR - 2016-06-30 09:47:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:47:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:47:25 --> Total execution time: 0.0044
DEBUG - 2016-06-30 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 09:47:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-06-30 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:50:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:50:02 --> Total execution time: 0.0055
DEBUG - 2016-06-30 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:50:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:50:25 --> hola
DEBUG - 2016-06-30 09:50:25 --> Total execution time: 0.0047
DEBUG - 2016-06-30 09:51:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:51:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:51:15 --> hola
DEBUG - 2016-06-30 09:51:15 --> Total execution time: 0.0039
DEBUG - 2016-06-30 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:52:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:52:15 --> hola
DEBUG - 2016-06-30 09:52:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:52:15 --> Total execution time: 0.0040
DEBUG - 2016-06-30 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:52:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:52:55 --> hola
DEBUG - 2016-06-30 09:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:52:55 --> Total execution time: 0.0040
DEBUG - 2016-06-30 09:52:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:52:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:52:57 --> hola
DEBUG - 2016-06-30 09:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:52:57 --> Total execution time: 0.0033
DEBUG - 2016-06-30 09:52:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:52:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:52:58 --> hola
DEBUG - 2016-06-30 09:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:52:58 --> Total execution time: 0.0037
DEBUG - 2016-06-30 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:53:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:53:00 --> hola
DEBUG - 2016-06-30 09:53:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:53:00 --> Total execution time: 0.0033
DEBUG - 2016-06-30 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:53:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:53:01 --> hola
DEBUG - 2016-06-30 09:53:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:53:01 --> Total execution time: 0.0036
DEBUG - 2016-06-30 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 09:58:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 09:58:59 --> hola
DEBUG - 2016-06-30 09:58:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 09:58:59 --> Total execution time: 0.0039
DEBUG - 2016-06-30 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:00:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:00:38 --> hola
DEBUG - 2016-06-30 10:00:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:00:38 --> Total execution time: 0.0040
DEBUG - 2016-06-30 10:00:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:00:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:00:43 --> hola
DEBUG - 2016-06-30 10:00:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:00:43 --> Total execution time: 0.0037
DEBUG - 2016-06-30 10:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:02:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:02:26 --> hola
DEBUG - 2016-06-30 10:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:02:26 --> Total execution time: 0.0039
DEBUG - 2016-06-30 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:02:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:02:41 --> hola
DEBUG - 2016-06-30 10:02:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:02:41 --> Total execution time: 0.0038
DEBUG - 2016-06-30 10:04:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:04:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:04:36 --> hola
DEBUG - 2016-06-30 10:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:04:36 --> Total execution time: 0.0041
DEBUG - 2016-06-30 10:05:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:05:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:05:30 --> hola
DEBUG - 2016-06-30 10:05:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:05:30 --> Total execution time: 0.0039
DEBUG - 2016-06-30 10:05:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:05:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:05:35 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:05:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:05:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:05:40 --> hola
DEBUG - 2016-06-30 10:05:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:05:40 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:06:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:06:07 --> hola
DEBUG - 2016-06-30 10:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:06:07 --> Total execution time: 0.0040
DEBUG - 2016-06-30 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:06:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:06:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:06:11 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:06:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:06:17 --> hola
DEBUG - 2016-06-30 10:06:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:06:17 --> Total execution time: 0.0041
DEBUG - 2016-06-30 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:06:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:06:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:06:20 --> Total execution time: 0.0036
DEBUG - 2016-06-30 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:06:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:06:23 --> hola
DEBUG - 2016-06-30 10:06:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:06:23 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:07:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:07:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:07:22 --> hola
DEBUG - 2016-06-30 10:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:07:22 --> Total execution time: 0.0044
DEBUG - 2016-06-30 10:07:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:07:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:07:26 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:07:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:07:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:07:30 --> hola
DEBUG - 2016-06-30 10:07:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:07:30 --> Total execution time: 0.0036
DEBUG - 2016-06-30 10:07:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:07:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:07:40 --> hola
DEBUG - 2016-06-30 10:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:07:40 --> Total execution time: 0.0039
DEBUG - 2016-06-30 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:07:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:07:42 --> hola
DEBUG - 2016-06-30 10:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:07:42 --> Total execution time: 0.0044
DEBUG - 2016-06-30 10:14:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:14:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 10:14:53 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/Blog/application/controllers/Project/Clogin.php 44
DEBUG - 2016-06-30 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:21:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:21:30 --> hola
DEBUG - 2016-06-30 10:21:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:21:30 --> Total execution time: 0.0046
DEBUG - 2016-06-30 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:21:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:21:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:21:35 --> Total execution time: 0.0035
DEBUG - 2016-06-30 10:22:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:13 --> hola
DEBUG - 2016-06-30 10:22:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:13 --> Total execution time: 0.0054
DEBUG - 2016-06-30 10:22:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:21 --> hola
DEBUG - 2016-06-30 10:22:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:21 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:22:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:28 --> Total execution time: 0.0035
DEBUG - 2016-06-30 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:30 --> hola
DEBUG - 2016-06-30 10:22:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:30 --> Total execution time: 0.0033
DEBUG - 2016-06-30 10:22:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:42 --> hola
DEBUG - 2016-06-30 10:22:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:42 --> Total execution time: 0.0040
DEBUG - 2016-06-30 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:22:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:22:48 --> hola
DEBUG - 2016-06-30 10:22:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:22:48 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:25:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:25:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:25:27 --> hola
DEBUG - 2016-06-30 10:25:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:25:27 --> Total execution time: 0.0066
DEBUG - 2016-06-30 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:25:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:25:31 --> hola
DEBUG - 2016-06-30 10:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:25:31 --> Total execution time: 0.0033
DEBUG - 2016-06-30 10:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:27:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:27:01 --> hola
DEBUG - 2016-06-30 10:27:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:27:01 --> Total execution time: 0.0041
DEBUG - 2016-06-30 10:27:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:27:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:27:04 --> hola
DEBUG - 2016-06-30 10:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:27:04 --> Total execution time: 0.0033
DEBUG - 2016-06-30 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:27:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:27:11 --> hola
DEBUG - 2016-06-30 10:27:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:27:11 --> Total execution time: 0.0035
DEBUG - 2016-06-30 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:27:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:27:19 --> hola
DEBUG - 2016-06-30 10:27:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:27:19 --> Total execution time: 0.0034
DEBUG - 2016-06-30 10:29:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:29:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:29:55 --> hola
DEBUG - 2016-06-30 10:29:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 10:29:55 --> Severity: Notice --> Undefined property: CI_Loader::$sesssion /var/www/html/Blog/application/views/Project/Login view.php 29
ERROR - 2016-06-30 10:29:55 --> Severity: Error --> Call to a member function var_dump() on a non-object /var/www/html/Blog/application/views/Project/Login view.php 29
DEBUG - 2016-06-30 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:30:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:30:11 --> hola
DEBUG - 2016-06-30 10:30:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 10:30:11 --> Severity: Error --> Call to undefined method CI_Session::var_dump() /var/www/html/Blog/application/views/Project/Login view.php 29
DEBUG - 2016-06-30 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:31:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:31:08 --> hola
DEBUG - 2016-06-30 10:31:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:31:08 --> Total execution time: 0.0041
DEBUG - 2016-06-30 10:31:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:31:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:31:23 --> hola
DEBUG - 2016-06-30 10:31:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:31:23 --> Total execution time: 0.0037
DEBUG - 2016-06-30 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:31:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:31:33 --> hola
DEBUG - 2016-06-30 10:31:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:31:33 --> Total execution time: 0.0040
DEBUG - 2016-06-30 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:31:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:31:56 --> hola
DEBUG - 2016-06-30 10:31:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:31:56 --> Total execution time: 0.0041
DEBUG - 2016-06-30 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:32:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:32:01 --> hola
DEBUG - 2016-06-30 10:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:32:01 --> Total execution time: 0.0040
DEBUG - 2016-06-30 10:32:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:32:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:32:14 --> hola
DEBUG - 2016-06-30 10:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:32:14 --> Total execution time: 0.0068
DEBUG - 2016-06-30 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:32:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:32:21 --> hola
DEBUG - 2016-06-30 10:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:32:21 --> Total execution time: 0.0038
DEBUG - 2016-06-30 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:47:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:47:10 --> hola
DEBUG - 2016-06-30 10:47:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:47:10 --> Total execution time: 0.0045
DEBUG - 2016-06-30 10:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:47:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:47:14 --> hola
DEBUG - 2016-06-30 10:47:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:47:14 --> Total execution time: 0.0075
DEBUG - 2016-06-30 10:48:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:48:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:48:58 --> hola
DEBUG - 2016-06-30 10:48:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:48:58 --> Total execution time: 0.0045
DEBUG - 2016-06-30 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:49:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:49:02 --> hola
DEBUG - 2016-06-30 10:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:49:02 --> Total execution time: 0.0063
DEBUG - 2016-06-30 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:50:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:50:17 --> hola
DEBUG - 2016-06-30 10:50:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:50:17 --> Total execution time: 0.0044
DEBUG - 2016-06-30 10:50:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:50:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:50:40 --> hola
DEBUG - 2016-06-30 10:50:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:50:40 --> Total execution time: 0.0053
DEBUG - 2016-06-30 10:50:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:50:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:50:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:51:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:51:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:51:07 --> hola
DEBUG - 2016-06-30 10:51:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:51:07 --> Total execution time: 0.0081
DEBUG - 2016-06-30 10:51:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:51:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:51:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:51:35 --> hola
DEBUG - 2016-06-30 10:51:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:51:35 --> Total execution time: 0.0056
DEBUG - 2016-06-30 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:51:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:52:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:52:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:52:00 --> hola
DEBUG - 2016-06-30 10:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:52:00 --> Total execution time: 0.0084
DEBUG - 2016-06-30 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:52:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:52:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:52:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:52:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:52:42 --> hola
DEBUG - 2016-06-30 10:52:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:52:42 --> Total execution time: 0.0080
DEBUG - 2016-06-30 10:52:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:52:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:52:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:58:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:58:22 --> hola
DEBUG - 2016-06-30 10:58:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:58:22 --> Total execution time: 0.0075
DEBUG - 2016-06-30 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:58:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:58:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:58:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:58:47 --> hola
DEBUG - 2016-06-30 10:58:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 10:58:47 --> Total execution time: 0.0065
DEBUG - 2016-06-30 10:58:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 10:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 10:58:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 10:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:00:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:00:24 --> hola
DEBUG - 2016-06-30 11:00:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:00:24 --> Total execution time: 0.0053
DEBUG - 2016-06-30 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:01:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:01:08 --> hola
DEBUG - 2016-06-30 11:01:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:01:08 --> Total execution time: 0.0079
DEBUG - 2016-06-30 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:01:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:01:10 --> Total execution time: 0.0038
DEBUG - 2016-06-30 11:01:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:01:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:01:14 --> hola
DEBUG - 2016-06-30 11:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:01:14 --> Total execution time: 0.0045
DEBUG - 2016-06-30 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:01:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:01:57 --> hola
DEBUG - 2016-06-30 11:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:01:57 --> Total execution time: 0.0045
DEBUG - 2016-06-30 11:02:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:02:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:02:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:02:01 --> Total execution time: 0.0057
DEBUG - 2016-06-30 11:02:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:02:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:02:06 --> hola
DEBUG - 2016-06-30 11:02:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:02:06 --> Total execution time: 0.0040
DEBUG - 2016-06-30 11:02:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 11:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 11:02:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 11:02:22 --> hola
DEBUG - 2016-06-30 11:02:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 11:02:22 --> Total execution time: 0.0036
DEBUG - 2016-06-30 12:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:05:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:05:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:05:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:05:50 --> hola
DEBUG - 2016-06-30 12:05:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:05:50 --> Total execution time: 0.0079
DEBUG - 2016-06-30 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:05:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:05:54 --> Total execution time: 0.0076
DEBUG - 2016-06-30 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:06:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:06:31 --> hola
DEBUG - 2016-06-30 12:06:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:06:31 --> Total execution time: 0.0061
DEBUG - 2016-06-30 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:07:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:07:14 --> hola
DEBUG - 2016-06-30 12:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:07:14 --> Total execution time: 0.0036
DEBUG - 2016-06-30 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:07:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:07:15 --> Total execution time: 0.0039
DEBUG - 2016-06-30 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:07:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:07:25 --> hola
DEBUG - 2016-06-30 12:07:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:07:25 --> Total execution time: 0.0042
DEBUG - 2016-06-30 12:09:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:09:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:09:33 --> hola
DEBUG - 2016-06-30 12:09:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:09:33 --> Total execution time: 0.0079
DEBUG - 2016-06-30 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:09:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:09:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:09:35 --> Total execution time: 0.0060
DEBUG - 2016-06-30 12:13:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:13:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:13:51 --> hola
DEBUG - 2016-06-30 12:13:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:13:51 --> Total execution time: 0.0055
DEBUG - 2016-06-30 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:14:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:14:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:14:11 --> Query error: Unknown column '$uname' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `username` = `$uname`
DEBUG - 2016-06-30 12:14:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:14:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:14:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:14:35 --> Query error: Unknown column 'Carlos1' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `username` = `Carlos1`
DEBUG - 2016-06-30 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:14:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:14:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:14:48 --> Severity: Notice --> Use of undefined constant Users - assumed 'Users' /var/www/html/Blog/application/controllers/Project/Clogin.php 50
ERROR - 2016-06-30 12:14:48 --> Query error: Unknown column 'Carlos1' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `username` = `Carlos1`
DEBUG - 2016-06-30 12:15:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:15:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:15:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:15:51 --> Query error: Unknown column 'Carlos1' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `username` = `Carlos1`
DEBUG - 2016-06-30 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:15:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:15:55 --> hola
DEBUG - 2016-06-30 12:15:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:15:55 --> Total execution time: 0.0061
DEBUG - 2016-06-30 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:15:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:15:56 --> hola
DEBUG - 2016-06-30 12:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:15:56 --> Total execution time: 0.0034
DEBUG - 2016-06-30 12:16:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:16:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:16:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:16:06 --> Query error: Unknown column 'Carlos1' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `username` = `Carlos1`
DEBUG - 2016-06-30 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:17:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:17:50 --> hola
DEBUG - 2016-06-30 12:17:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:17:50 --> Total execution time: 0.0079
DEBUG - 2016-06-30 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:17:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:17:51 --> hola
DEBUG - 2016-06-30 12:17:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:17:51 --> Total execution time: 0.0035
DEBUG - 2016-06-30 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:17:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:17:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:17:57 --> Query error: Unknown column 'Carlos1' in 'where clause' - Invalid query: select * from Users where username = Carlos1
DEBUG - 2016-06-30 12:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:23:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:23:35 --> hola
DEBUG - 2016-06-30 12:23:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:23:35 --> Total execution time: 0.0070
DEBUG - 2016-06-30 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:23:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:23:36 --> hola
DEBUG - 2016-06-30 12:23:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:23:36 --> Total execution time: 0.0052
DEBUG - 2016-06-30 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:23:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:23:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:23:39 --> Severity: Error --> Call to undefined function where() /var/www/html/Blog/application/controllers/Project/Clogin.php 49
DEBUG - 2016-06-30 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:23:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:23:39 --> hola
DEBUG - 2016-06-30 12:23:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:23:39 --> Total execution time: 0.0057
DEBUG - 2016-06-30 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:23:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:23:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:23:45 --> Severity: Error --> Call to undefined function where() /var/www/html/Blog/application/controllers/Project/Clogin.php 49
DEBUG - 2016-06-30 12:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:24:06 --> Severity: Error --> Call to undefined function get() /var/www/html/Blog/application/controllers/Project/Clogin.php 50
DEBUG - 2016-06-30 12:24:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:24:16 --> Total execution time: 0.0076
DEBUG - 2016-06-30 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:20 --> hola
DEBUG - 2016-06-30 12:24:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:24:20 --> Total execution time: 0.0062
DEBUG - 2016-06-30 12:24:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:22 --> hola
DEBUG - 2016-06-30 12:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:24:22 --> Total execution time: 0.0052
DEBUG - 2016-06-30 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:24:28 --> Total execution time: 0.0056
DEBUG - 2016-06-30 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:24:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:24:29 --> hola
DEBUG - 2016-06-30 12:24:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:24:29 --> Total execution time: 0.0056
DEBUG - 2016-06-30 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:25:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:25:52 --> Total execution time: 0.0072
DEBUG - 2016-06-30 12:25:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:25:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:25:54 --> hola
DEBUG - 2016-06-30 12:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:25:54 --> Total execution time: 0.0033
DEBUG - 2016-06-30 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:26:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:26:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:26:13 --> Total execution time: 0.0070
DEBUG - 2016-06-30 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:26:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:26:14 --> hola
DEBUG - 2016-06-30 12:26:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:26:14 --> Total execution time: 0.0061
DEBUG - 2016-06-30 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:26:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:26:54 --> hola
DEBUG - 2016-06-30 12:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:26:54 --> Total execution time: 0.0070
DEBUG - 2016-06-30 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:26:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:26:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:26:59 --> Total execution time: 0.0069
DEBUG - 2016-06-30 12:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:27:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:27:01 --> hola
DEBUG - 2016-06-30 12:27:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:27:01 --> Total execution time: 0.0034
DEBUG - 2016-06-30 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:27:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:27:38 --> hola
DEBUG - 2016-06-30 12:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:27:38 --> Total execution time: 0.0041
DEBUG - 2016-06-30 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:27:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:27:45 --> Total execution time: 0.0069
DEBUG - 2016-06-30 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:27:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:27:47 --> hola
DEBUG - 2016-06-30 12:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:27:47 --> Total execution time: 0.0037
DEBUG - 2016-06-30 12:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:09 --> hola
DEBUG - 2016-06-30 12:34:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:09 --> Total execution time: 0.0042
DEBUG - 2016-06-30 12:34:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:17 --> Total execution time: 0.0069
DEBUG - 2016-06-30 12:34:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:18 --> hola
DEBUG - 2016-06-30 12:34:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:18 --> Total execution time: 0.0034
DEBUG - 2016-06-30 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:48 --> hola
DEBUG - 2016-06-30 12:34:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:48 --> Total execution time: 0.0049
DEBUG - 2016-06-30 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:58 --> Total execution time: 0.0056
DEBUG - 2016-06-30 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:34:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:34:59 --> hola
DEBUG - 2016-06-30 12:34:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:34:59 --> Total execution time: 0.0055
DEBUG - 2016-06-30 12:35:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:04 --> Total execution time: 0.0065
DEBUG - 2016-06-30 12:35:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:05 --> hola
DEBUG - 2016-06-30 12:35:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:05 --> Total execution time: 0.0051
DEBUG - 2016-06-30 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:41 --> hola
DEBUG - 2016-06-30 12:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:41 --> Total execution time: 0.0044
DEBUG - 2016-06-30 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:50 --> Total execution time: 0.0074
DEBUG - 2016-06-30 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:52 --> hola
DEBUG - 2016-06-30 12:35:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:52 --> Total execution time: 0.0046
DEBUG - 2016-06-30 12:35:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:57 --> Total execution time: 0.0068
DEBUG - 2016-06-30 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:35:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:35:58 --> hola
DEBUG - 2016-06-30 12:35:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:35:58 --> Total execution time: 0.0042
DEBUG - 2016-06-30 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:36:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:36:43 --> hola
DEBUG - 2016-06-30 12:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:36:43 --> Total execution time: 0.0056
DEBUG - 2016-06-30 12:36:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:36:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:36:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 12:36:51 --> Query error: Unknown column 'victor1' in 'where clause' - Invalid query: SELECT * FROM  `Users` WHERE username =  victor1
DEBUG - 2016-06-30 12:38:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:17 --> Total execution time: 0.0068
DEBUG - 2016-06-30 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:19 --> hola
DEBUG - 2016-06-30 12:38:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:19 --> Total execution time: 0.0038
DEBUG - 2016-06-30 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:23 --> Total execution time: 0.0074
DEBUG - 2016-06-30 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:24 --> hola
DEBUG - 2016-06-30 12:38:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:24 --> Total execution time: 0.0054
DEBUG - 2016-06-30 12:38:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:28 --> Total execution time: 0.0074
DEBUG - 2016-06-30 12:38:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:38:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:38:29 --> hola
DEBUG - 2016-06-30 12:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:38:29 --> Total execution time: 0.0067
DEBUG - 2016-06-30 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:39:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:39:38 --> hola
DEBUG - 2016-06-30 12:39:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:39:38 --> Total execution time: 0.0069
DEBUG - 2016-06-30 12:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:39:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:39:43 --> Total execution time: 0.0059
DEBUG - 2016-06-30 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:39:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:39:44 --> hola
DEBUG - 2016-06-30 12:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:39:44 --> Total execution time: 0.0061
DEBUG - 2016-06-30 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:40:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:40:05 --> Total execution time: 0.0065
DEBUG - 2016-06-30 12:40:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:40:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:40:07 --> hola
DEBUG - 2016-06-30 12:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:40:07 --> Total execution time: 0.0063
DEBUG - 2016-06-30 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:40:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:40:44 --> hola
DEBUG - 2016-06-30 12:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:40:44 --> Total execution time: 0.0050
DEBUG - 2016-06-30 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:40:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:40:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:40:54 --> Total execution time: 0.0087
DEBUG - 2016-06-30 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:40:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:40:55 --> hola
DEBUG - 2016-06-30 12:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:40:55 --> Total execution time: 0.0039
DEBUG - 2016-06-30 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:41:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:41:13 --> Total execution time: 0.0061
DEBUG - 2016-06-30 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:41:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:41:14 --> hola
DEBUG - 2016-06-30 12:41:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:41:14 --> Total execution time: 0.0051
DEBUG - 2016-06-30 12:41:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:41:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:41:19 --> Total execution time: 0.0080
DEBUG - 2016-06-30 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 12:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 12:41:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 12:41:20 --> hola
DEBUG - 2016-06-30 12:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 12:41:20 --> Total execution time: 0.0053
DEBUG - 2016-06-30 13:18:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:18:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:18:18 --> hola
DEBUG - 2016-06-30 13:18:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:18:18 --> Total execution time: 0.0045
DEBUG - 2016-06-30 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:18:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:18:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:18:27 --> Total execution time: 0.0036
DEBUG - 2016-06-30 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:18:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:18:33 --> hola
DEBUG - 2016-06-30 13:18:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:18:33 --> Total execution time: 0.0038
DEBUG - 2016-06-30 13:18:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:18:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:18:39 --> Total execution time: 0.0038
DEBUG - 2016-06-30 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:20:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:20:31 --> hola
DEBUG - 2016-06-30 13:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:20:31 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:20:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:20:33 --> hola
DEBUG - 2016-06-30 13:20:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:20:33 --> Total execution time: 0.0033
DEBUG - 2016-06-30 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:20:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:20:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 13:20:34 --> Severity: Warning --> mb_strlen() expects parameter 1 to be string, array given /var/www/html/Blog/application/controllers/Project/Clogin.php 54
DEBUG - 2016-06-30 13:20:34 --> Total execution time: 0.0043
DEBUG - 2016-06-30 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:22:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:22:02 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:22:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:22:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:22:03 --> hola
DEBUG - 2016-06-30 13:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:22:03 --> Total execution time: 0.0035
DEBUG - 2016-06-30 13:22:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:22:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:22:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 13:22:09 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/Blog/application/controllers/Project/Clogin.php 56
DEBUG - 2016-06-30 13:22:09 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:23:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:23:06 --> hola
DEBUG - 2016-06-30 13:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:23:06 --> Total execution time: 0.0038
DEBUG - 2016-06-30 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:23:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:23:22 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:23:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:23:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:23:23 --> hola
DEBUG - 2016-06-30 13:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:23:23 --> Total execution time: 0.0036
DEBUG - 2016-06-30 13:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:25:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:25:48 --> hola
DEBUG - 2016-06-30 13:25:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:25:48 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:26:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:26:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:26:08 --> Total execution time: 0.0041
DEBUG - 2016-06-30 13:27:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:29 --> hola
DEBUG - 2016-06-30 13:27:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:29 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:27:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:30 --> hola
DEBUG - 2016-06-30 13:27:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:30 --> Total execution time: 0.0033
DEBUG - 2016-06-30 13:27:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:35 --> Total execution time: 0.0037
DEBUG - 2016-06-30 13:27:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:38 --> hola
DEBUG - 2016-06-30 13:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:38 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:27:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:44 --> Total execution time: 0.0036
DEBUG - 2016-06-30 13:27:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:27:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:27:45 --> hola
DEBUG - 2016-06-30 13:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:27:45 --> Total execution time: 0.0035
DEBUG - 2016-06-30 13:28:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:25 --> Total execution time: 0.0041
DEBUG - 2016-06-30 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:26 --> hola
DEBUG - 2016-06-30 13:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:26 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:37 --> hola
DEBUG - 2016-06-30 13:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:37 --> Total execution time: 0.0041
DEBUG - 2016-06-30 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:42 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:48 --> hola
DEBUG - 2016-06-30 13:28:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:48 --> Total execution time: 0.0036
DEBUG - 2016-06-30 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:52 --> Total execution time: 0.0035
DEBUG - 2016-06-30 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:28:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:28:54 --> hola
DEBUG - 2016-06-30 13:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:28:54 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:29:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:29:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:29:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:29:35 --> Total execution time: 0.0039
DEBUG - 2016-06-30 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:29:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:29:36 --> hola
DEBUG - 2016-06-30 13:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:29:36 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:36:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:36:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:36:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:36:44 --> hola
DEBUG - 2016-06-30 13:36:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:36:44 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:36:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:36:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:36:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:37:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:37:35 --> hola
DEBUG - 2016-06-30 13:37:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:37:35 --> Total execution time: 0.0035
DEBUG - 2016-06-30 13:38:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:38:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:38:27 --> hola
DEBUG - 2016-06-30 13:38:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:38:27 --> Total execution time: 0.0072
DEBUG - 2016-06-30 13:38:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:38:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:38:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:38:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:38:36 --> hola
DEBUG - 2016-06-30 13:38:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:38:36 --> Total execution time: 0.0066
DEBUG - 2016-06-30 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:39:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:39:08 --> hola
DEBUG - 2016-06-30 13:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:39:08 --> Total execution time: 0.0041
DEBUG - 2016-06-30 13:39:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:39:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:39:13 --> Total execution time: 0.0065
DEBUG - 2016-06-30 13:39:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:39:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:39:14 --> hola
DEBUG - 2016-06-30 13:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:39:14 --> Total execution time: 0.0047
DEBUG - 2016-06-30 13:39:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:39:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:39:55 --> hola
DEBUG - 2016-06-30 13:39:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:39:55 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:40:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:40:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:40:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:40:02 --> Total execution time: 0.0079
DEBUG - 2016-06-30 13:40:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:40:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:40:03 --> hola
DEBUG - 2016-06-30 13:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:40:03 --> Total execution time: 0.0034
DEBUG - 2016-06-30 13:40:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:40:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:40:15 --> hola
DEBUG - 2016-06-30 13:40:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:40:15 --> Total execution time: 0.0069
DEBUG - 2016-06-30 13:40:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:40:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:40:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:40:20 --> Total execution time: 0.0068
DEBUG - 2016-06-30 13:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:40:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:40:21 --> hola
DEBUG - 2016-06-30 13:40:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:40:21 --> Total execution time: 0.0064
DEBUG - 2016-06-30 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:41:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:41:08 --> hola
DEBUG - 2016-06-30 13:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:41:08 --> Total execution time: 0.0037
DEBUG - 2016-06-30 13:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:41:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:41:13 --> Total execution time: 0.0076
DEBUG - 2016-06-30 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:41:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:41:14 --> hola
DEBUG - 2016-06-30 13:41:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:41:14 --> Total execution time: 0.0048
DEBUG - 2016-06-30 13:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:23 --> hola
DEBUG - 2016-06-30 13:42:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:23 --> Total execution time: 0.0060
DEBUG - 2016-06-30 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:29 --> Total execution time: 0.0066
DEBUG - 2016-06-30 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:30 --> hola
DEBUG - 2016-06-30 13:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:30 --> Total execution time: 0.0055
DEBUG - 2016-06-30 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:35 --> Total execution time: 0.0064
DEBUG - 2016-06-30 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:36 --> hola
DEBUG - 2016-06-30 13:42:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:36 --> Total execution time: 0.0059
DEBUG - 2016-06-30 13:42:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:42:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:42:55 --> hola
DEBUG - 2016-06-30 13:42:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:42:55 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:43:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:43:07 --> Total execution time: 0.0087
DEBUG - 2016-06-30 13:43:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:43:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:43:09 --> hola
DEBUG - 2016-06-30 13:43:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:43:09 --> Total execution time: 0.0068
DEBUG - 2016-06-30 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:43:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:43:51 --> hola
DEBUG - 2016-06-30 13:43:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:43:51 --> Total execution time: 0.0041
DEBUG - 2016-06-30 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:43:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:43:57 --> Total execution time: 0.0071
DEBUG - 2016-06-30 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:43:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:43:57 --> hola
DEBUG - 2016-06-30 13:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:43:57 --> Total execution time: 0.0070
DEBUG - 2016-06-30 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:48:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:48:36 --> hola
DEBUG - 2016-06-30 13:48:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:48:36 --> Total execution time: 0.0059
DEBUG - 2016-06-30 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:48:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:48:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:48:42 --> Total execution time: 0.0075
DEBUG - 2016-06-30 13:48:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:48:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:48:43 --> hola
DEBUG - 2016-06-30 13:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:48:43 --> Total execution time: 0.0035
DEBUG - 2016-06-30 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:50:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:50:04 --> hola
DEBUG - 2016-06-30 13:50:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:50:04 --> Total execution time: 0.0070
DEBUG - 2016-06-30 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:50:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:50:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:50:10 --> Total execution time: 0.0067
DEBUG - 2016-06-30 13:50:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:50:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:50:12 --> hola
DEBUG - 2016-06-30 13:50:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:50:12 --> Total execution time: 0.0033
DEBUG - 2016-06-30 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:51:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:51:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:51:02 --> Total execution time: 0.0071
DEBUG - 2016-06-30 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:51:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:51:04 --> hola
DEBUG - 2016-06-30 13:51:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:51:04 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:51:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:51:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:51:09 --> Total execution time: 0.0051
DEBUG - 2016-06-30 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:53:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:53:25 --> hola
DEBUG - 2016-06-30 13:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:53:25 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:53:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:53:26 --> hola
DEBUG - 2016-06-30 13:53:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:53:26 --> Total execution time: 0.0048
DEBUG - 2016-06-30 13:53:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:53:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:53:33 --> Total execution time: 0.0059
DEBUG - 2016-06-30 13:53:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:53:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:53:34 --> hola
DEBUG - 2016-06-30 13:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:53:34 --> Total execution time: 0.0056
DEBUG - 2016-06-30 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:01 --> hola
DEBUG - 2016-06-30 13:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:01 --> Total execution time: 0.0053
DEBUG - 2016-06-30 13:54:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:05 --> Total execution time: 0.0060
DEBUG - 2016-06-30 13:54:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:07 --> hola
DEBUG - 2016-06-30 13:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:07 --> Total execution time: 0.0033
DEBUG - 2016-06-30 13:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:35 --> hola
DEBUG - 2016-06-30 13:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:35 --> Total execution time: 0.0067
DEBUG - 2016-06-30 13:54:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:42 --> Total execution time: 0.0067
DEBUG - 2016-06-30 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:54:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:54:43 --> hola
DEBUG - 2016-06-30 13:54:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:54:43 --> Total execution time: 0.0067
DEBUG - 2016-06-30 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:03 --> hola
DEBUG - 2016-06-30 13:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:03 --> Total execution time: 0.0040
DEBUG - 2016-06-30 13:56:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:07 --> Total execution time: 0.0099
DEBUG - 2016-06-30 13:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:08 --> hola
DEBUG - 2016-06-30 13:56:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:08 --> Total execution time: 0.0033
DEBUG - 2016-06-30 13:56:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:39 --> hola
DEBUG - 2016-06-30 13:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:39 --> Total execution time: 0.0042
DEBUG - 2016-06-30 13:56:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:44 --> Total execution time: 0.0067
DEBUG - 2016-06-30 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 13:56:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 13:56:45 --> hola
DEBUG - 2016-06-30 13:56:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 13:56:45 --> Total execution time: 0.0032
DEBUG - 2016-06-30 14:04:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:04:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:04:40 --> hola
DEBUG - 2016-06-30 14:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:04:40 --> Total execution time: 0.0065
DEBUG - 2016-06-30 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:04:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:05:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:05:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:05:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:05:22 --> Total execution time: 0.0089
DEBUG - 2016-06-30 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 14:05:22 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:05:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:05:29 --> hola
DEBUG - 2016-06-30 14:05:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:05:29 --> Total execution time: 0.0065
DEBUG - 2016-06-30 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:06:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:06:54 --> hola
DEBUG - 2016-06-30 14:06:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:06:54 --> Total execution time: 0.0035
DEBUG - 2016-06-30 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:04 --> Total execution time: 0.0066
DEBUG - 2016-06-30 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:07 --> hola
DEBUG - 2016-06-30 14:07:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:07 --> Total execution time: 0.0063
DEBUG - 2016-06-30 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:10 --> hola
DEBUG - 2016-06-30 14:07:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:10 --> Total execution time: 0.0077
DEBUG - 2016-06-30 14:07:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:14 --> Total execution time: 0.0065
DEBUG - 2016-06-30 14:07:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:36 --> hola
DEBUG - 2016-06-30 14:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:36 --> Total execution time: 0.0051
DEBUG - 2016-06-30 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:46 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:07:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:07:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:07:49 --> hola
DEBUG - 2016-06-30 14:07:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:07:49 --> Total execution time: 0.0053
DEBUG - 2016-06-30 14:08:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:08:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:08:11 --> hola
DEBUG - 2016-06-30 14:08:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:08:11 --> Total execution time: 0.0070
DEBUG - 2016-06-30 14:08:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:08:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:08:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:08:20 --> Total execution time: 0.0077
DEBUG - 2016-06-30 14:09:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:04 --> hola
DEBUG - 2016-06-30 14:09:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:04 --> Total execution time: 0.0040
DEBUG - 2016-06-30 14:09:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:06 --> Total execution time: 0.0048
DEBUG - 2016-06-30 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:30 --> hola
DEBUG - 2016-06-30 14:09:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:30 --> Total execution time: 0.0068
DEBUG - 2016-06-30 14:09:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:45 --> hola
DEBUG - 2016-06-30 14:09:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:45 --> Total execution time: 0.0200
DEBUG - 2016-06-30 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:46 --> Total execution time: 0.0054
DEBUG - 2016-06-30 14:09:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:09:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:09:50 --> hola
DEBUG - 2016-06-30 14:09:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:09:50 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:10:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 14:11:04 --> Severity: Parsing Error --> syntax error, unexpected 'username' (T_STRING) /var/www/html/Blog/application/controllers/Project/Clogin.php 80
DEBUG - 2016-06-30 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:11:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:11:20 --> hola
DEBUG - 2016-06-30 14:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:20 --> Total execution time: 0.0042
DEBUG - 2016-06-30 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:11:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:23 --> Total execution time: 0.0076
DEBUG - 2016-06-30 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:11:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:11:26 --> hola
DEBUG - 2016-06-30 14:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:26 --> Total execution time: 0.0055
DEBUG - 2016-06-30 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:11:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:11:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:31 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:11:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:11:33 --> hola
DEBUG - 2016-06-30 14:11:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:11:33 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:13:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:13:28 --> hola
DEBUG - 2016-06-30 14:13:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:13:28 --> Total execution time: 0.0040
DEBUG - 2016-06-30 14:13:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:13:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:13:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:13:39 --> Total execution time: 0.0072
DEBUG - 2016-06-30 14:14:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:14:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:14:11 --> hola
DEBUG - 2016-06-30 14:14:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:14:11 --> Total execution time: 0.0071
DEBUG - 2016-06-30 14:14:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:14:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:14:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:14:14 --> Total execution time: 0.0068
DEBUG - 2016-06-30 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:04 --> hola
DEBUG - 2016-06-30 14:15:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:04 --> Total execution time: 0.0044
DEBUG - 2016-06-30 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:06 --> Total execution time: 0.0053
DEBUG - 2016-06-30 14:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:26 --> hola
DEBUG - 2016-06-30 14:15:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:26 --> Total execution time: 0.0052
DEBUG - 2016-06-30 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:29 --> Total execution time: 0.0087
DEBUG - 2016-06-30 14:15:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:38 --> hola
DEBUG - 2016-06-30 14:15:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:38 --> Total execution time: 0.0043
DEBUG - 2016-06-30 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:40 --> Total execution time: 0.0047
DEBUG - 2016-06-30 14:15:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:52 --> hola
DEBUG - 2016-06-30 14:15:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:52 --> Total execution time: 0.0073
DEBUG - 2016-06-30 14:15:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:15:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:15:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:15:54 --> Total execution time: 0.0036
DEBUG - 2016-06-30 14:16:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:16:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:16:05 --> hola
DEBUG - 2016-06-30 14:16:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:16:05 --> Total execution time: 0.0048
DEBUG - 2016-06-30 14:16:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:16:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:16:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:12 --> hola
DEBUG - 2016-06-30 14:17:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:12 --> Total execution time: 0.0038
DEBUG - 2016-06-30 14:17:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:14 --> Total execution time: 0.0058
DEBUG - 2016-06-30 14:17:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:17 --> hola
DEBUG - 2016-06-30 14:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:17 --> Total execution time: 0.0075
DEBUG - 2016-06-30 14:17:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:33 --> hola
DEBUG - 2016-06-30 14:17:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:33 --> Total execution time: 0.0041
DEBUG - 2016-06-30 14:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:17:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:17:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:17:35 --> Total execution time: 0.0038
DEBUG - 2016-06-30 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:18:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:18:00 --> hola
DEBUG - 2016-06-30 14:18:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:18:00 --> Total execution time: 0.0045
DEBUG - 2016-06-30 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:18:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:18:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:18:07 --> Total execution time: 0.0081
DEBUG - 2016-06-30 14:19:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:19:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:19:41 --> hola
DEBUG - 2016-06-30 14:19:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:19:41 --> Total execution time: 0.0036
DEBUG - 2016-06-30 14:19:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:00 --> Total execution time: 0.0038
DEBUG - 2016-06-30 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:08 --> hola
DEBUG - 2016-06-30 14:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:08 --> Total execution time: 0.0049
DEBUG - 2016-06-30 14:20:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:10 --> hola
DEBUG - 2016-06-30 14:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:10 --> Total execution time: 0.0059
DEBUG - 2016-06-30 14:20:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:16 --> Total execution time: 0.0066
DEBUG - 2016-06-30 14:20:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:16 --> hola
DEBUG - 2016-06-30 14:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:16 --> Total execution time: 0.0059
DEBUG - 2016-06-30 14:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:19 --> Total execution time: 0.0066
DEBUG - 2016-06-30 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:20 --> hola
DEBUG - 2016-06-30 14:20:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:20 --> Total execution time: 0.0072
DEBUG - 2016-06-30 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:21 --> Total execution time: 0.0039
DEBUG - 2016-06-30 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:22 --> hola
DEBUG - 2016-06-30 14:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:22 --> Total execution time: 0.0061
DEBUG - 2016-06-30 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:24 --> Total execution time: 0.0065
DEBUG - 2016-06-30 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:25 --> hola
DEBUG - 2016-06-30 14:20:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:25 --> Total execution time: 0.0052
DEBUG - 2016-06-30 14:20:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:28 --> Total execution time: 0.0067
DEBUG - 2016-06-30 14:20:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:20:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:20:29 --> hola
DEBUG - 2016-06-30 14:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:20:29 --> Total execution time: 0.0062
DEBUG - 2016-06-30 14:28:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:28:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:28:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:28:12 --> Total execution time: 0.0097
DEBUG - 2016-06-30 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:28:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:28:14 --> hola
DEBUG - 2016-06-30 14:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:28:14 --> Total execution time: 0.0035
DEBUG - 2016-06-30 14:28:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:28:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:28:29 --> hola
DEBUG - 2016-06-30 14:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:28:29 --> Total execution time: 0.0041
DEBUG - 2016-06-30 14:28:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:28:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:28:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:28:34 --> Total execution time: 0.0071
DEBUG - 2016-06-30 14:28:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:28:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:28:35 --> hola
DEBUG - 2016-06-30 14:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:28:35 --> Total execution time: 0.0045
DEBUG - 2016-06-30 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:06 --> hola
DEBUG - 2016-06-30 14:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:06 --> Total execution time: 0.0040
DEBUG - 2016-06-30 14:29:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:11 --> Total execution time: 0.0090
DEBUG - 2016-06-30 14:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:12 --> hola
DEBUG - 2016-06-30 14:29:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:12 --> Total execution time: 0.0063
DEBUG - 2016-06-30 14:29:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:29 --> hola
DEBUG - 2016-06-30 14:29:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:29 --> Total execution time: 0.0069
DEBUG - 2016-06-30 14:29:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:35 --> Total execution time: 0.0073
DEBUG - 2016-06-30 14:29:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:29:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:29:36 --> hola
DEBUG - 2016-06-30 14:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:29:36 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:30:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:30:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:30:08 --> hola
DEBUG - 2016-06-30 14:30:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:30:08 --> Total execution time: 0.0067
DEBUG - 2016-06-30 14:30:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:30:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:30:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:30:13 --> Total execution time: 0.0074
DEBUG - 2016-06-30 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:30:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:30:14 --> hola
DEBUG - 2016-06-30 14:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:30:14 --> Total execution time: 0.0055
DEBUG - 2016-06-30 14:35:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:35:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:35:50 --> hola
DEBUG - 2016-06-30 14:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:35:50 --> Total execution time: 0.0078
DEBUG - 2016-06-30 14:35:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:35:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:35:56 --> Total execution time: 0.0062
DEBUG - 2016-06-30 14:36:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:22 --> Total execution time: 0.0042
DEBUG - 2016-06-30 14:36:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:24 --> hola
DEBUG - 2016-06-30 14:36:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:24 --> Total execution time: 0.0035
DEBUG - 2016-06-30 14:36:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:28 --> Total execution time: 0.0066
DEBUG - 2016-06-30 14:36:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:29 --> hola
DEBUG - 2016-06-30 14:36:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:29 --> Total execution time: 0.0034
DEBUG - 2016-06-30 14:36:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:36 --> hola
DEBUG - 2016-06-30 14:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:36 --> Total execution time: 0.0053
DEBUG - 2016-06-30 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:37 --> hola
DEBUG - 2016-06-30 14:36:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:37 --> Total execution time: 0.0033
DEBUG - 2016-06-30 14:36:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:49 --> hola
DEBUG - 2016-06-30 14:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:49 --> Total execution time: 0.0068
DEBUG - 2016-06-30 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:54 --> Total execution time: 0.0075
DEBUG - 2016-06-30 14:36:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:36:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:36:55 --> hola
DEBUG - 2016-06-30 14:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:36:55 --> Total execution time: 0.0055
DEBUG - 2016-06-30 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:37:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:37:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:37:48 --> Total execution time: 0.0070
DEBUG - 2016-06-30 14:37:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:37:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:37:49 --> hola
DEBUG - 2016-06-30 14:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:37:49 --> Total execution time: 0.0034
DEBUG - 2016-06-30 14:38:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:38:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:38:25 --> Total execution time: 0.0053
DEBUG - 2016-06-30 14:38:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:38:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:38:28 --> hola
DEBUG - 2016-06-30 14:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:38:28 --> Total execution time: 0.0035
DEBUG - 2016-06-30 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:38:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:38:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:38:31 --> Total execution time: 0.0064
DEBUG - 2016-06-30 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:38:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:38:32 --> hola
DEBUG - 2016-06-30 14:38:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:38:32 --> Total execution time: 0.0050
DEBUG - 2016-06-30 14:39:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:39:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:39:02 --> hola
DEBUG - 2016-06-30 14:39:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:39:02 --> Total execution time: 0.0041
DEBUG - 2016-06-30 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:39:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:39:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:39:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:39:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:39:23 --> Total execution time: 0.0080
DEBUG - 2016-06-30 14:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:39:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 14:39:24 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 14:39:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:39:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:39:25 --> hola
DEBUG - 2016-06-30 14:39:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 14:39:25 --> Total execution time: 0.0034
DEBUG - 2016-06-30 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:42:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:42:09 --> hola
DEBUG - 2016-06-30 14:42:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:42:09 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 /var/www/html/Blog/application/views/Project/Login view.php 4
ERROR - 2016-06-30 14:42:09 --> Severity: Warning --> include(http://localhost/Blog/assets/css/bootstrap-theme.css): failed to open stream: no suitable wrapper could be found /var/www/html/Blog/application/views/Project/Login view.php 4
ERROR - 2016-06-30 14:42:09 --> Severity: Warning --> include(): Failed opening 'http://localhost/Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 4
DEBUG - 2016-06-30 14:42:09 --> Total execution time: 0.0085
DEBUG - 2016-06-30 14:53:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:53:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:53:26 --> hola
DEBUG - 2016-06-30 14:53:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:53:26 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 /var/www/html/Blog/application/views/Project/Login view.php 4
ERROR - 2016-06-30 14:53:26 --> Severity: Warning --> include(http://localhost/Blog/assets/css/bootstrap-theme.css): failed to open stream: no suitable wrapper could be found /var/www/html/Blog/application/views/Project/Login view.php 4
ERROR - 2016-06-30 14:53:26 --> Severity: Warning --> include(): Failed opening 'http://localhost/Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 4
ERROR - 2016-06-30 14:53:26 --> Severity: Warning --> include(../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:53:26 --> Severity: Warning --> include(): Failed opening '../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:53:26 --> Total execution time: 0.0057
DEBUG - 2016-06-30 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:54:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:54:53 --> hola
DEBUG - 2016-06-30 14:54:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:54:53 --> Severity: Warning --> include(../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:54:53 --> Severity: Warning --> include(): Failed opening '../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:54:53 --> Total execution time: 0.0041
DEBUG - 2016-06-30 14:55:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:55:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:55:46 --> hola
DEBUG - 2016-06-30 14:55:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:55:46 --> Severity: Warning --> include(../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:55:46 --> Severity: Warning --> include(): Failed opening '../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:55:46 --> Total execution time: 0.0073
DEBUG - 2016-06-30 14:55:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:55:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:55:55 --> hola
DEBUG - 2016-06-30 14:55:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:55:55 --> Severity: Warning --> include(../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:55:55 --> Severity: Warning --> include(): Failed opening '../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:55:55 --> Total execution time: 0.0054
DEBUG - 2016-06-30 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:56:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:56:36 --> hola
DEBUG - 2016-06-30 14:56:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:56:36 --> Severity: Warning --> include(../../../../assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:56:36 --> Severity: Warning --> include(): Failed opening '../../../../assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:56:36 --> Total execution time: 0.0062
DEBUG - 2016-06-30 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 14:56:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 14:56:38 --> hola
DEBUG - 2016-06-30 14:56:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 14:56:38 --> Severity: Warning --> include(../../../../assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 14:56:38 --> Severity: Warning --> include(): Failed opening '../../../../assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 14:56:38 --> Total execution time: 0.0038
DEBUG - 2016-06-30 14:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:00:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:00:36 --> hola
DEBUG - 2016-06-30 15:00:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:00:36 --> Severity: Warning --> include(../../../../assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:00:36 --> Severity: Warning --> include(): Failed opening '../../../../assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 15:00:36 --> Total execution time: 0.0062
DEBUG - 2016-06-30 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:00:42 --> 404 Page Not Found: Blog/assets
DEBUG - 2016-06-30 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:01:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:01:07 --> hola
DEBUG - 2016-06-30 15:01:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:01:07 --> Severity: Warning --> include(../../../../assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:01:07 --> Severity: Warning --> include(): Failed opening '../../../../assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
DEBUG - 2016-06-30 15:01:07 --> Total execution time: 0.0079
DEBUG - 2016-06-30 15:02:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:02:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:02:35 --> hola
DEBUG - 2016-06-30 15:02:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:02:35 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:02:35 --> Total execution time: 0.0101
DEBUG - 2016-06-30 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:02:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:02:56 --> hola
DEBUG - 2016-06-30 15:02:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:02:56 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:02:56 --> Total execution time: 0.0096
DEBUG - 2016-06-30 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:03:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:03:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:03:12 --> hola
DEBUG - 2016-06-30 15:03:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:03:12 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:03:12 --> Total execution time: 0.0104
DEBUG - 2016-06-30 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:04:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:04:09 --> hola
DEBUG - 2016-06-30 15:04:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:04:09 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:04:09 --> Total execution time: 0.0086
DEBUG - 2016-06-30 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:08:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:08:39 --> hola
DEBUG - 2016-06-30 15:08:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:08:39 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:08:39 --> Total execution time: 0.0101
DEBUG - 2016-06-30 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:10:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:10:01 --> hola
DEBUG - 2016-06-30 15:10:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(http://localhost/Blog/assets/css/bootstrap-theme.css): failed to open stream: no suitable wrapper could be found /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(): Failed opening 'http://localhost/Blog/assets/css/bootstrap-theme.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 5
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap-theme.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap-theme.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 6
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 7
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(../../../../../Blog/assets/css/bootstrap.min.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Login view.php 8
ERROR - 2016-06-30 15:10:01 --> Severity: Warning --> include(): Failed opening '../../../../../Blog/assets/css/bootstrap.min.css' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Login view.php 8
DEBUG - 2016-06-30 15:10:01 --> Total execution time: 0.0109
DEBUG - 2016-06-30 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:13:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:13:33 --> hola
DEBUG - 2016-06-30 15:13:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:13:33 --> Total execution time: 0.0057
DEBUG - 2016-06-30 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:14:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:14:42 --> hola
DEBUG - 2016-06-30 15:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:14:42 --> Total execution time: 0.0042
DEBUG - 2016-06-30 15:14:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:14:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:14:52 --> hola
DEBUG - 2016-06-30 15:14:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:14:52 --> Total execution time: 0.0063
DEBUG - 2016-06-30 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:20:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:20:08 --> Total execution time: 0.0080
DEBUG - 2016-06-30 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:20:08 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:21:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:21:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:21:37 --> hola
DEBUG - 2016-06-30 15:21:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:21:37 --> Total execution time: 0.0078
DEBUG - 2016-06-30 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:21:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:21:39 --> hola
DEBUG - 2016-06-30 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:21:39 --> Total execution time: 0.0033
DEBUG - 2016-06-30 15:21:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:21:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:21:41 --> Total execution time: 0.0068
DEBUG - 2016-06-30 15:21:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:21:41 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:21:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:21:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:21:43 --> hola
DEBUG - 2016-06-30 15:21:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:21:43 --> Total execution time: 0.0034
DEBUG - 2016-06-30 15:23:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:23:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:23:20 --> hola
DEBUG - 2016-06-30 15:23:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:23:20 --> Total execution time: 0.0083
DEBUG - 2016-06-30 15:23:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:23:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:23:21 --> Total execution time: 0.0050
DEBUG - 2016-06-30 15:23:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:23:21 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:23:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:23:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:23:28 --> hola
DEBUG - 2016-06-30 15:23:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:23:28 --> Total execution time: 0.0064
DEBUG - 2016-06-30 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:24:01 --> Severity: Parsing Error --> syntax error, unexpected 'alert' (T_STRING), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/Clogin.php 64
DEBUG - 2016-06-30 15:24:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:24:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:24:19 --> hola
DEBUG - 2016-06-30 15:24:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:24:19 --> Total execution time: 0.0080
DEBUG - 2016-06-30 15:24:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:24:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:24:22 --> Total execution time: 0.0071
DEBUG - 2016-06-30 15:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:24:23 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:25:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:25:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:25:16 --> hola
DEBUG - 2016-06-30 15:25:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:25:16 --> Total execution time: 0.0062
DEBUG - 2016-06-30 15:25:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:25:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:25:31 --> hola
DEBUG - 2016-06-30 15:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:25:31 --> Total execution time: 0.0053
DEBUG - 2016-06-30 15:25:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:25:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:25:45 --> hola
DEBUG - 2016-06-30 15:25:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:25:45 --> Total execution time: 0.0067
DEBUG - 2016-06-30 15:26:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:26:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:26:00 --> hola
DEBUG - 2016-06-30 15:26:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:26:00 --> Total execution time: 0.0056
DEBUG - 2016-06-30 15:30:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:30:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:30:02 --> hola
DEBUG - 2016-06-30 15:30:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:30:02 --> Total execution time: 0.0071
DEBUG - 2016-06-30 15:31:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:31:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:31:06 --> hola
DEBUG - 2016-06-30 15:31:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:31:06 --> Total execution time: 0.0077
DEBUG - 2016-06-30 15:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:31:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:31:32 --> hola
DEBUG - 2016-06-30 15:31:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:31:32 --> Total execution time: 0.0054
DEBUG - 2016-06-30 15:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:31:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:31:43 --> hola
DEBUG - 2016-06-30 15:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:31:43 --> Total execution time: 0.0068
DEBUG - 2016-06-30 15:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:31:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:31:51 --> hola
DEBUG - 2016-06-30 15:31:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:31:51 --> Total execution time: 0.0060
DEBUG - 2016-06-30 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:31:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:31:58 --> hola
DEBUG - 2016-06-30 15:31:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:31:58 --> Total execution time: 0.0058
DEBUG - 2016-06-30 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:32:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:32:04 --> hola
DEBUG - 2016-06-30 15:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:32:04 --> Total execution time: 0.0055
DEBUG - 2016-06-30 15:32:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:32:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:32:11 --> hola
DEBUG - 2016-06-30 15:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:32:11 --> Total execution time: 0.0052
DEBUG - 2016-06-30 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:32:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:32:26 --> hola
DEBUG - 2016-06-30 15:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:32:26 --> Total execution time: 0.0061
DEBUG - 2016-06-30 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:32:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:32:54 --> hola
DEBUG - 2016-06-30 15:32:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:32:54 --> Total execution time: 0.0065
DEBUG - 2016-06-30 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:33:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:33:02 --> hola
DEBUG - 2016-06-30 15:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:33:02 --> Total execution time: 0.0066
DEBUG - 2016-06-30 15:33:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:33:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:33:50 --> hola
DEBUG - 2016-06-30 15:33:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:33:50 --> Total execution time: 0.0063
DEBUG - 2016-06-30 15:35:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:35:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:35:03 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/Clogin.php 65
DEBUG - 2016-06-30 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:35:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:35:21 --> hola
DEBUG - 2016-06-30 15:35:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:35:21 --> Total execution time: 0.0057
DEBUG - 2016-06-30 15:35:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:35:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:35:34 --> hola
DEBUG - 2016-06-30 15:35:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:35:34 --> Total execution time: 0.0057
DEBUG - 2016-06-30 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:35:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:35:43 --> Total execution time: 0.0078
DEBUG - 2016-06-30 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:35:43 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:36:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:36:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:36:08 --> hola
DEBUG - 2016-06-30 15:36:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:36:08 --> Total execution time: 0.0064
DEBUG - 2016-06-30 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:36:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:36:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:36:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:36:11 --> Total execution time: 0.0067
DEBUG - 2016-06-30 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:36:11 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:36:15 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:38:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:38:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:38:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:38:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:38:14 --> Total execution time: 0.0042
DEBUG - 2016-06-30 15:38:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:38:15 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-30 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:38:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:38:46 --> hola
DEBUG - 2016-06-30 15:38:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:38:46 --> Total execution time: 0.0066
DEBUG - 2016-06-30 15:39:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:39:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:39:11 --> hola
DEBUG - 2016-06-30 15:39:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:39:11 --> Total execution time: 0.0064
DEBUG - 2016-06-30 15:40:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:40:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:40:33 --> hola
DEBUG - 2016-06-30 15:40:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:40:33 --> Total execution time: 0.0059
DEBUG - 2016-06-30 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:40:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:40:44 --> Total execution time: 0.0070
DEBUG - 2016-06-30 15:41:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:41:01 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-06-30 15:41:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:41:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:41:05 --> hola
DEBUG - 2016-06-30 15:41:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:41:05 --> Total execution time: 0.0063
DEBUG - 2016-06-30 15:42:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:42:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:42:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:42:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:42:43 --> Total execution time: 0.0077
DEBUG - 2016-06-30 15:42:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:42:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:42:47 --> hola
DEBUG - 2016-06-30 15:42:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:42:47 --> Total execution time: 0.0064
DEBUG - 2016-06-30 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:44:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:44:18 --> hola
DEBUG - 2016-06-30 15:44:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:44:18 --> Total execution time: 0.0063
DEBUG - 2016-06-30 15:44:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:44:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:44:26 --> hola
DEBUG - 2016-06-30 15:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:44:26 --> Total execution time: 0.0047
DEBUG - 2016-06-30 15:44:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:44:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:44:28 --> Total execution time: 0.0069
DEBUG - 2016-06-30 15:45:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:45:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:45:18 --> Total execution time: 0.0133
DEBUG - 2016-06-30 15:49:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:49:37 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) /var/www/html/Blog/application/controllers/Project/Clogin.php 81
DEBUG - 2016-06-30 15:50:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:50:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:50:55 --> Total execution time: 0.0078
DEBUG - 2016-06-30 15:51:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:51:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:51:33 --> Total execution time: 0.0073
DEBUG - 2016-06-30 15:52:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:52:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:52:51 --> Total execution time: 0.0049
DEBUG - 2016-06-30 15:53:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:53:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:04 --> Total execution time: 0.0067
DEBUG - 2016-06-30 15:53:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:53:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:53:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:21 --> Total execution time: 0.0081
DEBUG - 2016-06-30 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:53:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:53:39 --> Total execution time: 0.0071
DEBUG - 2016-06-30 15:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:54:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:54:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:00 --> Total execution time: 0.0095
DEBUG - 2016-06-30 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:54:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:39 --> Total execution time: 0.0046
DEBUG - 2016-06-30 15:54:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:54:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:54:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:54:55 --> Total execution time: 0.0072
DEBUG - 2016-06-30 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:55:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:55:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:10 --> Total execution time: 0.0061
DEBUG - 2016-06-30 15:55:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:55:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:55:23 --> hola
DEBUG - 2016-06-30 15:55:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:23 --> Total execution time: 0.0103
DEBUG - 2016-06-30 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:55:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:55:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:28 --> Total execution time: 0.0060
DEBUG - 2016-06-30 15:55:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 15:55:38 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-06-30 15:55:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:55:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:42 --> Total execution time: 0.0088
DEBUG - 2016-06-30 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:55:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:55:43 --> hola
DEBUG - 2016-06-30 15:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:55:43 --> Total execution time: 0.0050
DEBUG - 2016-06-30 15:56:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:56:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:56:02 --> Total execution time: 0.0039
DEBUG - 2016-06-30 15:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:56:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:56:03 --> hola
DEBUG - 2016-06-30 15:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:56:03 --> Total execution time: 0.0034
DEBUG - 2016-06-30 15:58:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:58:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:58:10 --> hola
DEBUG - 2016-06-30 15:58:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:58:10 --> Total execution time: 0.0074
DEBUG - 2016-06-30 15:58:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:58:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:58:15 --> Total execution time: 0.0054
DEBUG - 2016-06-30 15:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:58:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:58:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:58:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:58:54 --> Total execution time: 0.0040
DEBUG - 2016-06-30 15:59:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:59:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:59:03 --> hola
DEBUG - 2016-06-30 15:59:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:59:03 --> Total execution time: 0.0055
DEBUG - 2016-06-30 15:59:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 15:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 15:59:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 15:59:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:59:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 15:59:14 --> Total execution time: 0.0059
DEBUG - 2016-06-30 16:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:01:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:01:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:01:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:01:22 --> Total execution time: 0.0065
DEBUG - 2016-06-30 16:03:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 16:03:04 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/Clogin.php 47
DEBUG - 2016-06-30 16:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:03:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:03:15 --> Total execution time: 0.0060
DEBUG - 2016-06-30 16:03:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:03:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:03:54 --> Total execution time: 0.0079
DEBUG - 2016-06-30 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 16:04:36 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/Clogin.php 45
DEBUG - 2016-06-30 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:04:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:04:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:04:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:04:46 --> Total execution time: 0.0072
DEBUG - 2016-06-30 16:05:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:05:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:05:06 --> Total execution time: 0.0073
DEBUG - 2016-06-30 16:07:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-30 16:07:14 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/Clogin.php 45
DEBUG - 2016-06-30 16:07:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:07:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:07:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:07:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:07:41 --> Total execution time: 0.0079
DEBUG - 2016-06-30 16:07:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:07:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:07:55 --> Total execution time: 0.0065
DEBUG - 2016-06-30 16:08:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:08:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:21 --> Total execution time: 0.3294
DEBUG - 2016-06-30 16:08:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:08:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:42 --> Total execution time: 0.0070
DEBUG - 2016-06-30 16:08:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:08:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:08:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:49 --> Total execution time: 0.0074
DEBUG - 2016-06-30 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:08:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:08:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:08:59 --> Total execution time: 0.0080
DEBUG - 2016-06-30 16:09:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:09:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:09:17 --> Total execution time: 0.0082
DEBUG - 2016-06-30 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:09:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:09:26 --> Total execution time: 0.0067
DEBUG - 2016-06-30 16:10:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:10:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:10:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:03 --> Total execution time: 0.0079
DEBUG - 2016-06-30 16:10:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:10:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:10:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:18 --> Total execution time: 0.0084
DEBUG - 2016-06-30 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:10:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:24 --> Total execution time: 0.0074
DEBUG - 2016-06-30 16:10:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:10:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:10:31 --> Total execution time: 0.0075
DEBUG - 2016-06-30 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:11:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:11:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:14 --> Total execution time: 0.0092
DEBUG - 2016-06-30 16:11:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:11:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:11:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:22 --> Total execution time: 0.0066
DEBUG - 2016-06-30 16:11:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:11:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:11:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:11:40 --> Total execution time: 0.0073
DEBUG - 2016-06-30 16:12:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:12:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:15 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:12:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:12:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:34 --> Total execution time: 0.0043
DEBUG - 2016-06-30 16:12:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:12:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:12:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:41 --> Total execution time: 0.0048
DEBUG - 2016-06-30 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:12:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:12:46 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:13:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:13:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:13:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:04 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:13:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:13:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:13:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:15 --> Total execution time: 0.0071
DEBUG - 2016-06-30 16:13:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:13:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:32 --> Total execution time: 0.0065
DEBUG - 2016-06-30 16:13:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:13:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:13:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:13:49 --> Total execution time: 0.0052
DEBUG - 2016-06-30 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:14:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:12 --> Total execution time: 0.0115
DEBUG - 2016-06-30 16:14:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:14:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:14:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:23 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:14:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:31 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:14:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:14:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:14:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:14:54 --> Total execution time: 0.0054
DEBUG - 2016-06-30 16:15:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:15:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:20 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:15:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:15:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:42 --> Total execution time: 0.0052
DEBUG - 2016-06-30 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:15:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:15:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:15:54 --> Total execution time: 0.0059
DEBUG - 2016-06-30 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:16:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:16:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:16:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:16:08 --> Total execution time: 0.0072
DEBUG - 2016-06-30 16:16:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:16:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:16:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:16:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:16:18 --> Total execution time: 0.0087
DEBUG - 2016-06-30 16:17:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:17:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:17:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:09 --> Total execution time: 0.0064
DEBUG - 2016-06-30 16:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:17:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:17:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:28 --> Total execution time: 0.0056
DEBUG - 2016-06-30 16:17:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:17:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:17:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:17:42 --> Total execution time: 0.0043
DEBUG - 2016-06-30 16:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:18:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:03 --> Total execution time: 0.0051
DEBUG - 2016-06-30 16:18:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:18:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:18:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:17 --> Total execution time: 0.0040
DEBUG - 2016-06-30 16:18:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:18:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:18:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:34 --> Total execution time: 0.0059
DEBUG - 2016-06-30 16:18:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:18:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:18:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:40 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:18:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:18:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:18:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:18:52 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:19:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:19:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:19:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:06 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:19:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:19:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:16 --> Total execution time: 0.0068
DEBUG - 2016-06-30 16:19:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:19:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:19:27 --> Total execution time: 0.0042
DEBUG - 2016-06-30 16:20:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:06 --> Total execution time: 0.0072
DEBUG - 2016-06-30 16:20:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:26 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:35 --> Total execution time: 0.0043
DEBUG - 2016-06-30 16:20:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:47 --> Total execution time: 0.0040
DEBUG - 2016-06-30 16:20:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:53 --> Total execution time: 0.0040
DEBUG - 2016-06-30 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:20:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:20:59 --> Total execution time: 0.0044
DEBUG - 2016-06-30 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:28:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:28:25 --> Total execution time: 0.0046
DEBUG - 2016-06-30 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:28:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:28:42 --> Total execution time: 0.0042
DEBUG - 2016-06-30 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:29:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:29:08 --> Total execution time: 0.0043
DEBUG - 2016-06-30 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:29:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:29:57 --> Total execution time: 0.0045
DEBUG - 2016-06-30 16:31:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:31:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:00 --> Total execution time: 0.0058
DEBUG - 2016-06-30 16:31:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:31:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:31:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:10 --> Total execution time: 0.0051
DEBUG - 2016-06-30 16:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:31:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:31:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:39 --> Total execution time: 0.0076
DEBUG - 2016-06-30 16:31:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:31:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:31:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:31:56 --> Total execution time: 0.0067
DEBUG - 2016-06-30 16:32:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:32:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:32:17 --> hola
DEBUG - 2016-06-30 16:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:32:17 --> Total execution time: 0.0071
DEBUG - 2016-06-30 16:32:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:32:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:32:39 --> Total execution time: 0.0084
DEBUG - 2016-06-30 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-30 16:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-30 16:32:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-30 16:32:44 --> hola
DEBUG - 2016-06-30 16:32:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-30 16:32:44 --> Total execution time: 0.0058
