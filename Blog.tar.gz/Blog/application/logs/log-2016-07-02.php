<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 01:06:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 01:06:16 --> Total execution time: 0.0039
DEBUG - 2016-07-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:06:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:06:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:06:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:06:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:06:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:07:09 --> 404 Page Not Found: Project/CRegister/CRegister
DEBUG - 2016-07-02 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:07:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:07:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:07:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 01:07:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 01:07:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 01:07:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 01:07:29 --> Total execution time: 0.0038
DEBUG - 2016-07-02 01:07:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 01:07:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 01:07:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 01:07:44 --> Total execution time: 0.8034
DEBUG - 2016-07-02 01:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 01:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 01:17:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 01:17:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 01:17:36 --> Total execution time: 1.6825
DEBUG - 2016-07-02 02:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:05:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:05:21 --> Total execution time: 0.0045
DEBUG - 2016-07-02 02:05:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:05:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:05:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 02:05:37 --> Total execution time: 1.6815
DEBUG - 2016-07-02 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:06:53 --> Severity: Parsing Error --> syntax error, unexpected 'name' (T_STRING) /var/www/html/Blog/application/controllers/Project/CRegister.php 148
DEBUG - 2016-07-02 02:07:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:07:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:07:12 --> Total execution time: 0.0041
DEBUG - 2016-07-02 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:13 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:13 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:13 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:13 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:07:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:07:59 --> Total execution time: 0.0044
DEBUG - 2016-07-02 02:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:59 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:59 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:59 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:07:59 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:08:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:08:18 --> Total execution time: 0.0044
DEBUG - 2016-07-02 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:08:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:08:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:08:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:08:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:08:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:08:22 --> Total execution time: 0.0033
DEBUG - 2016-07-02 02:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:08:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:08:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 02:08:35 --> Total execution time: 1.6680
DEBUG - 2016-07-02 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:09:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:09:24 --> Total execution time: 0.0033
DEBUG - 2016-07-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:14:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:14:51 --> Total execution time: 0.0054
DEBUG - 2016-07-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:14:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:14:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:14:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:14:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:14:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:14:56 --> Total execution time: 0.0037
DEBUG - 2016-07-02 02:15:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:15:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:15:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 02:15:50 --> Total execution time: 1.8300
DEBUG - 2016-07-02 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:15:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:15:53 --> Total execution time: 0.0033
DEBUG - 2016-07-02 02:17:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:17:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:17:01 --> Total execution time: 0.0043
DEBUG - 2016-07-02 02:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:02 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:02 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:02 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:02 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:17:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:17:19 --> Unable to find validation rule: alpha_spaces
ERROR - 2016-07-02 02:17:19 --> Could not find the language line "form_validation_alpha_spaces"
DEBUG - 2016-07-02 02:17:19 --> Total execution time: 0.0051
DEBUG - 2016-07-02 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 02:17:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 02:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 02:17:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 02:17:28 --> Total execution time: 0.0035
DEBUG - 2016-07-02 03:17:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:17:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:17:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Vanegas' at line 1 - Invalid query: select * from Users where name = Carlos Vanegas
DEBUG - 2016-07-02 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:18:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:18:36 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:19:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:19:39 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:20:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:20:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:20:06 --> Severity: Parsing Error --> syntax error, unexpected 'name' (T_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:20:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:20:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:20:24 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:20:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:20:35 --> Total execution time: 0.0054
DEBUG - 2016-07-02 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:20:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:20:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:20:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:20:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:21:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:21:27 --> Total execution time: 0.0045
DEBUG - 2016-07-02 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:27 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:27 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:27 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:27 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:21:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:21:34 --> Total execution time: 0.0038
DEBUG - 2016-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:34 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:34 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:34 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:34 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:21:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:21:39 --> Total execution time: 0.0036
DEBUG - 2016-07-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:39 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:39 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:39 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:21:39 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:21:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:21:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:21:44 --> Total execution time: 0.0032
DEBUG - 2016-07-02 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:23:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:23:29 --> Total execution time: 0.0042
DEBUG - 2016-07-02 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:23:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:23:55 --> Total execution time: 0.0043
DEBUG - 2016-07-02 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:55 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:55 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:55 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:23:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:23:55 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:24:06 --> Total execution time: 0.0032
DEBUG - 2016-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:24:14 --> Total execution time: 0.0046
DEBUG - 2016-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:24:22 --> Total execution time: 0.0034
DEBUG - 2016-07-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:24:23 --> Total execution time: 0.0062
DEBUG - 2016-07-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:23 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-02 03:24:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:24:23 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:24:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:24:50 --> Query error: Unknown column 'Cvanegas' in 'where clause' - Invalid query: select * from Users where name = Cvanegas
DEBUG - 2016-07-02 03:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:26:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:26:06 --> Severity: Parsing Error --> syntax error, unexpected 'name' (T_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:26:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:26:19 --> Total execution time: 0.0051
DEBUG - 2016-07-02 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:19 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:26:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:26:33 --> Total execution time: 0.0033
DEBUG - 2016-07-02 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:26:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:26:46 --> Total execution time: 0.0045
DEBUG - 2016-07-02 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:46 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:46 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:46 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:26:46 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:26:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:26:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:26:49 --> Total execution time: 0.0033
DEBUG - 2016-07-02 03:27:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:27:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:27:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '["name"]' at line 1 - Invalid query: select * from Users where name = $data_array["name"]
DEBUG - 2016-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:28:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:28:51 --> Total execution time: 0.0058
DEBUG - 2016-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:28:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:28:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:28:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:28:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:31:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:31:44 --> Total execution time: 0.0033
DEBUG - 2016-07-02 03:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:31:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:31:48 --> Total execution time: 0.0035
DEBUG - 2016-07-02 03:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:31:49 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:31:49 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:31:49 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:31:49 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:32:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:32:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:32:57 --> Severity: Error --> Call to undefined function CONCAT() /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 03:36:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:36:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:36:04 --> Total execution time: 0.0050
DEBUG - 2016-07-02 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:36:05 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:36:05 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:36:05 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:36:05 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:36:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:36:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:36:30 --> Total execution time: 0.0032
DEBUG - 2016-07-02 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:36:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 03:36:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select * from Users where name = 
DEBUG - 2016-07-02 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 03:38:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 03:38:18 --> Total execution time: 0.0054
DEBUG - 2016-07-02 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:38:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:38:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:38:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 03:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 03:38:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:33:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:33:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:33:52 --> Total execution time: 0.4451
DEBUG - 2016-07-02 11:34:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:34:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:34:10 --> Total execution time: 0.0139
DEBUG - 2016-07-02 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:38:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:38:16 --> Total execution time: 0.0151
DEBUG - 2016-07-02 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:38:16 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-02 11:38:16 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-02 11:38:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:38:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:38:17 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:43:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:43:35 --> Total execution time: 0.0101
DEBUG - 2016-07-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:43:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:43:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:43:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:43:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:43:35 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:44:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:44:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:44:16 --> Total execution time: 0.0068
DEBUG - 2016-07-02 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:44:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:44:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:44:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:44:16 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:44:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:44:26 --> Total execution time: 0.0107
DEBUG - 2016-07-02 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:45:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 11:45:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '["name"]' at line 1 - Invalid query: select * from Users where name = $data_array["name"]
DEBUG - 2016-07-02 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:45:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:45:52 --> Total execution time: 0.0139
DEBUG - 2016-07-02 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:45:52 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-02 11:45:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:45:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:45:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:45:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:47:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:47:28 --> Total execution time: 0.0034
DEBUG - 2016-07-02 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:47:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 11:47:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Flores' at line 1 - Invalid query: select * from Users where name = Roberto Flores
DEBUG - 2016-07-02 11:48:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:48:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 11:48:30 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 36
DEBUG - 2016-07-02 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:50:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:50:17 --> Total execution time: 0.0082
DEBUG - 2016-07-02 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:50:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:50:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:50:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:50:18 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:51:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:51:58 --> Total execution time: 0.0065
DEBUG - 2016-07-02 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 11:52:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 11:52:09 --> Total execution time: 0.0061
DEBUG - 2016-07-02 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:52:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:52:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:52:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 11:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 11:52:09 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:52:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:52:43 --> Total execution time: 0.0044
DEBUG - 2016-07-02 14:54:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:54:13 --> Severity: Parsing Error --> syntax error, unexpected '$email2' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 89
DEBUG - 2016-07-02 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:54:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:54:37 --> Total execution time: 0.0044
DEBUG - 2016-07-02 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:54:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:54:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:54:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:54:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:55:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 14:55:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`Carlos`' at line 3 - Invalid query: SELECT *
FROM `Users`
WHERE `name` = `Roberto` `Carlos`
DEBUG - 2016-07-02 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:55:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:55:40 --> Total execution time: 0.0086
DEBUG - 2016-07-02 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:55:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:55:57 --> Total execution time: 0.0045
DEBUG - 2016-07-02 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:55:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:55:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:55:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:55:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:55:57 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:56:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:56:36 --> Total execution time: 0.0037
DEBUG - 2016-07-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:57:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:57:03 --> Total execution time: 0.0043
DEBUG - 2016-07-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:03 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:03 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:03 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:03 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:57:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:57:29 --> Total execution time: 0.0038
DEBUG - 2016-07-02 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:57:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:57:48 --> Total execution time: 0.0089
DEBUG - 2016-07-02 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:57:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:57:50 --> Total execution time: 0.0033
DEBUG - 2016-07-02 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 14:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 14:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 14:58:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 14:58:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-02 14:58:26 --> Total execution time: 1.9385
DEBUG - 2016-07-02 17:26:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:26:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 17:26:48 --> Total execution time: 0.0041
DEBUG - 2016-07-02 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:26:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-02 17:26:50 --> Total execution time: 0.0031
DEBUG - 2016-07-02 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 17:26:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 17:26:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 17:26:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-02 17:26:50 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-02 17:27:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:27:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 17:27:36 --> Query error: Unknown column 'Vicente' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `name` = `Vicente`
DEBUG - 2016-07-02 17:28:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:28:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 17:28:16 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/models/Project/Mregister.php 40
DEBUG - 2016-07-02 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:28:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 17:28:33 --> Severity: Parsing Error --> syntax error, unexpected 'name' (T_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 40
DEBUG - 2016-07-02 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-02 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-02 17:28:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-02 17:28:43 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Vicente', 'chente1', 'chenteV', 'demovanegas@hotmail.com')
