<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-05 09:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:40:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:40:51 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:52 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:54 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:08:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:08:48 --> Could not find the language line "Duplicated key"
DEBUG - 2016-07-05 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:10:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:10:05 --> Total execution time: 0.0038
DEBUG - 2016-07-05 10:12:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:12:58 --> 404 Page Not Found: Project/Start_session/index
DEBUG - 2016-07-05 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:32 --> 404 Page Not Found: Project/Start_session/index
DEBUG - 2016-07-05 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:35 --> Total execution time: 0.0073
DEBUG - 2016-07-05 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:52 --> Total execution time: 0.0034
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:54 --> Total execution time: 0.0064
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:14:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:14:02 --> Total execution time: 0.0050
DEBUG - 2016-07-05 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:14:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:14:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/controllers/Project/CRegister.php 87
DEBUG - 2016-07-05 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:22:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:22:40 --> Total execution time: 0.0081
DEBUG - 2016-07-05 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:22:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:22:45 --> Total execution time: 0.0034
DEBUG - 2016-07-05 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:23:12 --> Could not find the language line ""
DEBUG - 2016-07-05 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:23:37 --> Could not find the language line "Duplicated key for username"
DEBUG - 2016-07-05 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:23:38 --> Total execution time: 0.0032
DEBUG - 2016-07-05 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:24:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:24:04 --> Could not find the language line "Duplicated key for username"
DEBUG - 2016-07-05 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:05 --> Total execution time: 0.0047
DEBUG - 2016-07-05 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:32:05 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/html/Blog/application/controllers/Project/Admin/Mail.php 3
DEBUG - 2016-07-05 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:07 --> Total execution time: 0.0033
DEBUG - 2016-07-05 10:32:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:08 --> Total execution time: 0.0042
DEBUG - 2016-07-05 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:32:28 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlitos', 'chente1', 'chente2', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 10:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:37:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:37:35 --> Total execution time: 0.0038
