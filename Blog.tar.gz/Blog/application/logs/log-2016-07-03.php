<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-03 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:37:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:37:48 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Vicente', 'chente1', 'chenteV', 'demovanegas@hotmail.com')
DEBUG - 2016-07-03 11:38:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:38:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-03 11:38:09 --> Total execution time: 0.0052
DEBUG - 2016-07-03 11:40:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:40:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:40:42 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlillos', 'chente1', 'chente2', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-03 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:40:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-03 11:40:56 --> Total execution time: 0.0033
DEBUG - 2016-07-03 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:41:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:41:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 3 - Invalid query: SELECT *
FROM `Users`
WHERE `name` = .`$data_array["name"]`
DEBUG - 2016-07-03 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:45:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:45:15 --> Query error: Duplicate entry 'chentev1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlillos', 'chentev1', 'chentev', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-03 11:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:45:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-03 11:45:24 --> Total execution time: 0.0032
DEBUG - 2016-07-03 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:45:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:45:39 --> Query error: Unknown column 'Carlillos' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `name` = `Carlillos`
DEBUG - 2016-07-03 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:47:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:47:38 --> Severity: Notice --> Use of undefined constant name - assumed 'name' /var/www/html/Blog/application/models/Project/Mregister.php 30
ERROR - 2016-07-03 11:47:38 --> Query error: Duplicate entry 'chentev12' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlillos', 'chentev12', 'chente12', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-03 11:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:48:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:48:35 --> Query error: Duplicate entry 'chentev12' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlillos', 'chentev12', 'chente12', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-03 11:48:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:48:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-03 11:48:41 --> Total execution time: 0.0034
DEBUG - 2016-07-03 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 11:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 11:49:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 11:49:09 --> Query error: Unknown column 'Carlillos' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `name` = `Carlillos`
DEBUG - 2016-07-03 12:14:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-03 12:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-03 12:14:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-03 12:14:13 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
