<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-06-28 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:39:23 --> Total execution time: 0.0039
DEBUG - 2016-06-28 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:39:38 --> Severity: Error --> Call to undefined method Mregister::open_session() /var/www/html/Blog/application/controllers/Project/CRegister.php 102
DEBUG - 2016-06-28 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:40:12 --> Total execution time: 0.0645
DEBUG - 2016-06-28 09:41:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:41:58 --> Total execution time: 0.0038
DEBUG - 2016-06-28 09:41:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:41:59 --> Total execution time: 0.0041
DEBUG - 2016-06-28 09:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:43:04 --> Total execution time: 0.0032
DEBUG - 2016-06-28 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:44:37 --> Total execution time: 0.1139
DEBUG - 2016-06-28 09:46:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:46:16 --> Total execution time: 0.0031
DEBUG - 2016-06-28 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:47:43 --> Total execution time: 0.0039
DEBUG - 2016-06-28 09:47:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:47:59 --> Total execution time: 0.1065
DEBUG - 2016-06-28 09:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:48:06 --> Total execution time: 0.0032
DEBUG - 2016-06-28 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:49:26 --> Total execution time: 0.0039
DEBUG - 2016-06-28 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:49:40 --> Severity: Notice --> Array to string conversion /var/www/html/Blog/application/controllers/Project/CRegister.php 110
DEBUG - 2016-06-28 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:49:40 --> 404 Page Not Found: Project/Ci_session/active
DEBUG - 2016-06-28 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:49:54 --> Total execution time: 0.0037
DEBUG - 2016-06-28 09:49:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:49:58 --> Total execution time: 0.0031
DEBUG - 2016-06-28 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:50:02 --> Total execution time: 0.0032
DEBUG - 2016-06-28 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:50:09 --> Severity: Notice --> Array to string conversion /var/www/html/Blog/application/controllers/Project/CRegister.php 110
DEBUG - 2016-06-28 09:50:09 --> Total execution time: 0.0572
DEBUG - 2016-06-28 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:50:48 --> Severity: Notice --> Array to string conversion /var/www/html/Blog/application/controllers/Project/CRegister.php 111
DEBUG - 2016-06-28 09:50:48 --> Total execution time: 0.0638
DEBUG - 2016-06-28 09:51:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 112
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 113
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 112
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 113
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 112
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 113
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 112
ERROR - 2016-06-28 09:51:49 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 113
DEBUG - 2016-06-28 09:51:49 --> Total execution time: 0.0664
DEBUG - 2016-06-28 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:52:18 --> Total execution time: 0.0642
DEBUG - 2016-06-28 09:52:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:52:30 --> Total execution time: 0.0673
DEBUG - 2016-06-28 09:53:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:53:10 --> Total execution time: 0.0612
DEBUG - 2016-06-28 09:58:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:58:16 --> Total execution time: 0.0038
DEBUG - 2016-06-28 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:58:17 --> Total execution time: 0.0029
DEBUG - 2016-06-28 09:58:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 09:58:33 --> Severity: Notice --> Undefined index: user_data /var/www/html/Blog/application/controllers/Project/CRegister.php 111
DEBUG - 2016-06-28 09:58:33 --> Total execution time: 0.1149
DEBUG - 2016-06-28 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 09:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 09:58:49 --> Total execution time: 0.0569
DEBUG - 2016-06-28 10:00:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:00:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:00:15 --> Severity: Notice --> Undefined index: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 113
DEBUG - 2016-06-28 10:00:15 --> Total execution time: 0.0618
DEBUG - 2016-06-28 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:00:31 --> Total execution time: 0.0522
DEBUG - 2016-06-28 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:00:47 --> Total execution time: 0.0530
DEBUG - 2016-06-28 10:02:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:02:42 --> Severity: Parsing Error --> syntax error, unexpected 'Project' (T_STRING), expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 115
DEBUG - 2016-06-28 10:02:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:02:58 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/Blog/application/controllers/Project/CRegister.php 115
DEBUG - 2016-06-28 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:03:05 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/Blog/application/controllers/Project/CRegister.php 115
DEBUG - 2016-06-28 10:03:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:03:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:03:51 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 121
DEBUG - 2016-06-28 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:04:18 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 125
DEBUG - 2016-06-28 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:04:24 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 127
DEBUG - 2016-06-28 10:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:04:28 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 128
DEBUG - 2016-06-28 10:04:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:04:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:04:33 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 130
DEBUG - 2016-06-28 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:04:37 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 138
DEBUG - 2016-06-28 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:07:07 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 115
DEBUG - 2016-06-28 10:09:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:09:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:09:45 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' /var/www/html/Blog/application/controllers/Project/CRegister.php 115
DEBUG - 2016-06-28 10:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:09:57 --> Total execution time: 0.0646
DEBUG - 2016-06-28 10:10:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:10:18 --> Total execution time: 0.0627
DEBUG - 2016-06-28 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:10:26 --> Total execution time: 0.0685
DEBUG - 2016-06-28 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:10:29 --> 404 Page Not Found: Project/CRegister/Project
DEBUG - 2016-06-28 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:10:29 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:10:29 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:10:29 --> 404 Page Not Found: Project/Assets/css
ERROR - 2016-06-28 10:10:29 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:10:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:10:33 --> Total execution time: 0.0782
DEBUG - 2016-06-28 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:10:35 --> Total execution time: 0.0030
DEBUG - 2016-06-28 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:19:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 10:19:39 --> Total execution time: 0.4935
DEBUG - 2016-06-28 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:20:54 --> Total execution time: 0.1592
DEBUG - 2016-06-28 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:31:21 --> Total execution time: 0.0042
DEBUG - 2016-06-28 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:31:32 --> Total execution time: 0.1277
DEBUG - 2016-06-28 10:31:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:31:42 --> 404 Page Not Found: Project/CRegister/Project
DEBUG - 2016-06-28 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:31:43 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:31:43 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:31:43 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 10:31:43 --> 404 Page Not Found: Project/Assets/css
DEBUG - 2016-06-28 10:31:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 10:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 10:31:47 --> Total execution time: 0.0100
DEBUG - 2016-06-28 12:08:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:08:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:08:10 --> Total execution time: 0.4655
DEBUG - 2016-06-28 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:08:14 --> Total execution time: 0.0033
DEBUG - 2016-06-28 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:08:40 --> Total execution time: 0.0084
DEBUG - 2016-06-28 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:08:42 --> Total execution time: 0.0033
DEBUG - 2016-06-28 12:09:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:12:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:14:31 --> Total execution time: 0.0043
DEBUG - 2016-06-28 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:16:29 --> Total execution time: 0.0032
DEBUG - 2016-06-28 12:16:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:16:36 --> 404 Page Not Found: Project/Ci_session/index
DEBUG - 2016-06-28 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:17:02 --> 404 Page Not Found: Project/Ci_session/index
DEBUG - 2016-06-28 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:19:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:19:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:22:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:22:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:22:46 --> Total execution time: 0.0120
DEBUG - 2016-06-28 12:23:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:23:15 --> Total execution time: 0.0042
DEBUG - 2016-06-28 12:23:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:23:16 --> Total execution time: 0.0035
DEBUG - 2016-06-28 12:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:23:17 --> Total execution time: 0.0030
DEBUG - 2016-06-28 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:23:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:25:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:25:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:25:07 --> 404 Page Not Found: Project/CI_session/index
DEBUG - 2016-06-28 12:25:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:25:33 --> 404 Page Not Found: Project/CI_session/index
DEBUG - 2016-06-28 12:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:25:48 --> 404 Page Not Found: Project/CI_session/index
DEBUG - 2016-06-28 12:28:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:30 --> Total execution time: 0.0041
DEBUG - 2016-06-28 12:29:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:29:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:32:28 --> Total execution time: 0.0033
DEBUG - 2016-06-28 12:32:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:32:54 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/html/Blog/application/controllers/Project/Ci_session.php 18
DEBUG - 2016-06-28 12:33:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:33:02 --> Total execution time: 0.0034
DEBUG - 2016-06-28 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:33:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 11
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 11
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 13
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 13
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 14
ERROR - 2016-06-28 12:33:58 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 14
DEBUG - 2016-06-28 12:33:58 --> Total execution time: 0.0047
DEBUG - 2016-06-28 12:40:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-06-28 12:40:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 11
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 11
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 13
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 13
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Undefined property: CI_Loader::$session /var/www/html/Blog/application/views/Project/account.php 14
ERROR - 2016-06-28 12:40:25 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/views/Project/account.php 14
DEBUG - 2016-06-28 12:40:25 --> Total execution time: 0.0078
DEBUG - 2016-06-28 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:40:40 --> 404 Page Not Found: Project/CRgister/my_register
DEBUG - 2016-06-28 12:40:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:40:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:40:48 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/Blog/application/controllers/Project/CRegister.php 105
DEBUG - 2016-06-28 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:41:36 --> Total execution time: 0.0068
DEBUG - 2016-06-28 12:41:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:41:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:41:50 --> 404 Page Not Found: Project/CRgister/index
DEBUG - 2016-06-28 12:42:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:42:32 --> Total execution time: 0.0066
DEBUG - 2016-06-28 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:52:45 --> 404 Page Not Found: Project/My_register/index
DEBUG - 2016-06-28 12:53:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:53:22 --> Total execution time: 0.0039
DEBUG - 2016-06-28 12:53:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:53:23 --> Total execution time: 0.0048
DEBUG - 2016-06-28 12:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:53:45 --> Total execution time: 0.0055
DEBUG - 2016-06-28 12:54:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:54:23 --> Total execution time: 0.0036
DEBUG - 2016-06-28 12:54:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:54:31 --> Severity: Error --> Call to undefined function start_session() /var/www/html/Blog/application/controllers/Project/CRegister.php 61
DEBUG - 2016-06-28 12:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 12:54:59 --> Severity: Error --> Call to undefined function start_session() /var/www/html/Blog/application/controllers/Project/CRegister.php 97
DEBUG - 2016-06-28 12:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 12:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 12:55:25 --> Total execution time: 0.0465
DEBUG - 2016-06-28 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 13:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 13:25:53 --> Total execution time: 0.0033
DEBUG - 2016-06-28 13:27:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 13:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 13:27:25 --> Total execution time: 0.0689
DEBUG - 2016-06-28 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 13:33:31 --> Total execution time: 0.0036
DEBUG - 2016-06-28 14:44:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 14:44:43 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/Blog/application/controllers/Project/CRegister.php 151
DEBUG - 2016-06-28 14:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 14:44:57 --> Severity: Notice --> Undefined offset: 2 /var/www/html/Blog/application/controllers/Project/CRegister.php 151
DEBUG - 2016-06-28 14:44:57 --> Total execution time: 0.0050
DEBUG - 2016-06-28 14:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 14:46:00 --> Severity: Notice --> Undefined offset: 2 /var/www/html/Blog/application/controllers/Project/CRegister.php 151
DEBUG - 2016-06-28 14:46:00 --> Total execution time: 0.0048
DEBUG - 2016-06-28 14:46:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 14:46:22 --> Severity: Notice --> Undefined index: gmail.com /var/www/html/Blog/application/controllers/Project/CRegister.php 151
DEBUG - 2016-06-28 14:46:22 --> Total execution time: 0.0043
DEBUG - 2016-06-28 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 14:49:33 --> Total execution time: 0.0043
DEBUG - 2016-06-28 14:49:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 14:49:57 --> Total execution time: 0.0037
DEBUG - 2016-06-28 14:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 14:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 14:51:08 --> Total execution time: 0.0041
DEBUG - 2016-06-28 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:00:48 --> Severity: Parsing Error --> syntax error, unexpected 'break' (T_BREAK) /var/www/html/Blog/application/controllers/Project/CRegister.php 164
DEBUG - 2016-06-28 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:01:08 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/Blog/application/controllers/Project/CRegister.php 167
DEBUG - 2016-06-28 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:01:10 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/Blog/application/controllers/Project/CRegister.php 167
DEBUG - 2016-06-28 15:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:01:23 --> Total execution time: 0.0043
DEBUG - 2016-06-28 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:02:09 --> Total execution time: 0.0048
DEBUG - 2016-06-28 15:02:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:02:11 --> Total execution time: 0.0030
DEBUG - 2016-06-28 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
ERROR - 2016-06-28 15:03:11 --> Severity: Notice --> Undefined variable: cadena /var/www/html/Blog/application/controllers/Project/CRegister.php 131
DEBUG - 2016-06-28 15:03:11 --> Total execution time: 0.0530
DEBUG - 2016-06-28 15:03:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:03:30 --> Total execution time: 0.0048
DEBUG - 2016-06-28 15:03:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:03:39 --> Total execution time: 0.0031
DEBUG - 2016-06-28 15:07:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:07:27 --> Total execution time: 0.0050
DEBUG - 2016-06-28 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:07:50 --> Total execution time: 0.0038
DEBUG - 2016-06-28 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:07:57 --> Total execution time: 0.0031
DEBUG - 2016-06-28 15:09:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:09:20 --> Total execution time: 0.0043
DEBUG - 2016-06-28 15:09:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:09:39 --> Total execution time: 0.0033
DEBUG - 2016-06-28 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:10:49 --> Total execution time: 0.0041
DEBUG - 2016-06-28 15:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:09 --> Total execution time: 0.0042
DEBUG - 2016-06-28 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:11 --> Total execution time: 0.0033
DEBUG - 2016-06-28 15:11:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:29 --> Total execution time: 0.0034
DEBUG - 2016-06-28 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:32 --> Total execution time: 0.0032
DEBUG - 2016-06-28 15:11:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:54 --> Total execution time: 0.0035
DEBUG - 2016-06-28 15:11:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:11:56 --> Total execution time: 0.0030
DEBUG - 2016-06-28 15:14:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:14:47 --> Total execution time: 0.0041
DEBUG - 2016-06-28 15:22:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:22:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:22:28 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/Blog/application/controllers/Project/CRegister.php 84
DEBUG - 2016-06-28 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:22:50 --> Total execution time: 0.0048
DEBUG - 2016-06-28 15:22:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:22:59 --> Total execution time: 0.0032
DEBUG - 2016-06-28 15:23:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:23:54 --> Total execution time: 0.0032
DEBUG - 2016-06-28 15:24:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:24:17 --> Total execution time: 0.0113
DEBUG - 2016-06-28 15:24:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:24:57 --> Total execution time: 0.0032
DEBUG - 2016-06-28 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:25:15 --> Total execution time: 0.0108
DEBUG - 2016-06-28 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:25:17 --> Total execution time: 0.0031
DEBUG - 2016-06-28 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:25:27 --> Total execution time: 0.0036
DEBUG - 2016-06-28 15:25:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:25:35 --> Total execution time: 0.0032
DEBUG - 2016-06-28 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:25:43 --> Total execution time: 0.0035
DEBUG - 2016-06-28 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:36:13 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/Blog/application/controllers/Project/CRegister.php 38
DEBUG - 2016-06-28 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:36:16 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/Blog/application/controllers/Project/CRegister.php 38
DEBUG - 2016-06-28 15:36:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:36:43 --> Total execution time: 0.0036
DEBUG - 2016-06-28 15:37:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:37:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:37:01 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 116
DEBUG - 2016-06-28 15:37:01 --> Total execution time: 0.0043
DEBUG - 2016-06-28 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:38:28 --> Total execution time: 0.0139
DEBUG - 2016-06-28 15:38:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:38:45 --> Total execution time: 0.0051
DEBUG - 2016-06-28 15:39:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:39:26 --> Total execution time: 0.0059
DEBUG - 2016-06-28 15:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:41:10 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/Blog/application/controllers/Project/CRegister.php 41
DEBUG - 2016-06-28 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:41:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:41:11 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/Blog/application/controllers/Project/CRegister.php 41
DEBUG - 2016-06-28 15:41:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 15:41:21 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/CRegister.php 41
DEBUG - 2016-06-28 15:41:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:41:35 --> Total execution time: 0.0240
DEBUG - 2016-06-28 15:42:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:42:08 --> Total execution time: 0.0073
DEBUG - 2016-06-28 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:57:05 --> Total execution time: 0.0044
DEBUG - 2016-06-28 15:57:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 15:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 15:57:09 --> Total execution time: 0.0034
DEBUG - 2016-06-28 16:00:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:00:27 --> Total execution time: 0.0041
DEBUG - 2016-06-28 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:00:51 --> Total execution time: 0.0036
DEBUG - 2016-06-28 16:11:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:11:45 --> Total execution time: 0.0033
DEBUG - 2016-06-28 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:15:07 --> Total execution time: 0.0092
DEBUG - 2016-06-28 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:15:28 --> Total execution time: 0.0035
DEBUG - 2016-06-28 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 16:21:49 --> Severity: Parsing Error --> syntax error, unexpected '.0' (T_DNUMBER) /var/www/html/Blog/application/controllers/Project/CRegister.php 41
DEBUG - 2016-06-28 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:21:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 16:21:50 --> Severity: Parsing Error --> syntax error, unexpected '.0' (T_DNUMBER) /var/www/html/Blog/application/controllers/Project/CRegister.php 41
DEBUG - 2016-06-28 16:22:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:22:11 --> Total execution time: 0.0044
DEBUG - 2016-06-28 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:22:28 --> Total execution time: 0.0044
DEBUG - 2016-06-28 16:27:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:27:18 --> Total execution time: 0.0044
DEBUG - 2016-06-28 16:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:27:20 --> Total execution time: 0.0030
DEBUG - 2016-06-28 16:27:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:27:33 --> Total execution time: 0.0047
DEBUG - 2016-06-28 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:34:28 --> Total execution time: 0.0917
DEBUG - 2016-06-28 16:36:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-28 16:36:48 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) /var/www/html/Blog/application/controllers/Project/CRegister.php 47
DEBUG - 2016-06-28 16:37:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:37:13 --> Total execution time: 0.0040
DEBUG - 2016-06-28 16:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:37:23 --> Total execution time: 0.0042
DEBUG - 2016-06-28 16:37:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:37:30 --> Total execution time: 0.0040
DEBUG - 2016-06-28 16:38:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:38:35 --> Total execution time: 0.0045
DEBUG - 2016-06-28 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:38:36 --> Total execution time: 0.0030
DEBUG - 2016-06-28 16:38:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:38:38 --> Total execution time: 0.0033
DEBUG - 2016-06-28 16:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:38:58 --> Total execution time: 0.0037
DEBUG - 2016-06-28 16:43:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:43:18 --> Total execution time: 0.0042
DEBUG - 2016-06-28 16:43:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:43:27 --> Total execution time: 0.0591
DEBUG - 2016-06-28 16:46:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:46:39 --> Total execution time: 0.0042
DEBUG - 2016-06-28 16:46:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:46:40 --> Total execution time: 0.0030
DEBUG - 2016-06-28 16:47:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:47:05 --> Total execution time: 0.0093
DEBUG - 2016-06-28 16:47:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:47:17 --> Total execution time: 0.0032
DEBUG - 2016-06-28 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:48:07 --> Total execution time: 0.1017
DEBUG - 2016-06-28 16:48:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 16:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 16:48:56 --> Total execution time: 0.0035
DEBUG - 2016-06-28 17:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 17:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 17:13:52 --> Total execution time: 0.1738
DEBUG - 2016-06-28 17:15:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 17:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 17:15:41 --> Total execution time: 0.0079
DEBUG - 2016-06-28 17:19:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-28 17:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-28 17:19:50 --> Total execution time: 0.0109
