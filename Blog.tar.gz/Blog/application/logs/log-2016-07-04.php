<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-04 14:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-04 14:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-04 14:37:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-04 14:37:12 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-04 14:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-04 14:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-04 14:37:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-04 14:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-04 14:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-04 14:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-04 14:37:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-04 14:37:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-04 14:37:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-04 14:37:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-04 14:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-04 14:37:13 --> 404 Page Not Found: Assets/css
