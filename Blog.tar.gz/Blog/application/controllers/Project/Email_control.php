<?php 
/**
* 
*/
class Email_control extends CI_Controller
{
	

	public function index()
	{
		$this->load->library('email');

		$this->email->from('cvanegashdz@gmail.com', 'Carlos Vanegas');
		$this->email->to('drummerphantom@gmail.com');
		#$this->email->cc('another@another-example.com');
		#$this->email->bcc('them@their-example.com');

		$this->email->subject('Email Test');
		$this->email->message('Testing the email class.');

		if($this->email->send())
		{
			echo "Email sent";
		}
		else
		{
			echo "Email failure";
		}
	}
}
?>