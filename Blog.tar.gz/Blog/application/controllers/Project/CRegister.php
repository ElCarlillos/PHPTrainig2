<html>
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.min.css">
</html>


<?php 
/**
* 
*/
class CRegister extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Project/Mregister');
	}
    
	
	function index()
	{
		if($this->session->userdata('active') !== NULL)
		{
			if ($this->session->userdata('active') === 0) {
				//Show error popup
				$this->load->view('Tuto/register');	
			}
			elseif($this->session->userdata('active') === 1)
			{
				$this->load->view('Project/Admin views/member_view');
			}
		}else
		{
			$this->load->view('Tuto/register');
		}
		

		
	}

	public function login()
	{
		echo "Vista de login";
	}

	public function start_session()
	{

		$name = $this->input->post('name');
		$username = $this->input->post('username');
		$pass = $this->input->post('password');
		$conf_pass = $this->input->post('confPass');
		$email = $this->input->post('email');

						$array = array('name' => $name,
				'username' => $username,
				'password' => $pass,
				'email' => $email,
				'active' => NULL,
				'logged in' => 0);
		$this->form_validation->set_data($array);
		$this->form_validation->set_rules('name', 'Nombre', 'required|trim|alpha_numeric_spaces');
		$this->form_validation->set_rules('username', 'Nombre de usuario', 'required|alpha_numeric|min_length[6]|max_length[14]');
		$this->form_validation->set_rules('password', 'Contraseña', 'required|alpha_numeric|min_length[6]|max_length[14]');
		$this->form_validation->set_rules('confPass', 'Confirmar contraseña', 'matches[password]');
		$this->form_validation->set_rules('email', 'Correo electronico', 'required|valid_email');

		if ($this->form_validation->run() === FALSE) 
		{	
			//La validacion fallo, los campos no cumplen las condiciones 
			//Redireccionar al usuario a la misma pagian y mostra los errores
			$error = validation_errors();
			echo $error;
			$this->load->view('Tuto/register');

		}
		else
		{
			//Las condiciones del form validation se cumplieron.
			//Ahora se debe verificar si el usuario existe en la base de datos
			$sql = $this->db->query("select * from Users where username = '$username'");
			
			
			if ($this->Mregister->insert_users($array) !== FALSE) {
				$this->session->set_userdata($array);
				$email2 = $this->input->post('email');
				

				$this->load->view('Project/Admin views/Prompt', $email2);

				$this->load->library('email');
			 


         
				$config = Array(
				    'protocol' => 'smtp',
				    'smtp_host' => 'ssl://smtp.googlemail.com',
				    'smtp_port' => 465,
				    'smtp_user' => 'cvanegashdz@gmail.com',
				    'smtp_pass' => 'carlos12050857',
				    'mailtype'  => 'html', 
				    'charset'   => 'iso-8859-1'
				);
				$this->load->library('email', $config);
				$this->email->set_newline("\r\n");

				

	            $this->email->initialize($config);


	            $this->email->from('cvanegashdz@gmail.com', 'Carlos Vanegas from platzi');
	            $this->email->to($email2); 


	            $this->email->subject('Email Test');

	            $this->email->message('Thanks '.$name.' for registering at LaBanda.com
	            						Now all that you have to do is click at the link below to activate your account ' 
	            						.'<a href="Project/Admin views/member_view.php">Activate account</a>');  


	            $this->email->send();
			}
			else
			{
				$this->load->view('Tuto/register');
				echo "There are duplicated keys";
			}
				
			
				
	
			
			
            


		}


							
	}


	public function send_email()
	{
		return TRUE;
	}


	function prompt_user($name, $uname, $pass, $email)
	{

		$array = 
		array(
			'name' => $name,
			'username' => $uname,
			'password' => $pass,
			'email' => $email,
			'active' => 0
			);
				if ($this->db->get('Users') !== NULL) {
							
							$this->session->set_userdata($array);	
						if($this->session->userdata['active'] === 0){

							
							echo "<p>Enhorabuena, tu usario fue registrado!!!</p>";
							echo "<br>";
							echo "Tu nombre: ".$this->session->userdata['name'];
							echo "<br>";
							echo "Tu nombre de usuario: ".$this->session->userdata['username'];
							echo "Hemos enviado un correo a la direccion ".$this->session->userdata['email']."<br>debes hacer click en el enlace para activar tu cuenta";
													
						}
						elseif ($this->session->userdata['active'] === 1)
							{
								echo "Vista de cuenta activada";
								redirect();//Pagina de usuario registrado 
							}
							

				}
	}
		

	public function my_register()	
	{

		$name = $this->input->post('name');
		$uname = $this->input->post('username');
		$pass = $this->input->post('password');
		$email = $this->input->post('email');



			
			$this->load->library('form_validation');
			$data = array(
				'name' 		=> 	$name,
				'username' 	=>	$uname, 	
				'password' 	=> 	$pass,
				'email'		=> 	$email);
			$this->form_validation->set_data($data);
			$this->form_validation->set_rules('name', 'name', 'required|alpha');
			$this->form_validation->set_rules('username', 'uname','required|is_unique[Users.username]|min_length[6]|max_length[14]|alpha_numeric');
			$this->form_validation->set_rules('password', 'pass','required|min_length[6]|max_length[14]|alpha_numeric');
			$this->form_validation->set_rules('email', 'email', 'required|valid_email');





		if ($this->form_validation->run() === FALSE) 
		{ 
			
			
			
			#echo $this->MLogin->pass_not_empty($pass);
			#echo $this->MLogin->check_length($pass,6, 3);
			#echo $this->MLogin->is_numeric($uname);				
			echo validation_errors();
			
		}
	}

	

}		

 ?>


