<?php 
/**
* 
*/
class Home extends CI_Controller
{
	private $logged_in;

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('logged_in'))
			$this->logged_in = TRUE;
		else
		{
			$this->logged_in = FALSE;
		}
	}


	public function index()
	{
		$this->load->view('home/view_home',array('logged_in' => $this->logged_in));
	}
}
 ?>