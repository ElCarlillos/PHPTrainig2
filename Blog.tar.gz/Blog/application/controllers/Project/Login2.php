<?php 

/**
* 
*/
class Login2 extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		
	}
	
	// function index()
	// {
	// 	$this->load->view('Project/Login view');
	// 	$this->load->library('form_validation');
	// }

	public function validar()
	{
				
			$this->form_validation->set_rules('username','U','required');
			$this->form_validation->set_rules('pass','P','required');

			if($this->form_validation->run() == FALSE)
			{
				echo validation_errors();
				echo '<head>';
				echo '<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.css">';
				echo '<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.min.css">';
				echo '<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.css">';
				echo '<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.min.css">';
				echo '</head>';
				echo '<div class="alert alert-danger" style ="width:300px;"';
				echo '<span class="alert alert-danger">';
				echo '<p style="padding-bottom:20px;">Username and password required</p>';
				echo '</span>';
				echo '</div>';
				
				
			}
			
	
	}	

	public function error()
	{
		$this->form_validation->set_message("Username and password are required");
		$this->load->view('Project/Login view');
	}

	public function Login()	
	{
		$u = $this->input->post('username');
		$p = $this->input->post('pass');
		$var = $this->MLogin->checLogin($u,$p);

		switch ($var) {
			case 'Success':
				echo "La contraseña no coincide";
				break;
			case 'Carlos':
				echo "Nombre: Carlos";
				break;
			default: 
				echo 'Fracaso';
				break;
			
		}

	}


}

?>
