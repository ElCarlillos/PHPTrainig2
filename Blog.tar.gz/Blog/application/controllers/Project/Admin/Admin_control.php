<?php 
/**
* 
*/
class Admin_control extends CI_Controller
{
	public function manageLogin()
	{
		if (active === 1 && logged_in === 1) {
			
		}
	}
	
}
 ?>