<?php 
/**
* 
*/
class ClassName extends CI_Controller
{
	
	function __construct(argument)
	{
				
	}

	function zone()
	{
		#parent::Controller();
		$this->load->helper("url");
		$this->load->helper("form");
		$this->load->helper('file');
		$this->load->database();
		$this->load->helper('date');
	}

	function index()
	{
		$this->load->view('index');		
	}

	function login_pwd()
	{
		if(isset($_POST["user_name"])){
		$user_name=$_POST["user_name"];
		$valid='TRUE';
		$data["check_name"]=$this->db->query("SELECT*FROM
		user_account WHERE user_name='$user_name'");
		if($data["check_name"]->num_rows() > 0){
 			echo "true";
		}
			25
	else{
			echo "false";
		}
		}
	}
}
?>