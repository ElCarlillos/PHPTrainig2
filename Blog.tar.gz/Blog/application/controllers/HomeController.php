<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* CONTROLADOR DE LA VISTA DE REGISTRO Y LOGIN
*/
class HomeController extends CI_Controller
{
    

    
    public function index()
    {


        $this->load->model('Blog_model');
        
        $this->load->helper(array('form','url'));        

        
    }

    public function login()
    {

            
            $this->load->library('form_validation');            
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run() === FALSE) {                
                echo validation_errors();
                
            }
            else
            {                
                
                $this->load->model('user_model1'):
                if($this->user_model1->login($this->input->post('username'),$this->input->post('password')))
                   {
                        $this->load->view('main_blog');                         
                   } 
                   else
                   {
                        $v = validation_errors();
                        $this->load->view('view1',$v);
                   }
                

            }    
        
    }

    public function register()
    {

            $this->load->library('form_validation');
            $this->form_validation->set_rules('name', 'Name', 'required');
            
            $this->form_validation->set_rules('password', 'Password', 'required');            
            $this->form_validation->set_rules('email', 'E-mail', 'required');

            if ($this->form_validation->run() === FALSE) {                
                echo validation_errors();


            }
            else
            {
                
                                


                $data = array('user_id' => '10', 'name' => $name, 'username' => $username, 
                    'password' => $password );

                $this->db->insert("Users",$data);
                return ($this->db->affected_rows() != 1) ? false : true;

            }

            
    }

    public function callback_check_login()
     {
        $username = $this->input->post('username');
        #$password = $this->input->post('password');
        $u = $this->db->query("seect username from Users where username = '$username'");
        #$p = $this->db->query("seect password from Users where password = '$password'");
        if($username === $u->result() )
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }


     }


}
?>