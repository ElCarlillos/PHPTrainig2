<?php 
/**
* 
*/
class Admin extends CI_Controller
{
	
	public function index()
	{
		$this->session->set_userdata('username', 'mo');
		$this->session->set_userdata('user e-mail', '');
		$this->session->set_userdata('login_attemp', '3');

		if(!$this->session->userdata('username'))
		{
			redirect(base_url().'index.php/Welcome');
		}

		else
		{
			$data['title'] = "Admin  Page";
			$this->load->view('template/header', $data);
			$this->load->view('main_blog');
			
		}
	}
}
?>