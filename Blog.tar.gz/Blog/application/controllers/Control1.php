<?php  
/**
* 
*/
class Control1 extends CI_Controller
{	
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Blog_model');

	}

	public function index()
	{
		
		
		$this->load->view('Pruebas');
		
	}

	function manageData()
	{
		$nombre = $_POST['name'];
		$usuario = $_POST['username'];
		$nombredb = mysql_result("select name from Users where 'name' = '$nombre' ", 0);
		$usuariodb = mysql_result("select username from Users where 'username' = '$usuario' ", 0);
		$this->load->view('inicio');
		


	}

	

	


	
		

	


}
?>