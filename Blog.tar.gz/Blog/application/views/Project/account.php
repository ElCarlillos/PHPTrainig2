<!DOCTYPE html>
<html>
<head>
	<title>Active your account</title>
</head>
<body>
<?php 
		
 ?>
</body>
</html>