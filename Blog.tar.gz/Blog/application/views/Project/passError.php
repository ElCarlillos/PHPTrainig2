<!DOCTYPE html>
<html>
<head>
	<title>Login widget</title>
	<link rel="stylesheet" type="text/css" href="../../application/css/Project/Login.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/css/bootstrap.min.css">
</head>
<body>
	<form action="Login2/validar" method="post">
		<h4>Usuario</h4>
		<input type="text" name="username" id="username"><br><br>		
		<br>
		<h4>Password</h4>
		<input type="password" name="pass" id="password"><br><br>		
		<div class="anchor"><input class="go" type="submit"></input></div>
	</form>
</body>
</html>
