	<?php 
	$this->load->library('form_validation');
	$this->load->model('MLogin');
	
	

 ?>



<!DOCTYPE html>
<html>
<head>
	<title>Login widget</title>
	
	<link rel="stylesheet" type="text/css" href="../../../../../Blog/assets/css/bootstrap-theme.css">
	<!-- <!--<link rel="stylesheet" type="text/css" href="../../../../../Blog/assets/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href="../../../../../Blog/assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../../../../../Blog/assets/css/bootstrap.min.css"> -->
<style type="text/css">
	body
{
	
	margin: 0;
	padding:0;
	font-family: 'Arbutus Slab',serif;
}

#login_form, #register_form
{
	width: 300px;
	background:#AAC4C5;
	border:1px solid white;
	margin: 100px auto 0;
	padding:1em;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
	border-radius: 4px;

}

h1,h2,h3,h4,h5
{
	margin-top: 0;
	text-align: center;
	color: #39898d;
	text-shadow: 0 1px 0 white;
}

input[type=text], input[type=password]
{
	font-family: 'Arbutus Slab', serif;
	font-size: 14px;
	color: #39898D;
	display: block;
	margin: 0 0 1em 0;
	width: 273px;
	border:5px;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
	border-radius: 4px;
	padding:1em;

}


input[type=text]:focus, input[type=password]:focus
{
	outline: none;
	box-shadow: 0px 0px 0px 2px  #549396;
}

input::-webkit-input-placeholder
{
	color: #39898D;
}

input:-moz-placeholder
{
	color: #39898D;
}

input[type=submit],form a
{
	font-family: 'Arbutus Slab', serif;
	border:none;
	margin-right: 1em;
	padding:6px;
	text-decoration: none;
	font-size: 14px;
	background:#549396;
	color white;
	-moz-box-shadow: 0 1px 0 white;
	-webkit-box-shadow:0 1px 0 white;
	box-shadow: 0 1px 0 white;
	-moz-border-radius:2px;
	-webkit-border-radius:2px;
	border-radius:2px;	
}

input[type=submit]:hover,form a:hover
{
	background:#39898D;
	cursor:pointer;
}




</style>	
</head>


<body>
	<form method="POST" action="Clogin/login_validation"><!--../Clogin2/login2-->
		
		<ul style="list-style:none">
			<li style="margin-bottom:44px;margin-top:0px;"><input type="text" name="uname" id="uname" placeholder="Username"></li>
			<?php 
			echo $this->session->flashdata('msg');
			?>


			
			
			<li><input type="password" name="pass" id="pass" placeholder="Password"></li>						
			<br><br>
			
			<li><input type="submit" name="login" id="login"></li>

		</ul>
	</form>
</body>

</html>			