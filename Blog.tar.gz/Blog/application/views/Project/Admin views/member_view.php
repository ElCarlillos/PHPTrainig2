<!DOCTYPE html>
<html>
<head>
	<title>Welcome Vack!</title>
</head>
<body>
	This is an member's exclusive area
</body>
</html>