<link rel="stylesheet" type="text/css" href="../css/blog.css">

<div class="Commentar" id="continer">
    <form action="Commentar/crearComentario" method="post">
        <textarea rows="5" cols="5" name="contenido"></textarea>
        <input type="text" name="options" id="options">
        <input type="submit" name="Comentar">
    </form>
</div>