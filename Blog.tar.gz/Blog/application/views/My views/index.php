<!DOCTYPE html>
<html>
<head>
	<title>My register form</title>
</head>
<body>
<style type="text/css">
	
</style>

<form action="register" method="POST">
	<table>
		<tbody>
			<tr>
				<th>User Name</th>
				<td>
					<input type="text" name="user_name" placeholder="Please input username" ">
					<?php  echo form_error('user_name');?>
				</td>
			</tr>
		</tbody>
	</table>
	
</form>
</body>
</html>