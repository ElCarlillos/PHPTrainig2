<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		ul
		{
			list-style: none;
		}
	</style>
</head>
<body>
<form action="insert" method="POST">
<ul>
	<li>Name: <br/><input type="text" name="name"></li>
	<li>Username: <br/><input type="text" name="username"></li>
	<li><input type="submit" name="go" value="Go"></li>
</ul>
	
</form>
</body>
</html>

