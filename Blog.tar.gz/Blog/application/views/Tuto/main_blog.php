<!DOCTYPE html>
<html>
<head>
	<title>This is my main blog</title>
<link rel="stylesheet" type="text/css" href="../../Iconmoon/style.css">
<link rel="stylesheet" type="text/css" href="../css/slideshow.css">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<style type="text/css">
body
	{
		margin: 0px;
		padding:0px;
		height: 2000px;
		
	}
	ul
	{
		list-style: none;
		display: flex;
	    margin: 0px;
    	padding-left: 519px;
    	background-color: lightblue;
    	height: 40px;
    	position: fixed;
    	width: 100%;    

	}

	

	ul li p
	{
		margin-right: 68px;
		margin-top: 10px;
	}
	ul li p:hover
	{
		background-color: green;
	}	

	.headers:hover
	{
		background-color: green;
	}

	

	#header
	{
		font-weight: bold;
		font:10px 'Time New Roman';
	}

	img
	{
		height: 265px;
	    
	    margin-top: 40px;
	    width: 1000px;

	}

	.main
	{
		width: 90%;
		max-width: 1000px;
		margin:20px auto;
		margin-top: 0px;

	}


	body div
	{
		margin-top: 0px;
	}
	.content
	{
		border: 1px solid black;
		width: 355px;
	}

	#content
	{
		height: 650px;
		width: 1347px;
		display: flex;
    	border: 1px solid green;
    	position: absolute;
    	left: 1px;
	}

	#content1
	{
		width: 221px;
	}

	#content2
	{
		width: 765px;
	}

	.comentarios
	{
		border: 2px solid black;
	}


</style>
</head>
<body>

	<ul>
		
		<li><p>Home</p></li>
		<li><p>Register</p></li>
		<li><p>News</p></li>
		<li><p>Gallery</p></li>

	</ul>
	
	<div class="container">
		<div class="slides">
				<!--<img src="../../application/images/bandas.jpg">
				<img src="../../application/images/bandas.jpg">-->
				<img src="../../../../application/images/stratovarious.jpg" class="img-rounded"> 
		</div>	
		<div id="content" style="display:flex;border: 1px solid green;" >
			<div class="content" id="content1">
				<aside>
					
				</aside>
			</div>
			<div class="content" id="content2">
				<div class="comentarios"></div>
			</div>
			<div class="content" id="content3">Div3</div>
			
		</div>
	</div>

	
</body>
</html>