<!DOCTYPE html>
<html>
<head>
	<title>Formulario de Registro</title>
	<link rel="stylesheet" type="text/css" href=".././../assets/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href=".././../assets/css/bootstrap-theme.min.css">
	<link rel="stylesheet" type="text/css" href=".././../assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href=".././../assets/css/bootstrap.min.css">
<style type="text/css">
	input
	{
		border-radius: 10px;
		
	}

	form
	{
		position: absolute;
		left: 453px;
		text-align: center;
		border-radius: 15px;
		border:2px solid lightgray;
		width: 35%;
		background-color: lightgray;
	}

	body
	{
		height: 410px;
    	margin: 0px;
    	background-color: green;
	}


	#btn
	{
		background-color: blue;
		width: 76px;
		height: 35px;
	}

	#btn:hover
	{
		background-color: #4652F7;

	}
	h1
	{
		background-color: blue;
    	margin: 0px;
    	height: 44px;
    	margin-bottom: 20px;
	}

	#show_pas
	{
		position: absolute;
    	top: 275px;
    	left: 147px;

	}

	p
	{
		    margin: 0px;
    	position: absolute;
    	top: 276px;
    	left: 167px;
	}

</style>

</head>
<body>
<h1>La Banda.com: Blog & Fan Page</h1>
<form action="CRegister/start_session" method="post"> 
	<h2>Register your information</h2>
	Nombre: <br>
	<input type="text" name="name" placeholder="Your name here"><br><br>
	<?php echo form_error('name'); ?>
	Usuario:<br>
	<input type="text" name="username" placeholder="Choose a username"><br><br>
	
	Password <br>
	<input type="password" name="password" placeholder="Type your password"><br><br>		
	Confirm password<br>
	<input type="password" name="confPass" id="confPass" placeholder="Type your password again"><br><br>
	Email: <br>
	<input type="text" name="email" placeholder="Type your email address"><br><br>
	<input type="submit" name="register" id="btn" value="Register"><br><br>
	
	<input type="reset" name="reset">
</form> 
	
</body>
</html>