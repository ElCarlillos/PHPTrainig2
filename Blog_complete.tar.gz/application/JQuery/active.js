$(document).ready(function() {
$("#commentForm").validate({
});

password2: {
required: true,
equalTo: "#password"
}