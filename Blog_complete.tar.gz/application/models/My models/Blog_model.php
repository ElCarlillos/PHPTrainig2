<?php 
/**
* 
*/
class Blog_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}
	

	public function get_all()
	{
		$this-> db -> select('user_id,name,username');
		$query = $this-> db -> get('Blog');
		return $query->result_array();
	}
	public function getData()
	{
		$query = $this -> db -> get('Blog');
		return $query->result();
	}

	
}
?>