<?php 
/**
* 
*/
class MLogin extends CI_Model
{
	
	public function checLogin($username,$password)
	{
		$query = $this->db->query("select * from Users where username = '$username'");
		
		$row = $query->row();

		if ($query->row() != NULL){
			return $query->row()->username;
		}
		else
		{
			return "No carlos";
		}
		
		
			
		
	}

	public function uname_not_empty($campo)
	{
		if (empty($campo)) {
			

			echo "The field username is required" ;
			echo "<br>";
		}		
	}

	public function pass_not_empty($pass)
	{
		if (empty($pass)) {
			echo "The password is required";
			echo "<br>";
		}
	}


	

	public function is_numeric($cadena)
	{
		if (mb_strpos($cadena, 1) >= 1 || mb_strpos($cadena, 2) >= 1 || mb_strpos($cadena, 3) >= 1 || mb_strpos($cadena, 4) >= 1 || mb_strpos($cadena, 5) >= 1 || mb_strpos($cadena, 6) >= 1 || mb_strpos($cadena, 7) >= 1 || mb_strpos($cadena, 8) >= 1 || mb_strpos($cadena, 9) >= 1 || mb_strpos($cadena, 0) >= 1)
		{
			
			echo "The field  can't be numeric";
			echo "<br>";
			
		}	
	}


	public function check_length($str, $max_len, $min_len)
	{
		if (mb_strlen($str) > $max_len) {
			echo "The field has a max length of ".$max_len;
			echo "<br>";
		}		
		elseif (mb_strlen($str) < $min_len) {
			echo "The field has a min length of ".$min_len;
			echo "<br>";
		}

	}


	
}
 ?>
