<!DOCTYPE html>
<html>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

<head>
	<title>Login Widget</title>
<style type="text/css">
	#upperBar
	{
		background-color: blue;
		height: 50px;
	}
	#mainDiv
	{
		background-color: green;
		height: 578px;
	}

	form
	{
		position: absolute;
		left: 591px;
		top:216px;
		list-style: none;
		background-color: lightgray;
		border-radius: 10px;
		height: 180px;
    	width: 241px;
	}

	form ul li
	{
		list-style: none;
	}

	body	
	{
		margin: 0px;
	}

	#loginBtn
	{
		position: absolute;
    	top: 148px;
    	left: 15px;
	}

	a
	{
		position: absolute;
 	   left: 69px;
       top: 149px;
}
	}


</style>
</head>
<body>
<?php echo validation_errors() ?>

	<form action="../Login" method="POST">
		<ul>
			<li><h2>Login, Fool!</h2></li>
			<li>Usuario <br> <input type="text" name="username" placeholder="Write your username" data-dismiss="alert"></li>
			<?php echo form_error('user_name', '<p>class="error"', '</p>') ?>
			<span class="label label-danger">Danger</span>
			<li>Password <br> <input type="password" name="password" placeholder="Write your password"></li>
			<li><input type="submit" id="loginBtn" value="Login"></li>
			<li><a href="Register_control">Register</a></li>
		</ul>
	</form>
	<div id="upperBar"></div>
<div id="mainDiv">
</div>
</body>
</html>

<!--"../HomeController/login"-->