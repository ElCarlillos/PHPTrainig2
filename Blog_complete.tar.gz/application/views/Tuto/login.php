<?php 
echo "Records from de database<br/> ";


foreach ($records as $rec) {

	echo $rec->user_id."   ".$rec->name."   ";
}
 ?>