<?php
$(function() {
$("#datepicker").datepicker({
 dateFormat: 'dd-mm-yy',
changeMonth: true,
changeYear: true,
maxDate: '+0M +0D'
});
});

function user_info_insert(){
$data=array('user_nick_name'=>$_POST["nick_name"],
'user_sex'=>$_POST["sex"],'user_marry'=>$_POST["mar
ry"],
'user_country'=>$_POST["province"],'user_city'=>$_P
OST["city"],
'user_brithday'=>$_POST["datepicker"]);
$user_name=$_POST["user_name"];
$this->db->where('user_name',$user_name);
$this->db->update('user_info', $data);
}

?>