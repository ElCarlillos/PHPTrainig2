<div id="login_form" style="width:400px;margin:100px auto;border-radius:10px;padding:20px;border:2px solid #909090">

 <?php 
echo form_open();
echo form_label('Username:').br(2);
$data = array(
	'name' => 'user_name',
	'id' => 'user_name',
	'value'  => '',
	'style' => 'width:100%'
	);
	echo form_input($data).br(2);

	echo form_label('Password:').br(2);
	$data = array(
		'name' => 'Password',
		'id' => 'Password',
		'value'  => '',
		'style' => 'width:100%'
	);
		echo form_password($data).br(2);

		echo form_close();

?> 
<form>
	Usuario
	<input type="text" name="">
</form>
</div>