<!DOCTYPE html>
<html>
<head>
	<title>Este es una vista mia</title>
</head>
<body>
	<p>AHORA TENGO EL PODER PARA DOMINAR CODEIGNITER!!!</p>
</body>
</html>