<!DOCTYPE html>
<html>
<head>
	<title>Prueba comentario</title>
	<link rel="stylesheet" type="text/css" href="http://localhost/Blog/application/css/Blog.css">

</head>
<body>
<?php $this->load->model('Post_db');?>
<!-- <div id="main-cont">


<div id="mydate-cont"><p>Fecha</p><input type="date" name="myDate" id="mydate"></div>
      
<div id="user_id" >
<form action="http://localhost/Blog/index.php/Main/comment" method="post">
    <input type="text" name="type_uid" id="type_uid" placeholder="Type your username">    
    
    <input type="text" name="coment" id="coment" style=""> 
    <input type="submit" name="go" id="go">
<form>

</div>


<div id="img-opt" > 
    <h1>Hola</h1>
    <p>Envelope icon: <span class="glyphicon glyphicon-envelope"></span></p> 
    <span class="glyphicon glyphicon-file"></span>
</div>

</div> -->

<span style="background-color:lightgray; ">
<div id="cuerpo">
<h1>Zona de comentarios</h1>

<?php $this->Post_db->mostrarCont();
$this->Post_db->mostrarFecha();
$this->Post_db->mostrarId();
?>            
    </div>
</div>
</span>



    <script type="text/javascript" href="http://localhost/Blog/application/views/js/attach.js"></script>
</body>
</html>

