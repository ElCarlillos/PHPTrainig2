<html>
<?php

		$query = $this->db->query("select * from Comentario");

			
		foreach($query->result() as $row)
		{
				if (isset($row))
				{
		        		echo $row->id;
		        		echo $row->fecha_com;
		        		echo $row->contenido;
		        		echo "<br>";
				}
		
		}	
		
			

	

?>
</html>