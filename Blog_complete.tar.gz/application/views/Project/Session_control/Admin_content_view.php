<p> <h4>Session info</h4>
    <?php 
        print_r($this->session->all_userdata()).br(1);
    
    ?>
</p>
<p>
    Some admin Data to be manage
</p>