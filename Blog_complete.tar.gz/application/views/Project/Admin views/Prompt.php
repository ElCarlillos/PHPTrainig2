<?php 

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Account activation</title>
	<link rel="stylesheet" type="text/css" href="../../../../assets/css/prompt.css">
	<meta charset="utf-8">
	<style type="text/css">
		body
{
	background: lightblue;
}

#text_div
{
	background:#F6FD6F;
	text-align:center;
	width:400px;
	height: 200px;
	border-radius:10px;
	margin-left: 500px;
	margin-top: 200px;
}
		
	</style>
</head>
<body>
	<div id="container_div">
		<div id="text_div" 
			<p>!!!FELICIDADES, TU USUARIO HA SIDO REGISTRADO¡¡¡</p><br>
			<p>Hemos enviado un correo electronico a la direccion <?php echo $this->session->userdata('email');?></p><br>
			<p>Solo cierra esta pagina y haz click en el enlace del correo y podras activar tu cuenta</p>	
		</div>
	</div>
</body>
</html>