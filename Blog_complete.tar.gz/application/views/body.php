<!DOCTYPE html>
<html>
<head>
	<title>Ejemplo diesño con bootstrap</title>
	<link rel="stylesheet" type="text/css" href="base_url('assets/Freelance/css/sb-admin--2.css')">
	<link rel="stylesheet" type="text/css" href="base_url('assets/Freelance/css/timeline.css')">
</head>
<body>

</body>
</html>