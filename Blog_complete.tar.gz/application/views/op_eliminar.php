<div id="elim">

    <?php 
    $query = $this->db->query("select * from Comentario");

                
            foreach($query->result() as $row)
            {
                    if (isset($row))
                    {
                            echo $row->id;
                            echo $row->fecha_com;
                            echo $row->contenido;
                            echo "<br>";
                    }
            
            }   
            $this->load->view('main_blog');
    ?>

    
            <input type="text" name="select_id" placeholder="Escribe un id ">
            <input type="submit" name="delete" value="Delete comment">    

    
</div>