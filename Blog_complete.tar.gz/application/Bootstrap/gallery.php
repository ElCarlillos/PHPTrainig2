<html>
<head>
    <title>Slideshow</title>
<style type="text/css">
    * {
    margin:0;
    padding:0;
}
 
body {
    background:#f2f2f2;
}
 
.main {
    width:90%;
    max-width:1000px;
    margin:20px auto;
}
 
.slides {
    width:100%;
}
 
.slides img {
    width:100%;
}
 
.slidesjs-pagination {
    background:#424242;
    list-style:none;
    overflow:hidden;
}
 
.slidesjs-pagination li {
    float:left;
}
 
.slidesjs-pagination li a {
    display:block;
    padding:10px 20px;
    color:#fff;
    text-decoration:none;
}
 
.slidesjs-pagination li a:hover {
    background:#000;
}
 
.slides .active {
    background:#000;
}
 
.slidesjs-navigation{
    background:#000;
    color:#fff;
    text-decoration:none;
    display:inline-block;
    padding:13.5px 20px;
    float:right;
}
</style>
</head>
<body>
    <div class="main">
        <div class="slides">
            <img src="http://lorempixel.com/1600/900/city/1" alt="">
            <img src="http://lorempixel.com/1600/900/city/2" alt="">
            <img src="http://lorempixel.com/1600/900/city/3" alt="">
        </div>
    </div>
    <script>
 
    $(function(){
  $(".slides").slidesjs({
    play: {
      active: true,
        // [boolean] Generate the play and stop buttons.
        // You cannot use your own buttons. Sorry.
      effect: "slide",
        // [string] Can be either "slide" or "fade".
      interval: 3000,
        // [number] Time spent on each slide in milliseconds.
      auto: true,
        // [boolean] Start playing the slideshow on load.
      swap: true,
        // [boolean] show/hide stop and play buttons
      pauseOnHover: false,
        // [boolean] pause a playing slideshow on hover
      restartDelay: 2500
        // [number] restart delay on inactive slideshow
    }
  });
});
 
    </script>
</body>
</html>
    


    