<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-06 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 07:38:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 07:40:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 07:40:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 07:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 08:00:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:00:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-06 08:00:07 --> 404 Page Not Found: Project/Admin%20views/index
DEBUG - 2016-07-06 08:00:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-06 08:00:40 --> 404 Page Not Found: Project/Admin/Admin_control/index
DEBUG - 2016-07-06 08:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-06 08:01:23 --> 404 Page Not Found: Project/Admin/Admin_control/index
DEBUG - 2016-07-06 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 08:20:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-06 08:21:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-06 08:21:42 --> Global POST, GET and COOKIE data sanitized
