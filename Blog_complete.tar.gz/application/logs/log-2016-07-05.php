<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-05 09:40:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:40:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:40:51 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:52 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 09:59:52 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:54 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 09:59:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 09:59:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/views/Tuto/register.php 94
DEBUG - 2016-07-05 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:08:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:08:48 --> Could not find the language line "Duplicated key"
DEBUG - 2016-07-05 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:10:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:10:05 --> Total execution time: 0.0038
DEBUG - 2016-07-05 10:12:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:12:58 --> 404 Page Not Found: Project/Start_session/index
DEBUG - 2016-07-05 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:32 --> 404 Page Not Found: Project/Start_session/index
DEBUG - 2016-07-05 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:35 --> Total execution time: 0.0073
DEBUG - 2016-07-05 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:52 --> Total execution time: 0.0034
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:13:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:13:54 --> Total execution time: 0.0064
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:13:54 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:14:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:14:02 --> Total execution time: 0.0050
DEBUG - 2016-07-05 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:14:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:14:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() /var/www/html/Blog/application/controllers/Project/CRegister.php 87
DEBUG - 2016-07-05 10:22:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:22:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:22:40 --> Total execution time: 0.0081
DEBUG - 2016-07-05 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:22:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:22:45 --> Total execution time: 0.0034
DEBUG - 2016-07-05 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:23:12 --> Could not find the language line ""
DEBUG - 2016-07-05 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:23:37 --> Could not find the language line "Duplicated key for username"
DEBUG - 2016-07-05 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:23:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:23:38 --> Total execution time: 0.0032
DEBUG - 2016-07-05 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:24:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:24:04 --> Could not find the language line "Duplicated key for username"
DEBUG - 2016-07-05 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:05 --> Total execution time: 0.0047
DEBUG - 2016-07-05 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 10:32:05 --> Severity: Parsing Error --> syntax error, unexpected ':' /var/www/html/Blog/application/controllers/Project/Admin/Mail.php 3
DEBUG - 2016-07-05 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:07 --> Total execution time: 0.0033
DEBUG - 2016-07-05 10:32:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:32:08 --> Total execution time: 0.0042
DEBUG - 2016-07-05 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:32:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 10:32:28 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlitos', 'chente1', 'chente2', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 10:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 10:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 10:37:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 10:37:35 --> Total execution time: 0.0038
DEBUG - 2016-07-05 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:42:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:42:05 --> Query error: Duplicate entry 'chente1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlitos', 'chente1', 'chente123', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:42:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:42:45 --> Total execution time: 0.0035
DEBUG - 2016-07-05 12:43:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:43:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:43:50 --> Total execution time: 0.0068
DEBUG - 2016-07-05 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 12:43:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 12:43:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 12:43:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 12:43:51 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-05 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:44:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:44:02 --> Total execution time: 0.0036
DEBUG - 2016-07-05 12:44:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:44:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:44:04 --> Total execution time: 0.0031
DEBUG - 2016-07-05 12:44:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:44:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:44:31 --> Query error: Unknown column 'Roberto' in 'where clause' - Invalid query: SELECT *
FROM `Users`
WHERE `name` = `Roberto`
DEBUG - 2016-07-05 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:47:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:47:26 --> Query error: Duplicate entry 'rovicFlores' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Roberto', 'rovicFlores', 'rovic12', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:47:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:47:31 --> Total execution time: 0.0031
DEBUG - 2016-07-05 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:47:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:47:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 12:47:44 --> Query error: Table 'Blog.users' doesn't exist - Invalid query: select * from users where name = Roberto
DEBUG - 2016-07-05 12:47:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:47:44 --> Query error: Duplicate entry 'rovicFlores1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Roberto', 'rovicFlores1', 'flores1', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:48:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:48:02 --> Total execution time: 0.0059
DEBUG - 2016-07-05 12:48:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:48:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:48:24 --> Query error: Table 'Blog.users' doesn't exist - Invalid query: select * from users where name = Roberto
DEBUG - 2016-07-05 12:49:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:49:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:49:10 --> Query error: Duplicate entry 'rovicMena1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Roberto', 'rovicMena1', 'mena123', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:49:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:49:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:49:13 --> Total execution time: 0.0036
DEBUG - 2016-07-05 12:49:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:49:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:49:14 --> Total execution time: 0.0032
DEBUG - 2016-07-05 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:49:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:49:43 --> Query error: Unknown column 'Roberto' in 'where clause' - Invalid query: select * from Users where name = Roberto
DEBUG - 2016-07-05 12:50:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:50:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:50:09 --> Severity: Parsing Error --> syntax error, unexpected 'name' (T_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 38
DEBUG - 2016-07-05 12:50:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:50:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:50:24 --> Query error: Duplicate entry 'rovicMena123' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Roberto', 'rovicMena123', 'rovic123', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:50:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:50:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:50:28 --> Total execution time: 0.0046
DEBUG - 2016-07-05 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:50:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:50:31 --> Total execution time: 0.0035
DEBUG - 2016-07-05 12:51:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:51:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:51:19 --> Total execution time: 0.0039
DEBUG - 2016-07-05 12:51:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:51:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:51:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '["name"]' at line 1 - Invalid query: select * from Users where name = $data_array["name"]
DEBUG - 2016-07-05 12:52:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:52:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:52:16 --> Severity: Parsing Error --> syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) /var/www/html/Blog/application/models/Project/Mregister.php 38
DEBUG - 2016-07-05 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:52:51 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:52:51 --> Severity: Parsing Error --> syntax error, unexpected '$name' (T_VARIABLE), expecting function (T_FUNCTION) /var/www/html/Blog/application/models/Project/Mregister.php 8
DEBUG - 2016-07-05 12:53:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:53:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:53:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/models/Project/Mregister.php 8
DEBUG - 2016-07-05 12:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:53:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:53:56 --> Query error: Duplicate entry 'carmenQuiroz' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlitos', 'carmenQuiroz', 'carmenQuiroz', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:53:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:53:59 --> Total execution time: 0.0062
DEBUG - 2016-07-05 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:54:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:54:28 --> Query error: Unknown column 'Carlitos' in 'where clause' - Invalid query: select * from Users where name = Carlitos
DEBUG - 2016-07-05 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:55:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 12:55:14 --> Query error: Duplicate entry 'carmenQuiroz1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('Carlitos', 'carmenQuiroz1', 'carmenQuiroz1', 'painkillerkilling@gmail.com')
DEBUG - 2016-07-05 12:55:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:55:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:55:30 --> Total execution time: 0.0032
DEBUG - 2016-07-05 12:55:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:55:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:55:32 --> Total execution time: 0.0033
DEBUG - 2016-07-05 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 12:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 12:55:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 12:55:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 12:55:55 --> Total execution time: 1.9545
DEBUG - 2016-07-05 13:08:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:08:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:08:21 --> Total execution time: 0.0188
DEBUG - 2016-07-05 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:08:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:08:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 13:08:57 --> Total execution time: 5.2650
DEBUG - 2016-07-05 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:10:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 13:10:16 --> Query error: Duplicate entry 'carHdz1' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('CarmenH', 'carHdz1', 'carHdz1', 'drummerphantom@gmail.com')
DEBUG - 2016-07-05 13:10:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:10:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:10:20 --> Total execution time: 0.0051
DEBUG - 2016-07-05 13:10:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:10:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:10:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 13:10:44 --> Total execution time: 1.4521
DEBUG - 2016-07-05 13:12:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:12:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:12:11 --> Total execution time: 0.0033
DEBUG - 2016-07-05 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:12:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:12:12 --> Total execution time: 0.0032
DEBUG - 2016-07-05 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:31:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:31:27 --> Total execution time: 0.0067
DEBUG - 2016-07-05 13:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:31:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 13:31:33 --> Query error: Duplicate entry 'carHdz2' for key 'username' - Invalid query: INSERT INTO `Users` (`name`, `username`, `password`, `email`) VALUES ('CarmenHQ', 'carHdz2', 'carHdz2q', 'cvanegashdz@gmail.com')
DEBUG - 2016-07-05 13:31:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:31:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:31:55 --> Total execution time: 0.0034
DEBUG - 2016-07-05 13:31:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 13:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 13:31:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 13:31:59 --> Total execution time: 0.0035
DEBUG - 2016-07-05 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:05:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:05:58 --> Total execution time: 0.4802
DEBUG - 2016-07-05 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:13:54 --> 404 Page Not Found: Project/Cadmin/index
DEBUG - 2016-07-05 14:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:07 --> 404 Page Not Found: Project/Admin%20views/Cadmin
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:48:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:48:44 --> Total execution time: 0.0210
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:44 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:45 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:45 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:48:45 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:51:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:51:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:51:34 --> Total execution time: 0.0166
DEBUG - 2016-07-05 14:51:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:34 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:51:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:51:35 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:53:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:53:00 --> Total execution time: 0.0065
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:00 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:01 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:01 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:01 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:53:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:29 --> 404 Page Not Found: Project/Admin/Cadmin/bower_components
DEBUG - 2016-07-05 14:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:53:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:53:36 --> Total execution time: 0.0099
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:53:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:53:41 --> Total execution time: 0.0050
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/font-awesome
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/jquery
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:53:41 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:54:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:54:33 --> Total execution time: 0.0063
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:54:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:54:37 --> Total execution time: 0.0047
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/morrisjs
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:54:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:54:37 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:54:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:54:57 --> Total execution time: 0.0061
DEBUG - 2016-07-05 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:55:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:55:21 --> Total execution time: 0.0064
DEBUG - 2016-07-05 14:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:56:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:56:03 --> Total execution time: 0.0033
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:56:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 14:56:05 --> Total execution time: 0.0032
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 14:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 14:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 14:56:05 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:25:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:25:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:25:49 --> hola
DEBUG - 2016-07-05 16:25:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 16:25:49 --> Total execution time: 0.0313
DEBUG - 2016-07-05 16:25:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:25:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:25:59 --> 404 Page Not Found: Project/Cadmin/index
DEBUG - 2016-07-05 16:26:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:26:21 --> hola
DEBUG - 2016-07-05 16:26:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 16:26:21 --> Total execution time: 0.0181
DEBUG - 2016-07-05 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:22 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:26:22 --> hola
DEBUG - 2016-07-05 16:26:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 16:26:22 --> Total execution time: 0.0039
DEBUG - 2016-07-05 16:26:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:26:27 --> Total execution time: 0.0066
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Dist/css
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/font-awesome
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/jquery
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:26:28 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:27:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:27:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:27:38 --> hola
DEBUG - 2016-07-05 16:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 16:27:38 --> Total execution time: 0.0103
DEBUG - 2016-07-05 16:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:27:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:27:40 --> hola
DEBUG - 2016-07-05 16:27:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 16:27:40 --> Total execution time: 0.0054
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:27:46 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:27:46 --> Total execution time: 0.0197
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/font-awesome
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/jquery
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:46 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:47 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:47 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:47 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:47 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:27:47 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:26 --> 404 Page Not Found: Project/Cadmin/index
DEBUG - 2016-07-05 16:28:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:28:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:28:37 --> Total execution time: 0.0053
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/font-awesome
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Dist/css
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/jquery
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/bootstrap
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/metisMenu
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/raphael
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Bower_components/morrisjs
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Js/morris-data.js
DEBUG - 2016-07-05 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:38 --> 404 Page Not Found: Project/Admin/Dist/js
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:28:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:28:41 --> Total execution time: 0.0049
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:28:41 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:29:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:29:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:29:33 --> Total execution time: 0.0106
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:29:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:29:34 --> Total execution time: 0.0032
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:29:34 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:29:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:29:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:29:59 --> Total execution time: 0.0060
DEBUG - 2016-07-05 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:30:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:30:31 --> Total execution time: 0.0097
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:30:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:30:33 --> Total execution time: 0.0033
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:30:33 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:31:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:31:24 --> Total execution time: 0.0184
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Dist/css
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/font-awesome
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 16:31:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:31:24 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:33:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:33:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:33:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:34:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:35:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:37:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:37:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:37:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:37:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:38:19 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:38:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:38:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:38:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:38:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 16:38:47 --> 404 Page Not Found: Assets/Main_pages
DEBUG - 2016-07-05 16:39:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:39:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:39:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:39:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:39:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:40:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:41:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:41:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:41:49 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:44:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 16:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 16:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 16:56:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:01:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:01:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:01:04 --> Total execution time: 0.0453
DEBUG - 2016-07-05 17:01:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:01:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:01:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:01:40 --> Total execution time: 0.0074
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:01:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:01:40 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:03:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-05 17:03:32 --> Severity: Notice --> Undefined variable: username /var/www/html/Blog/application/views/Project/Admin views/member_view.php 1
DEBUG - 2016-07-05 17:03:32 --> Total execution time: 0.0332
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:03:32 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:04:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:04:34 --> Total execution time: 0.0040
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:04:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:04:34 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:13:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 17:13:54 --> Total execution time: 0.0069
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:13:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:54 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-05 17:13:57 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-05 17:13:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 17:13:57 --> Total execution time: 0.0039
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/jquery
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/bootstrap
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Dist/js
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/metisMenu
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/raphael
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Bower_components/morrisjs
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Js/morris-data.js
DEBUG - 2016-07-05 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-05 17:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-05 17:13:57 --> 404 Page Not Found: Project/Dist/js
