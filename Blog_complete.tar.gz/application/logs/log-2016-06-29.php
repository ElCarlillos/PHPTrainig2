<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-06-29 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:29:28 --> Total execution time: 0.4716
DEBUG - 2016-06-29 09:53:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 09:53:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Mregister /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-29 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:53:58 --> Total execution time: 0.0086
DEBUG - 2016-06-29 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:54:00 --> Total execution time: 0.0051
DEBUG - 2016-06-29 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:54:18 --> Total execution time: 0.0104
DEBUG - 2016-06-29 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:54:29 --> Total execution time: 0.0056
DEBUG - 2016-06-29 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:54:42 --> Total execution time: 0.0037
DEBUG - 2016-06-29 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:54:52 --> Total execution time: 0.0034
DEBUG - 2016-06-29 09:55:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:55:36 --> Total execution time: 0.1911
DEBUG - 2016-06-29 09:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 09:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 09:55:57 --> Total execution time: 0.0101
DEBUG - 2016-06-29 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:51:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:51:13 --> Total execution time: 0.3115
DEBUG - 2016-06-29 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:51:18 --> hola
DEBUG - 2016-06-29 10:51:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:51:19 --> Total execution time: 0.5009
DEBUG - 2016-06-29 10:51:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 10:51:19 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 10:51:29 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-06-29 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:51:33 --> hola
DEBUG - 2016-06-29 10:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:51:33 --> Total execution time: 0.0061
DEBUG - 2016-06-29 10:53:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:53:03 --> hola
DEBUG - 2016-06-29 10:53:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:53:03 --> Total execution time: 0.0065
DEBUG - 2016-06-29 10:53:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 10:53:03 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 10:53:44 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-06-29 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:53:47 --> hola
DEBUG - 2016-06-29 10:53:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:53:47 --> Total execution time: 0.0095
DEBUG - 2016-06-29 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:54:01 --> hola
DEBUG - 2016-06-29 10:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:54:01 --> Total execution time: 0.0058
DEBUG - 2016-06-29 10:54:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 10:54:02 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:54:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:54:12 --> Total execution time: 0.0274
DEBUG - 2016-06-29 10:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:54:18 --> hola
DEBUG - 2016-06-29 10:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:54:18 --> Total execution time: 0.0062
DEBUG - 2016-06-29 10:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:54:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:54:45 --> Total execution time: 0.0046
DEBUG - 2016-06-29 10:54:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 10:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 10:54:47 --> hola
DEBUG - 2016-06-29 10:54:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 10:54:47 --> Total execution time: 0.0056
DEBUG - 2016-06-29 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:20:42 --> hola
DEBUG - 2016-06-29 12:20:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:20:42 --> Total execution time: 0.0040
DEBUG - 2016-06-29 12:20:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 12:20:43 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 12:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:20:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:20:50 --> Total execution time: 0.0035
DEBUG - 2016-06-29 12:30:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:28 --> hola
DEBUG - 2016-06-29 12:30:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:28 --> Total execution time: 0.0038
DEBUG - 2016-06-29 12:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:30 --> hola
DEBUG - 2016-06-29 12:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:30 --> Total execution time: 0.0033
DEBUG - 2016-06-29 12:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 12:30:30 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:37 --> Total execution time: 0.0038
DEBUG - 2016-06-29 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:39 --> hola
DEBUG - 2016-06-29 12:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:39 --> Total execution time: 0.0034
DEBUG - 2016-06-29 12:30:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:44 --> Total execution time: 0.0035
DEBUG - 2016-06-29 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:49 --> hola
DEBUG - 2016-06-29 12:30:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:49 --> Total execution time: 0.0033
DEBUG - 2016-06-29 12:30:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:30:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:30:57 --> Total execution time: 0.0105
DEBUG - 2016-06-29 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:31:00 --> hola
DEBUG - 2016-06-29 12:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:31:00 --> Total execution time: 0.0035
DEBUG - 2016-06-29 12:31:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:31:31 --> Total execution time: 0.0035
DEBUG - 2016-06-29 12:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:31:35 --> hola
DEBUG - 2016-06-29 12:31:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:31:35 --> Total execution time: 0.0032
DEBUG - 2016-06-29 12:31:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:31:55 --> Total execution time: 0.0037
DEBUG - 2016-06-29 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:31:57 --> hola
DEBUG - 2016-06-29 12:31:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:31:57 --> Total execution time: 0.0033
DEBUG - 2016-06-29 12:32:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:32:04 --> Total execution time: 0.0035
DEBUG - 2016-06-29 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:32:05 --> hola
DEBUG - 2016-06-29 12:32:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:32:05 --> Total execution time: 0.0034
DEBUG - 2016-06-29 12:32:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:32:11 --> Total execution time: 0.0037
DEBUG - 2016-06-29 12:32:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 12:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 12:32:13 --> hola
DEBUG - 2016-06-29 12:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 12:32:13 --> Total execution time: 0.0031
DEBUG - 2016-06-29 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:08 --> hola
DEBUG - 2016-06-29 13:45:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:08 --> Total execution time: 0.0035
DEBUG - 2016-06-29 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:45:08 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:21 --> Total execution time: 0.0035
DEBUG - 2016-06-29 13:45:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:32 --> hola
DEBUG - 2016-06-29 13:45:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:32 --> Total execution time: 0.0035
DEBUG - 2016-06-29 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:35 --> Total execution time: 0.0039
DEBUG - 2016-06-29 13:45:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:38 --> hola
DEBUG - 2016-06-29 13:45:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:38 --> Total execution time: 0.0033
DEBUG - 2016-06-29 13:45:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:45:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:45:46 --> Total execution time: 0.0037
DEBUG - 2016-06-29 13:46:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:46:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:46:08 --> Total execution time: 0.0040
DEBUG - 2016-06-29 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:46:10 --> hola
DEBUG - 2016-06-29 13:46:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:46:10 --> Total execution time: 0.0032
DEBUG - 2016-06-29 13:46:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:46:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:46:15 --> Total execution time: 0.0037
DEBUG - 2016-06-29 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:46:17 --> hola
DEBUG - 2016-06-29 13:46:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:46:17 --> Total execution time: 0.0034
DEBUG - 2016-06-29 13:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:46:44 --> hola
DEBUG - 2016-06-29 13:46:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:46:44 --> Total execution time: 0.0042
DEBUG - 2016-06-29 13:46:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:46:44 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:54:01 --> hola
DEBUG - 2016-06-29 13:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:54:01 --> Total execution time: 0.0042
DEBUG - 2016-06-29 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:54:01 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:54:11 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:54:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:54:11 --> Total execution time: 0.0049
DEBUG - 2016-06-29 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:56:03 --> hola
DEBUG - 2016-06-29 13:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:56:03 --> Total execution time: 0.0041
DEBUG - 2016-06-29 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:56:04 --> hola
DEBUG - 2016-06-29 13:56:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:56:04 --> Total execution time: 0.0034
DEBUG - 2016-06-29 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:56:05 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:56:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:56:14 --> Total execution time: 0.0033
DEBUG - 2016-06-29 13:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:56:15 --> hola
DEBUG - 2016-06-29 13:56:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:56:15 --> Total execution time: 0.0032
DEBUG - 2016-06-29 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:58:16 --> hola
DEBUG - 2016-06-29 13:58:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:58:16 --> Total execution time: 0.0040
DEBUG - 2016-06-29 13:58:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:58:16 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:58:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:58:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:58:21 --> Total execution time: 0.0036
DEBUG - 2016-06-29 13:58:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:58:23 --> hola
DEBUG - 2016-06-29 13:58:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:58:23 --> Total execution time: 0.0034
DEBUG - 2016-06-29 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:58:53 --> hola
DEBUG - 2016-06-29 13:58:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:58:53 --> Total execution time: 0.0046
DEBUG - 2016-06-29 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 13:58:54 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 13:59:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:59:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:59:00 --> Total execution time: 0.0036
DEBUG - 2016-06-29 13:59:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 13:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 13:59:01 --> hola
DEBUG - 2016-06-29 13:59:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 13:59:01 --> Total execution time: 0.0034
DEBUG - 2016-06-29 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:06:34 --> hola
DEBUG - 2016-06-29 14:06:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:06:34 --> Total execution time: 0.0100
DEBUG - 2016-06-29 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:06:34 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:06:44 --> 404 Page Not Found: Project/Clogin/Clogin2
DEBUG - 2016-06-29 14:06:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:06:46 --> hola
DEBUG - 2016-06-29 14:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:06:46 --> Total execution time: 0.0058
DEBUG - 2016-06-29 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:06:55 --> hola
DEBUG - 2016-06-29 14:06:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:06:55 --> Total execution time: 0.0038
DEBUG - 2016-06-29 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:06:55 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:07:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:07:00 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/Blog/application/controllers/Project/Clogin2.php 18
DEBUG - 2016-06-29 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:07:31 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/Clogin2.php 18
DEBUG - 2016-06-29 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:07:53 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/Blog/application/controllers/Project/Clogin2.php 18
DEBUG - 2016-06-29 14:08:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:08:15 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/Clogin2.php 29
DEBUG - 2016-06-29 14:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:08:30 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/Clogin2.php 43
DEBUG - 2016-06-29 14:08:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:08:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Mregister /var/www/html/Blog/system/core/Loader.php 344
DEBUG - 2016-06-29 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:19:13 --> Total execution time: 0.0073
DEBUG - 2016-06-29 14:19:49 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:19:49 --> Total execution time: 0.0043
DEBUG - 2016-06-29 14:21:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:21:41 --> Total execution time: 0.0062
DEBUG - 2016-06-29 14:21:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:21:43 --> hola
DEBUG - 2016-06-29 14:21:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-29 14:21:43 --> Severity: Notice --> Undefined variable: error /var/www/html/Blog/application/views/Project/Login view.php 22
DEBUG - 2016-06-29 14:21:43 --> Total execution time: 0.0065
DEBUG - 2016-06-29 14:22:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:22:22 --> hola
DEBUG - 2016-06-29 14:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:22:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:22:44 --> hola
DEBUG - 2016-06-29 14:22:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:23:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:23:07 --> hola
DEBUG - 2016-06-29 14:23:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:30:14 --> Total execution time: 0.0066
DEBUG - 2016-06-29 14:30:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:30:19 --> hola
DEBUG - 2016-06-29 14:30:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-29 14:30:19 --> Severity: Notice --> Undefined variable: error /var/www/html/Blog/application/views/Project/Login view.php 23
DEBUG - 2016-06-29 14:30:19 --> Total execution time: 0.0060
DEBUG - 2016-06-29 14:30:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:30:19 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:30:33 --> hola
DEBUG - 2016-06-29 14:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:30:33 --> Total execution time: 0.0038
DEBUG - 2016-06-29 14:30:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:30:34 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:30:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:30:42 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/Blog/application/models/Project/Mregister.php 86
DEBUG - 2016-06-29 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:31:05 --> Severity: Warning --> Missing argument 1 for Clogin2::login() /var/www/html/Blog/application/controllers/Project/Clogin2.php 14
ERROR - 2016-06-29 14:31:05 --> Severity: Warning --> Missing argument 2 for Clogin2::login() /var/www/html/Blog/application/controllers/Project/Clogin2.php 14
ERROR - 2016-06-29 14:31:05 --> Severity: Warning --> Missing argument 3 for Clogin2::login() /var/www/html/Blog/application/controllers/Project/Clogin2.php 14
ERROR - 2016-06-29 14:31:05 --> Severity: Warning --> Missing argument 4 for Clogin2::login() /var/www/html/Blog/application/controllers/Project/Clogin2.php 14
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Undefined variable: name /var/www/html/Blog/application/controllers/Project/Clogin2.php 18
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/Clogin2.php 19
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Undefined variable: pass /var/www/html/Blog/application/controllers/Project/Clogin2.php 20
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Undefined variable: email /var/www/html/Blog/application/controllers/Project/Clogin2.php 22
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Undefined variable: ths /var/www/html/Blog/application/controllers/Project/Clogin2.php 44
ERROR - 2016-06-29 14:31:05 --> Severity: Notice --> Trying to get property of non-object /var/www/html/Blog/application/controllers/Project/Clogin2.php 44
ERROR - 2016-06-29 14:31:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/Blog/system/core/Exceptions.php:272) /var/www/html/Blog/system/core/Common.php 573
ERROR - 2016-06-29 14:31:05 --> Severity: Error --> Call to a member function is_numeric() on a non-object /var/www/html/Blog/application/controllers/Project/Clogin2.php 44
DEBUG - 2016-06-29 14:35:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:35:58 --> Severity: Parsing Error --> syntax error, unexpected 'login' (T_STRING), expecting '(' /var/www/html/Blog/application/controllers/Project/Clogin2.php 100
DEBUG - 2016-06-29 14:36:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:36:22 --> Total execution time: 0.0034
DEBUG - 2016-06-29 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:36:26 --> hola
DEBUG - 2016-06-29 14:36:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:36:26 --> Total execution time: 0.0068
DEBUG - 2016-06-29 14:36:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:36:35 --> Total execution time: 0.0046
DEBUG - 2016-06-29 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:36:37 --> hola
DEBUG - 2016-06-29 14:36:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:36:37 --> Total execution time: 0.0055
DEBUG - 2016-06-29 14:40:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:40:59 --> hola
DEBUG - 2016-06-29 14:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:40:59 --> Total execution time: 0.0047
DEBUG - 2016-06-29 14:40:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:40:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:40:59 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:41:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:41:06 --> Total execution time: 0.0065
DEBUG - 2016-06-29 14:41:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:41:08 --> hola
DEBUG - 2016-06-29 14:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:41:08 --> Total execution time: 0.0066
DEBUG - 2016-06-29 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:41:33 --> hola
DEBUG - 2016-06-29 14:41:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:41:33 --> Total execution time: 0.0035
DEBUG - 2016-06-29 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:41:33 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:41:37 --> Total execution time: 0.0046
DEBUG - 2016-06-29 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:41:38 --> hola
DEBUG - 2016-06-29 14:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:41:38 --> Total execution time: 0.0033
DEBUG - 2016-06-29 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:44:03 --> Total execution time: 0.0055
DEBUG - 2016-06-29 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:45:05 --> hola
DEBUG - 2016-06-29 14:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:45:05 --> Total execution time: 0.0061
DEBUG - 2016-06-29 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:45:37 --> Total execution time: 0.0056
DEBUG - 2016-06-29 14:45:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:45:40 --> hola
DEBUG - 2016-06-29 14:45:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:45:40 --> Total execution time: 0.0060
DEBUG - 2016-06-29 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:55:27 --> hola
DEBUG - 2016-06-29 14:55:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:55:27 --> Total execution time: 0.0056
DEBUG - 2016-06-29 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:55:27 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:55:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:55:33 --> Total execution time: 0.0057
DEBUG - 2016-06-29 14:55:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:55:35 --> hola
DEBUG - 2016-06-29 14:55:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:55:35 --> Total execution time: 0.0044
DEBUG - 2016-06-29 14:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:55:59 --> Total execution time: 0.0046
DEBUG - 2016-06-29 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:56:00 --> hola
DEBUG - 2016-06-29 14:56:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:56:00 --> Total execution time: 0.0033
DEBUG - 2016-06-29 14:56:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:56:54 --> hola
DEBUG - 2016-06-29 14:56:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:56:54 --> Total execution time: 0.0058
DEBUG - 2016-06-29 14:56:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:56:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:56:54 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:57:03 --> Total execution time: 0.0070
DEBUG - 2016-06-29 14:57:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:57:06 --> hola
DEBUG - 2016-06-29 14:57:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:57:06 --> Total execution time: 0.0057
DEBUG - 2016-06-29 14:57:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:57:17 --> Total execution time: 0.0062
DEBUG - 2016-06-29 14:57:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:57:19 --> hola
DEBUG - 2016-06-29 14:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:57:19 --> Total execution time: 0.0055
DEBUG - 2016-06-29 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:58:45 --> hola
DEBUG - 2016-06-29 14:58:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:58:45 --> Total execution time: 0.0050
DEBUG - 2016-06-29 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 14:58:45 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 14:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:58:54 --> Total execution time: 0.0062
DEBUG - 2016-06-29 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 14:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 14:58:56 --> hola
DEBUG - 2016-06-29 14:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 14:58:56 --> Total execution time: 0.0061
DEBUG - 2016-06-29 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:00:18 --> hola
DEBUG - 2016-06-29 15:00:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:00:18 --> Total execution time: 0.0055
DEBUG - 2016-06-29 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:00:18 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:00:25 --> Total execution time: 0.0070
DEBUG - 2016-06-29 15:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:00:29 --> hola
DEBUG - 2016-06-29 15:00:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:00:29 --> Total execution time: 0.0066
DEBUG - 2016-06-29 15:00:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:00:35 --> Total execution time: 0.0055
DEBUG - 2016-06-29 15:00:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:00:41 --> hola
DEBUG - 2016-06-29 15:00:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:00:41 --> Total execution time: 0.0061
DEBUG - 2016-06-29 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:02:40 --> Total execution time: 0.0059
DEBUG - 2016-06-29 15:02:43 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:02:43 --> hola
DEBUG - 2016-06-29 15:02:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:02:43 --> Total execution time: 0.0065
DEBUG - 2016-06-29 15:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:06:23 --> Total execution time: 0.0053
DEBUG - 2016-06-29 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:06:31 --> hola
DEBUG - 2016-06-29 15:06:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:06:31 --> Total execution time: 0.0062
DEBUG - 2016-06-29 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:10:10 --> hola
DEBUG - 2016-06-29 15:10:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:10:10 --> Total execution time: 0.0034
DEBUG - 2016-06-29 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:10:10 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:10:22 --> Total execution time: 0.0077
DEBUG - 2016-06-29 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:10:27 --> hola
DEBUG - 2016-06-29 15:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:10:27 --> Total execution time: 0.0063
DEBUG - 2016-06-29 15:11:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:11:00 --> hola
DEBUG - 2016-06-29 15:11:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:11:00 --> Total execution time: 0.0049
DEBUG - 2016-06-29 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:11:01 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:11:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:11:15 --> Total execution time: 0.0048
DEBUG - 2016-06-29 15:11:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:11:18 --> hola
DEBUG - 2016-06-29 15:11:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:11:18 --> Total execution time: 0.0057
DEBUG - 2016-06-29 15:12:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:12:22 --> Total execution time: 0.0066
DEBUG - 2016-06-29 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:12:23 --> hola
DEBUG - 2016-06-29 15:12:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:12:23 --> Total execution time: 0.0048
DEBUG - 2016-06-29 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:13:57 --> Total execution time: 0.0062
DEBUG - 2016-06-29 15:13:58 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:13:58 --> hola
DEBUG - 2016-06-29 15:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:13:58 --> Total execution time: 0.0036
DEBUG - 2016-06-29 15:18:31 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:18:31 --> hola
DEBUG - 2016-06-29 15:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:18:31 --> Total execution time: 0.0058
DEBUG - 2016-06-29 15:18:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:18:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:18:32 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:18:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:18:35 --> Total execution time: 0.0063
DEBUG - 2016-06-29 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:18:36 --> hola
DEBUG - 2016-06-29 15:18:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:18:36 --> Total execution time: 0.0033
DEBUG - 2016-06-29 15:19:48 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:19:48 --> Total execution time: 0.0055
DEBUG - 2016-06-29 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:20:09 --> hola
DEBUG - 2016-06-29 15:20:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:20:09 --> Total execution time: 0.0058
DEBUG - 2016-06-29 15:20:16 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:20:16 --> Total execution time: 0.0048
DEBUG - 2016-06-29 15:20:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:20:17 --> hola
DEBUG - 2016-06-29 15:20:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:20:17 --> Total execution time: 0.0042
DEBUG - 2016-06-29 15:20:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:20:25 --> Total execution time: 0.0064
DEBUG - 2016-06-29 15:29:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:29:22 --> hola
DEBUG - 2016-06-29 15:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:29:22 --> Total execution time: 0.0055
DEBUG - 2016-06-29 15:29:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:29:23 --> hola
DEBUG - 2016-06-29 15:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:29:23 --> Total execution time: 0.0053
DEBUG - 2016-06-29 15:29:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:29:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:29:23 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:29:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:29:28 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) /var/www/html/Blog/application/controllers/Project/Clogin2.php 77
DEBUG - 2016-06-29 15:30:10 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:30:10 --> Total execution time: 0.0071
DEBUG - 2016-06-29 15:31:04 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:31:04 --> Total execution time: 0.0066
DEBUG - 2016-06-29 15:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:32:07 --> Total execution time: 0.0074
DEBUG - 2016-06-29 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:32:13 --> hola
DEBUG - 2016-06-29 15:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:32:13 --> Total execution time: 0.0049
DEBUG - 2016-06-29 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:32:39 --> hola
DEBUG - 2016-06-29 15:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:32:39 --> Total execution time: 0.0050
DEBUG - 2016-06-29 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:32:39 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:32:46 --> Total execution time: 0.0068
DEBUG - 2016-06-29 15:37:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:37:47 --> Total execution time: 0.0074
DEBUG - 2016-06-29 15:37:57 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:37:57 --> hola
DEBUG - 2016-06-29 15:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:37:57 --> Total execution time: 0.0064
DEBUG - 2016-06-29 15:38:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:38:06 --> Total execution time: 0.0056
DEBUG - 2016-06-29 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:38:09 --> hola
DEBUG - 2016-06-29 15:38:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:38:09 --> Total execution time: 0.0060
DEBUG - 2016-06-29 15:39:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:39:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 15:39:59 --> hola
DEBUG - 2016-06-29 15:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:39:59 --> Total execution time: 0.0038
DEBUG - 2016-06-29 15:40:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 15:40:00 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 15:40:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:40:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 15:40:05 --> Total execution time: 0.0054
DEBUG - 2016-06-29 15:40:07 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 15:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 15:40:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 15:40:07 --> hola
DEBUG - 2016-06-29 15:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 15:40:07 --> Total execution time: 0.0037
DEBUG - 2016-06-29 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:11:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:11:21 --> hola
DEBUG - 2016-06-29 22:11:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:11:21 --> Total execution time: 0.0047
DEBUG - 2016-06-29 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:11:21 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:11:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:11:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:11:26 --> Total execution time: 0.0037
DEBUG - 2016-06-29 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:11:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:11:28 --> hola
DEBUG - 2016-06-29 22:11:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:11:28 --> Total execution time: 0.0033
DEBUG - 2016-06-29 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:13:19 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:13:19 --> hola
DEBUG - 2016-06-29 22:13:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:13:19 --> Total execution time: 0.0036
DEBUG - 2016-06-29 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:13:19 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:13:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:13:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:13:24 --> Total execution time: 0.0040
DEBUG - 2016-06-29 22:13:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:13:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:13:27 --> hola
DEBUG - 2016-06-29 22:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:13:27 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:13:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:13:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:13:59 --> hola
DEBUG - 2016-06-29 22:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:13:59 --> Total execution time: 0.0035
DEBUG - 2016-06-29 22:13:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:13:59 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:14:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:14:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:14:08 --> Total execution time: 0.0042
DEBUG - 2016-06-29 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:14:12 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:14:12 --> hola
DEBUG - 2016-06-29 22:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:14:12 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:25:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:25:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-29 22:25:00 --> Severity: Notice --> Undefined property: CI_Form_validation::$_errors_array /var/www/html/Blog/application/controllers/Project/Clogin2.php 96
ERROR - 2016-06-29 22:25:00 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/Blog/application/controllers/Project/Clogin2.php 97
DEBUG - 2016-06-29 22:25:00 --> Total execution time: 0.0045
DEBUG - 2016-06-29 22:25:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:25:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:25:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-06-29 22:25:18 --> Severity: Notice --> Undefined property: Clogin2::$_errors_array /var/www/html/Blog/application/controllers/Project/Clogin2.php 96
ERROR - 2016-06-29 22:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/Blog/application/controllers/Project/Clogin2.php 97
DEBUG - 2016-06-29 22:25:18 --> Total execution time: 0.0046
DEBUG - 2016-06-29 22:25:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:25:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:25:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:25:33 --> Total execution time: 0.0044
DEBUG - 2016-06-29 22:25:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:25:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:25:40 --> hola
DEBUG - 2016-06-29 22:25:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:25:40 --> Total execution time: 0.0033
DEBUG - 2016-06-29 22:36:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:36:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:36:34 --> hola
DEBUG - 2016-06-29 22:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:36:34 --> Total execution time: 0.0040
DEBUG - 2016-06-29 22:36:34 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:36:34 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:36:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:36:40 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:36:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:36:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:36:43 --> hola
DEBUG - 2016-06-29 22:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:36:43 --> Total execution time: 0.0033
DEBUG - 2016-06-29 22:36:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:36:53 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:36:53 --> hola
DEBUG - 2016-06-29 22:36:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:36:53 --> Total execution time: 0.0035
DEBUG - 2016-06-29 22:36:53 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:36:53 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:36:59 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:36:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:36:59 --> Total execution time: 0.0049
DEBUG - 2016-06-29 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:37:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:37:00 --> hola
DEBUG - 2016-06-29 22:37:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:37:00 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:37:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:37:17 --> hola
DEBUG - 2016-06-29 22:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:37:17 --> Total execution time: 0.0036
DEBUG - 2016-06-29 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:37:18 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:37:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:37:23 --> hola
DEBUG - 2016-06-29 22:37:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:37:23 --> Total execution time: 0.0050
DEBUG - 2016-06-29 22:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:37:23 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:37:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:37:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:37:32 --> hola
DEBUG - 2016-06-29 22:37:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:37:32 --> Total execution time: 0.0035
DEBUG - 2016-06-29 22:37:32 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:37:32 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:53:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:53:17 --> hola
DEBUG - 2016-06-29 22:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:53:17 --> Total execution time: 0.0041
DEBUG - 2016-06-29 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:53:17 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:53:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:53:33 --> hola
DEBUG - 2016-06-29 22:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:53:33 --> Total execution time: 0.0037
DEBUG - 2016-06-29 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:53:33 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:53:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:53:37 --> hola
DEBUG - 2016-06-29 22:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:53:37 --> Total execution time: 0.0036
DEBUG - 2016-06-29 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:53:37 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:53:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:53:41 --> hola
DEBUG - 2016-06-29 22:53:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:53:41 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:53:41 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:53:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:53:55 --> hola
DEBUG - 2016-06-29 22:53:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:53:55 --> Total execution time: 0.0039
DEBUG - 2016-06-29 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:53:55 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:54:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:54:01 --> hola
DEBUG - 2016-06-29 22:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:54:01 --> Total execution time: 0.0040
DEBUG - 2016-06-29 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:54:02 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:54:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:54:29 --> hola
DEBUG - 2016-06-29 22:54:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:54:29 --> Total execution time: 0.0042
DEBUG - 2016-06-29 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:54:29 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:54:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:54:35 --> hola
DEBUG - 2016-06-29 22:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:54:35 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:54:35 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:55:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:55:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:55:06 --> hola
DEBUG - 2016-06-29 22:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:55:06 --> Total execution time: 0.0037
DEBUG - 2016-06-29 22:55:06 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:06 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:55:09 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:09 --> 404 Page Not Found: Project/Clogin/Clogin2
DEBUG - 2016-06-29 22:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:22 --> 404 Page Not Found: Project/Clogin/Clogin2
DEBUG - 2016-06-29 22:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:55:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:55:25 --> hola
DEBUG - 2016-06-29 22:55:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:55:25 --> Total execution time: 0.0043
DEBUG - 2016-06-29 22:55:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:26 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:29 --> 404 Page Not Found: Project/Clogin/login2
DEBUG - 2016-06-29 22:55:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:55:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:55:44 --> hola
DEBUG - 2016-06-29 22:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:55:44 --> Total execution time: 0.0038
DEBUG - 2016-06-29 22:55:45 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:45 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:55:47 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:55:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:55:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:55:47 --> Total execution time: 0.0040
DEBUG - 2016-06-29 22:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:55:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:55:54 --> hola
DEBUG - 2016-06-29 22:55:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:55:54 --> Total execution time: 0.0038
DEBUG - 2016-06-29 22:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:55:54 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:59:25 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:59:25 --> hola
DEBUG - 2016-06-29 22:59:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:59:25 --> Total execution time: 0.0035
DEBUG - 2016-06-29 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:59:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:59:25 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 22:59:33 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:59:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:59:33 --> Total execution time: 0.0046
DEBUG - 2016-06-29 22:59:38 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 22:59:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 22:59:38 --> hola
DEBUG - 2016-06-29 22:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 22:59:38 --> Total execution time: 0.0034
DEBUG - 2016-06-29 22:59:39 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 22:59:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 22:59:39 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:00:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:00:08 --> hola
DEBUG - 2016-06-29 23:00:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:00:08 --> Total execution time: 0.0039
DEBUG - 2016-06-29 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:00:08 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:00:13 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:00:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:00:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:00:13 --> Total execution time: 0.0039
DEBUG - 2016-06-29 23:00:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:00:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:00:17 --> hola
DEBUG - 2016-06-29 23:00:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:00:17 --> Total execution time: 0.0033
DEBUG - 2016-06-29 23:00:17 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:00:17 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:00:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:00:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:00:41 --> hola
DEBUG - 2016-06-29 23:00:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:00:41 --> Total execution time: 0.0038
DEBUG - 2016-06-29 23:00:42 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:00:42 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:00:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:00:44 --> hola
DEBUG - 2016-06-29 23:00:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:00:44 --> Total execution time: 0.0040
DEBUG - 2016-06-29 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:00:44 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:01:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:01:21 --> hola
DEBUG - 2016-06-29 23:01:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:01:21 --> Total execution time: 0.0039
DEBUG - 2016-06-29 23:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:01:21 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:01:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:01:23 --> hola
DEBUG - 2016-06-29 23:01:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:01:23 --> Total execution time: 0.0032
DEBUG - 2016-06-29 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:01:23 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:01:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:01:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:01:26 --> hola
DEBUG - 2016-06-29 23:01:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:01:26 --> Total execution time: 0.0034
DEBUG - 2016-06-29 23:01:26 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:01:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:01:26 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:02:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:02:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:02:27 --> hola
DEBUG - 2016-06-29 23:02:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:02:27 --> Total execution time: 0.0041
DEBUG - 2016-06-29 23:02:27 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:02:27 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:02:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:02:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:02:29 --> hola
DEBUG - 2016-06-29 23:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:02:29 --> Total execution time: 0.0033
DEBUG - 2016-06-29 23:02:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:02:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:02:29 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:03:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:03:15 --> hola
DEBUG - 2016-06-29 23:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:03:15 --> Total execution time: 0.0040
DEBUG - 2016-06-29 23:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:03:15 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:03:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:03:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:03:29 --> hola
DEBUG - 2016-06-29 23:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:03:29 --> Total execution time: 0.0038
DEBUG - 2016-06-29 23:03:29 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:03:29 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:03:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:03:41 --> hola
DEBUG - 2016-06-29 23:03:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:03:41 --> Total execution time: 0.0034
DEBUG - 2016-06-29 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:03:41 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:04:01 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:04:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:04:01 --> hola
DEBUG - 2016-06-29 23:04:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:04:01 --> Total execution time: 0.0034
DEBUG - 2016-06-29 23:04:02 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:04:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:04:02 --> 404 Page Not Found: Application/css
DEBUG - 2016-06-29 23:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-29 23:04:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-06-29 23:04:05 --> hola
DEBUG - 2016-06-29 23:04:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-06-29 23:04:05 --> Total execution time: 0.0034
DEBUG - 2016-06-29 23:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-06-29 23:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-06-29 23:04:05 --> 404 Page Not Found: Application/css
