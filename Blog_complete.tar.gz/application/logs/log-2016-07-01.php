<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2016-07-01 09:23:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:23:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:23:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:23:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:23:59 --> Total execution time: 0.2792
DEBUG - 2016-07-01 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:24:35 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-07-01 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:24:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:24:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:48 --> Total execution time: 0.0040
DEBUG - 2016-07-01 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:24:50 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:24:50 --> hola
DEBUG - 2016-07-01 09:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:50 --> Total execution time: 0.0033
DEBUG - 2016-07-01 09:24:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:24:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:24:52 --> hola
DEBUG - 2016-07-01 09:24:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:52 --> Total execution time: 0.0034
DEBUG - 2016-07-01 09:24:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:24:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:56 --> Total execution time: 0.0036
DEBUG - 2016-07-01 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:24:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:24:58 --> hola
DEBUG - 2016-07-01 09:24:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:24:58 --> Total execution time: 0.0033
DEBUG - 2016-07-01 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:25:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:25:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:25:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:25:05 --> Total execution time: 0.0501
DEBUG - 2016-07-01 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:25:17 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-07-01 09:25:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:25:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:25:20 --> hola
DEBUG - 2016-07-01 09:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:25:20 --> Total execution time: 0.0037
DEBUG - 2016-07-01 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:36:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:36:02 --> hola
DEBUG - 2016-07-01 09:36:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:36:02 --> Total execution time: 0.7460
DEBUG - 2016-07-01 09:36:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:36:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:36:16 --> Total execution time: 0.0509
DEBUG - 2016-07-01 09:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:39:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:28 --> Total execution time: 0.0151
DEBUG - 2016-07-01 09:39:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:39:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:40 --> Total execution time: 0.0168
DEBUG - 2016-07-01 09:39:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:39:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:39:59 --> Total execution time: 0.0166
DEBUG - 2016-07-01 09:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:40:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:06 --> Total execution time: 0.0162
DEBUG - 2016-07-01 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:40:26 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:40:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:26 --> Total execution time: 0.0084
DEBUG - 2016-07-01 09:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:40:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:40:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:45 --> Total execution time: 0.0044
DEBUG - 2016-07-01 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:40:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:40:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:40:58 --> Total execution time: 0.0046
DEBUG - 2016-07-01 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:41:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:20 --> Total execution time: 0.0046
DEBUG - 2016-07-01 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:41:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:31 --> Total execution time: 0.0043
DEBUG - 2016-07-01 09:41:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:41:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:39 --> Total execution time: 0.0043
DEBUG - 2016-07-01 09:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:41:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:41:48 --> Total execution time: 0.0045
DEBUG - 2016-07-01 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:42:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:05 --> Total execution time: 0.0043
DEBUG - 2016-07-01 09:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:42:23 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:42:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:23 --> Total execution time: 0.0065
DEBUG - 2016-07-01 09:42:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:42:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:35 --> Total execution time: 0.0042
DEBUG - 2016-07-01 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:42:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:42:54 --> Total execution time: 0.0048
DEBUG - 2016-07-01 09:43:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:05 --> Total execution time: 0.0045
DEBUG - 2016-07-01 09:43:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:17 --> Total execution time: 0.0044
DEBUG - 2016-07-01 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:24 --> Total execution time: 0.0041
DEBUG - 2016-07-01 09:43:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:29 --> Total execution time: 0.0066
DEBUG - 2016-07-01 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:35 --> hola
DEBUG - 2016-07-01 09:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:35 --> Total execution time: 0.0071
DEBUG - 2016-07-01 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:39 --> Total execution time: 0.0067
DEBUG - 2016-07-01 09:43:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:43:55 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-07-01 09:43:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:43:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:43:58 --> hola
DEBUG - 2016-07-01 09:43:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:43:58 --> Total execution time: 0.0059
DEBUG - 2016-07-01 09:44:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:44:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:44:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:44:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:44:21 --> Total execution time: 0.0798
DEBUG - 2016-07-01 09:44:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:44:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:44:27 --> 404 Page Not Found: Project/Clogin/Clogin
DEBUG - 2016-07-01 09:44:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:44:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:44:29 --> hola
DEBUG - 2016-07-01 09:44:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:44:29 --> Total execution time: 0.0036
DEBUG - 2016-07-01 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:46:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:46:56 --> Total execution time: 0.0079
DEBUG - 2016-07-01 09:46:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:46:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:46:59 --> hola
DEBUG - 2016-07-01 09:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:46:59 --> Total execution time: 0.0056
DEBUG - 2016-07-01 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:47:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:47:06 --> Total execution time: 0.0068
DEBUG - 2016-07-01 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:47:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:47:08 --> hola
DEBUG - 2016-07-01 09:47:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:47:08 --> Total execution time: 0.0059
DEBUG - 2016-07-01 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:50:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:50:58 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/Clogin.php 82
DEBUG - 2016-07-01 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:51:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:51:10 --> hola
DEBUG - 2016-07-01 09:51:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:51:10 --> Total execution time: 0.0048
DEBUG - 2016-07-01 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:51:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:51:28 --> Total execution time: 0.0738
DEBUG - 2016-07-01 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:51:28 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:51:28 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:52:15 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:52:15 --> Total execution time: 0.0067
DEBUG - 2016-07-01 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:52:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:52:20 --> hola
DEBUG - 2016-07-01 09:52:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:52:20 --> Total execution time: 0.0058
DEBUG - 2016-07-01 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 09:57:44 --> Severity: Parsing Error --> syntax error, unexpected '*' /var/www/html/Blog/application/controllers/Project/Clogin2.php 3
DEBUG - 2016-07-01 09:58:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:58:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:58:07 --> hola
DEBUG - 2016-07-01 09:58:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:58:07 --> Total execution time: 0.0063
DEBUG - 2016-07-01 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:58:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:58:17 --> Total execution time: 0.0129
DEBUG - 2016-07-01 09:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:58:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:58:24 --> hola
DEBUG - 2016-07-01 09:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:58:24 --> Total execution time: 0.0133
DEBUG - 2016-07-01 09:59:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:59:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:59:08 --> hola
DEBUG - 2016-07-01 09:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:59:08 --> Total execution time: 0.0068
DEBUG - 2016-07-01 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:59:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:59:40 --> hola
DEBUG - 2016-07-01 09:59:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:59:40 --> Total execution time: 0.0042
DEBUG - 2016-07-01 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 09:59:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 09:59:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 09:59:54 --> Total execution time: 0.0049
DEBUG - 2016-07-01 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:00:18 --> 404 Page Not Found: Project/Clogin2/Clogin
DEBUG - 2016-07-01 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:00:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:00:24 --> hola
DEBUG - 2016-07-01 10:00:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:00:24 --> Total execution time: 0.0059
DEBUG - 2016-07-01 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:00:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:00:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:00:33 --> Total execution time: 0.0058
DEBUG - 2016-07-01 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:00:40 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:00:40 --> hola
DEBUG - 2016-07-01 10:00:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:00:40 --> Total execution time: 0.0054
DEBUG - 2016-07-01 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:00:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:00:48 --> Total execution time: 0.0068
DEBUG - 2016-07-01 10:00:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:00:56 --> 404 Page Not Found: Project/Clogin2/Clogin
DEBUG - 2016-07-01 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:00:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:00:59 --> hola
DEBUG - 2016-07-01 10:00:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:00:59 --> Total execution time: 0.0072
DEBUG - 2016-07-01 10:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:01 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:01:01 --> Total execution time: 0.0062
DEBUG - 2016-07-01 10:01:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:04 --> hola
DEBUG - 2016-07-01 10:01:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:01:04 --> Total execution time: 0.0060
DEBUG - 2016-07-01 10:01:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:01:09 --> Total execution time: 0.0066
DEBUG - 2016-07-01 10:01:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:11 --> hola
DEBUG - 2016-07-01 10:01:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:01:11 --> Total execution time: 0.0040
DEBUG - 2016-07-01 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:27 --> Total execution time: 0.0071
DEBUG - 2016-07-01 10:01:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:01:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:01:29 --> hola
DEBUG - 2016-07-01 10:01:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:01:29 --> Total execution time: 0.0062
DEBUG - 2016-07-01 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:03:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:03:04 --> hola
DEBUG - 2016-07-01 10:03:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:03:04 --> Total execution time: 0.0092
DEBUG - 2016-07-01 10:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:03:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:03:11 --> Total execution time: 0.0073
DEBUG - 2016-07-01 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:03:42 --> 404 Page Not Found: Project/Clogin2/Clogin
DEBUG - 2016-07-01 10:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:03:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:03:45 --> hola
DEBUG - 2016-07-01 10:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:03:45 --> Total execution time: 0.0054
DEBUG - 2016-07-01 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:04:18 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:04:18 --> Total execution time: 0.0068
DEBUG - 2016-07-01 10:04:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:04:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:04:24 --> hola
DEBUG - 2016-07-01 10:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:04:24 --> Total execution time: 0.0065
DEBUG - 2016-07-01 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:04:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:04:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:04:37 --> Total execution time: 0.0069
DEBUG - 2016-07-01 10:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:04:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:04:39 --> hola
DEBUG - 2016-07-01 10:04:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:04:39 --> Total execution time: 0.0035
DEBUG - 2016-07-01 10:04:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:04:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:04:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:04:58 --> Total execution time: 0.0072
DEBUG - 2016-07-01 10:05:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:05:02 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:05:02 --> hola
DEBUG - 2016-07-01 10:05:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:05:02 --> Total execution time: 0.0066
DEBUG - 2016-07-01 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:05:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:05:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:05:36 --> Total execution time: 0.0042
DEBUG - 2016-07-01 10:05:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:05:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:05:37 --> hola
DEBUG - 2016-07-01 10:05:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:05:37 --> Total execution time: 0.0032
DEBUG - 2016-07-01 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:05:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:05:44 --> Total execution time: 0.0053
DEBUG - 2016-07-01 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:06:29 --> 404 Page Not Found: Project/Clogin2/Clogin
DEBUG - 2016-07-01 10:06:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:06:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:06:32 --> hola
DEBUG - 2016-07-01 10:06:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:06:32 --> Total execution time: 0.0104
DEBUG - 2016-07-01 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:06:48 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:06:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:06:48 --> Total execution time: 0.0070
DEBUG - 2016-07-01 10:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:07:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:07:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:07:09 --> Total execution time: 0.0053
DEBUG - 2016-07-01 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:07:27 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:07:27 --> Total execution time: 0.0049
DEBUG - 2016-07-01 10:07:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:07:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:07:32 --> Total execution time: 0.0045
DEBUG - 2016-07-01 10:07:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:07:38 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:07:38 --> hola
DEBUG - 2016-07-01 10:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:07:38 --> Total execution time: 0.0079
DEBUG - 2016-07-01 10:07:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:07:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:07:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:07:52 --> Total execution time: 0.0049
DEBUG - 2016-07-01 10:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:08 --> hola
DEBUG - 2016-07-01 10:08:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:08:08 --> Total execution time: 0.0069
DEBUG - 2016-07-01 10:08:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:08:14 --> Total execution time: 0.0080
DEBUG - 2016-07-01 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:17 --> hola
DEBUG - 2016-07-01 10:08:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:08:17 --> Total execution time: 0.0054
DEBUG - 2016-07-01 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:30 --> Total execution time: 0.0073
DEBUG - 2016-07-01 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:32 --> hola
DEBUG - 2016-07-01 10:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:08:32 --> Total execution time: 0.0058
DEBUG - 2016-07-01 10:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:08:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:08:55 --> hola
DEBUG - 2016-07-01 10:08:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:08:55 --> Total execution time: 0.0042
DEBUG - 2016-07-01 10:09:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:09:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:09:03 --> Total execution time: 0.0075
DEBUG - 2016-07-01 10:09:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:09:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:09:04 --> hola
DEBUG - 2016-07-01 10:09:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:09:04 --> Total execution time: 0.0066
DEBUG - 2016-07-01 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:31:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:31:18 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/Clogin2.php 12
DEBUG - 2016-07-01 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:31:38 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting variable (T_VARIABLE) or '$' /var/www/html/Blog/application/controllers/Project/Clogin2.php 119
DEBUG - 2016-07-01 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:32:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:32:00 --> hola
DEBUG - 2016-07-01 10:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:32:00 --> Total execution time: 0.0079
DEBUG - 2016-07-01 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:32:16 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:32:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:32:16 --> Total execution time: 0.0068
DEBUG - 2016-07-01 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:33:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:33:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:33:20 --> Total execution time: 0.0048
DEBUG - 2016-07-01 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:33:21 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:33:21 --> hola
DEBUG - 2016-07-01 10:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:33:21 --> Total execution time: 0.0041
DEBUG - 2016-07-01 10:34:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:34:07 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:34:07 --> hola
ERROR - 2016-07-01 10:34:07 --> Severity: Notice --> Undefined property: Clogin2::$lod /var/www/html/Blog/application/controllers/Project/Clogin2.php 11
ERROR - 2016-07-01 10:34:07 --> Severity: Error --> Call to a member function view() on a non-object /var/www/html/Blog/application/controllers/Project/Clogin2.php 11
DEBUG - 2016-07-01 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:34:17 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:34:17 --> hola
DEBUG - 2016-07-01 10:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:34:17 --> Total execution time: 0.0068
DEBUG - 2016-07-01 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:34:39 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:34:39 --> hola
DEBUG - 2016-07-01 10:34:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:34:39 --> Total execution time: 0.0043
DEBUG - 2016-07-01 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:35:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:35:30 --> hola
DEBUG - 2016-07-01 10:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:35:30 --> Total execution time: 0.0039
DEBUG - 2016-07-01 10:38:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 10:38:09 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/Blog/application/controllers/Project/Clogin2.php 3
DEBUG - 2016-07-01 10:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 10:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 10:38:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 10:38:58 --> hola
DEBUG - 2016-07-01 10:38:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 10:38:58 --> Total execution time: 0.0093
DEBUG - 2016-07-01 13:36:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:36:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:36:29 --> Total execution time: 0.0523
DEBUG - 2016-07-01 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:36:47 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:36:47 --> Total execution time: 0.0036
DEBUG - 2016-07-01 13:36:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:36:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:36:59 --> Total execution time: 0.0037
DEBUG - 2016-07-01 13:37:04 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:37:04 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:37:04 --> Total execution time: 0.0033
DEBUG - 2016-07-01 13:37:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:37:54 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:37:54 --> Total execution time: 0.0039
DEBUG - 2016-07-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:37:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:37:58 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:37:58 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:37:58 --> Total execution time: 0.0047
DEBUG - 2016-07-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:37:58 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:37:58 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-01 13:37:58 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:39:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:39:28 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:39:28 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:39:28 --> Total execution time: 0.0054
DEBUG - 2016-07-01 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:28 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-01 13:39:28 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:29 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:30 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:39:30 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:39:30 --> Total execution time: 0.0804
DEBUG - 2016-07-01 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:39:36 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:39:36 --> Total execution time: 0.0040
DEBUG - 2016-07-01 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:39:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:39:42 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:39:42 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:39:42 --> Total execution time: 0.0049
DEBUG - 2016-07-01 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:43 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:43 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:43 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:39:43 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:40:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:40:44 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:40:44 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:40:44 --> Total execution time: 0.0048
DEBUG - 2016-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:40:44 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:40:44 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:40:44 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:40:44 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:42:24 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:42:24 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:42:24 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:42:24 --> Total execution time: 0.0049
DEBUG - 2016-07-01 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:42:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:42:45 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
ERROR - 2016-07-01 13:42:45 --> Severity: Notice --> Undefined variable: errror /var/www/html/Blog/application/controllers/Project/CRegister.php 62
DEBUG - 2016-07-01 13:42:45 --> Total execution time: 0.0047
DEBUG - 2016-07-01 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:45 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:45 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:45 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:42:45 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:43:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:43:37 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
DEBUG - 2016-07-01 13:43:37 --> Total execution time: 0.0050
DEBUG - 2016-07-01 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:43:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:43:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:43:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:43:37 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:44:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:44:20 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
DEBUG - 2016-07-01 13:44:20 --> Total execution time: 0.0045
DEBUG - 2016-07-01 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:44:20 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:44:20 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:44:20 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:44:20 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:45:13 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:45:13 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
DEBUG - 2016-07-01 13:45:13 --> Total execution time: 0.0069
DEBUG - 2016-07-01 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-01 13:45:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:45:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:45:14 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 13:46:11 --> Severity: Notice --> Undefined variable: uname /var/www/html/Blog/application/controllers/Project/CRegister.php 45
DEBUG - 2016-07-01 13:46:11 --> Total execution time: 0.0044
DEBUG - 2016-07-01 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:46:33 --> Total execution time: 0.0039
DEBUG - 2016-07-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:46:41 --> Total execution time: 0.0042
DEBUG - 2016-07-01 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:42 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:42 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-01 13:46:42 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:46:52 --> Total execution time: 0.0045
DEBUG - 2016-07-01 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:46:53 --> 404 Page Not Found: Assets/css
ERROR - 2016-07-01 13:46:53 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:46:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:46:56 --> Total execution time: 0.0032
DEBUG - 2016-07-01 13:54:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:54:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:54:58 --> Total execution time: 0.0043
DEBUG - 2016-07-01 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:55:00 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:55:00 --> Total execution time: 0.0037
DEBUG - 2016-07-01 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:00 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:00 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:00 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:00 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:55:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:55:03 --> Total execution time: 0.0035
DEBUG - 2016-07-01 13:55:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:55:20 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:55:20 --> Total execution time: 0.0047
DEBUG - 2016-07-01 13:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:21 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:21 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:21 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:21 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 13:55:21 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 13:55:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 13:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 13:55:32 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 13:55:32 --> Total execution time: 0.0033
DEBUG - 2016-07-01 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:15:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:15:34 --> Total execution time: 0.0043
DEBUG - 2016-07-01 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:37:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:37:58 --> hola
DEBUG - 2016-07-01 14:37:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:37:58 --> Total execution time: 0.0036
DEBUG - 2016-07-01 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:38:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:38:52 --> hola
DEBUG - 2016-07-01 14:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:38:52 --> Total execution time: 0.0036
DEBUG - 2016-07-01 14:38:55 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:38:55 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:38:55 --> Total execution time: 0.0036
DEBUG - 2016-07-01 14:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:38:58 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:38:58 --> hola
DEBUG - 2016-07-01 14:38:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:38:58 --> Total execution time: 0.0033
DEBUG - 2016-07-01 14:39:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:39:37 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:39:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:39:37 --> Total execution time: 0.0039
DEBUG - 2016-07-01 14:49:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:49:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:49:45 --> hola
DEBUG - 2016-07-01 14:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 14:49:45 --> Total execution time: 0.0034
DEBUG - 2016-07-01 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 14:54:25 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/Blog/application/controllers/Project/CRegister.php 87
DEBUG - 2016-07-01 14:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 14:55:40 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/Blog/application/controllers/Project/CRegister.php 87
DEBUG - 2016-07-01 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:55:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 14:55:46 --> Severity: Parsing Error --> syntax error, unexpected '=' /var/www/html/Blog/application/controllers/Project/CRegister.php 87
DEBUG - 2016-07-01 14:55:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:55:56 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 14:55:56 --> Total execution time: 0.0038
DEBUG - 2016-07-01 14:58:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:58:11 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 14:58:11 --> Severity: Notice --> Undefined variable: data /var/www/html/Blog/application/controllers/Project/CRegister.php 86
ERROR - 2016-07-01 14:58:11 --> Severity: Notice --> Undefined variable: email /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 12
DEBUG - 2016-07-01 14:58:11 --> Total execution time: 0.0069
DEBUG - 2016-07-01 14:58:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:58:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 14:58:33 --> Severity: Notice --> Undefined variable: email /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 12
DEBUG - 2016-07-01 14:58:33 --> Total execution time: 0.0058
DEBUG - 2016-07-01 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 14:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 14:59:35 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 14:59:35 --> Severity: Notice --> Undefined variable: email /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 12
DEBUG - 2016-07-01 14:59:35 --> Total execution time: 0.0058
DEBUG - 2016-07-01 15:00:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 15:00:11 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/Blog/application/controllers/Project/CRegister.php 88
DEBUG - 2016-07-01 15:00:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 15:00:23 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/Blog/application/controllers/Project/CRegister.php 88
DEBUG - 2016-07-01 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:00:34 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:00:34 --> Severity: Notice --> Undefined variable: email /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 12
DEBUG - 2016-07-01 15:00:34 --> Total execution time: 0.0054
DEBUG - 2016-07-01 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:01:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:01:14 --> Total execution time: 0.0053
DEBUG - 2016-07-01 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:02:41 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:02:41 --> Severity: Warning --> require(../../../../assets/css/prompt.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:02:41 --> Severity: Compile Error --> require(): Failed opening required '../../../../assets/css/prompt.css' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
DEBUG - 2016-07-01 15:03:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 15:03:12 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 15:03:25 --> 404 Page Not Found: Assets/css
DEBUG - 2016-07-01 15:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:03:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:03:28 --> Severity: Warning --> require(../../../../../assets/css/prompt.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:03:28 --> Severity: Compile Error --> require(): Failed opening required '../../../../../assets/css/prompt.css' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
DEBUG - 2016-07-01 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:03:58 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:04:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:04:29 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:04:29 --> Severity: Warning --> require(../../../../../assets/css/prompt.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:04:29 --> Severity: Compile Error --> require(): Failed opening required '../../../../../assets/css/prompt.css' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
DEBUG - 2016-07-01 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:04:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:04:43 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:04:43 --> Severity: Warning --> require(../../../../../assets/css/prompt.css): failed to open stream: No such file or directory /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:04:43 --> Severity: Compile Error --> require(): Failed opening required '../../../../../assets/css/prompt.css' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
DEBUG - 2016-07-01 15:08:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:08:33 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:08:33 --> Severity: Warning --> require(): http:// wrapper is disabled in the server configuration by allow_url_include=0 /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:08:33 --> Severity: Warning --> require(http://localhost/Blog/assets/css/prompt.css): failed to open stream: no suitable wrapper could be found /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
ERROR - 2016-07-01 15:08:33 --> Severity: Compile Error --> require(): Failed opening required 'http://localhost/Blog/assets/css/prompt.css' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/views/Project/Admin views/Prompt.php 2
DEBUG - 2016-07-01 15:08:42 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:08:42 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:08:42 --> Total execution time: 0.0044
DEBUG - 2016-07-01 15:09:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:09:08 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:09:08 --> Total execution time: 0.0047
DEBUG - 2016-07-01 15:15:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:15:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:15:44 --> Total execution time: 0.0047
DEBUG - 2016-07-01 15:56:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:56:44 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:56:44 --> Total execution time: 0.0043
DEBUG - 2016-07-01 15:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:56:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:56:45 --> Total execution time: 0.0031
DEBUG - 2016-07-01 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:57:28 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:57:28 --> Severity: Notice --> Undefined property: CRegister::$email /var/www/html/Blog/application/controllers/Project/CRegister.php 93
ERROR - 2016-07-01 15:57:28 --> Severity: Error --> Call to a member function initialize() on a non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 93
DEBUG - 2016-07-01 15:58:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:58:10 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
ERROR - 2016-07-01 15:58:10 --> Severity: Notice --> Undefined property: CRegister::$email /var/www/html/Blog/application/controllers/Project/CRegister.php 93
ERROR - 2016-07-01 15:58:10 --> Severity: Error --> Call to a member function from() on a non-object /var/www/html/Blog/application/controllers/Project/CRegister.php 93
DEBUG - 2016-07-01 15:59:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:59:09 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:59:09 --> Total execution time: 0.0898
DEBUG - 2016-07-01 15:59:59 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 15:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 15:59:59 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 15:59:59 --> Total execution time: 0.0492
DEBUG - 2016-07-01 16:07:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 16:07:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 16:07:29 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/Blog/application/controllers/Project/CRegister.php 96
DEBUG - 2016-07-01 16:12:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 16:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 16:12:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 16:12:52 --> Total execution time: 0.0043
DEBUG - 2016-07-01 16:13:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 16:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 16:13:14 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 16:13:15 --> Total execution time: 0.4660
DEBUG - 2016-07-01 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 16:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 16:21:30 --> Severity: Warning --> require(vendor/autoload.php): failed to open stream: No such file or directory /var/www/html/Blog/application/controllers/Project/Admin/Mail.php 4
ERROR - 2016-07-01 16:21:30 --> Severity: Compile Error --> require(): Failed opening required 'vendor/autoload.php' (include_path='.:/usr/share/php:/usr/share/pear') /var/www/html/Blog/application/controllers/Project/Admin/Mail.php 4
DEBUG - 2016-07-01 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 16:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-07-01 16:21:49 --> Severity: Error --> Class 'Mailgun\Mailgun' not found /var/www/html/Blog/application/controllers/Project/Admin/Mail.php 8
DEBUG - 2016-07-01 17:01:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:01:45 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:01:45 --> Total execution time: 0.0099
DEBUG - 2016-07-01 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:02:06 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:02:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 17:02:06 --> Total execution time: 0.7465
DEBUG - 2016-07-01 17:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:10:52 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:10:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 17:10:53 --> Total execution time: 0.5592
DEBUG - 2016-07-01 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:12:03 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:12:03 --> Total execution time: 0.0064
DEBUG - 2016-07-01 17:12:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:12:05 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:12:05 --> Total execution time: 0.0032
DEBUG - 2016-07-01 17:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-07-01 17:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-07-01 17:12:31 --> /var/www/html/Blog/application/libraries/MY_Form_validation.php exists, but does not declare MY_Form_validation
DEBUG - 2016-07-01 17:12:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2016-07-01 17:12:31 --> Total execution time: 0.4388
