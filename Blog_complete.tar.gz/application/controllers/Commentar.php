<?php 
/**
* 
*/
class Commentar extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	function index()
	{			

		
		
			

	}


	function crearComentario()
	{
		
		$fecha_com = date('d-m-Y');
		$username = 'Carlitos';

		$contenido = $this->input->post('contenido');
		$array = array('fecha_com' => $fecha_com,'username' => $username,'contenido' =>
			$contenido);
		$this->db->insert('Comentario',$array);

		$comentarios = $this->db->get('Comentario');

		$this->load->view('main_blog',$comentarios);


	}

	function eliminar()
	{
		// $query = $this->db->query("select * from Comentario");

			
		// foreach($query->result() as $row)
		// {
		// 		if (isset($row))
		// 		{
		//         		echo $row->id;
		//         		echo $row->fecha_com;
		//         		echo $row->contenido;
		//         		echo "<br>";
		// 		}
		
		// }		
		// #$data = $query->result();
		
		// $this->load->view('main_blog','Commentar/mostrar');
		// $id = $this->input->post('select_id');
		// $this->db->delete("Comentario","id = $id");
		$this->load->view('op_eliminar');


	}


	/**
	$fecha = $this->input->post('fecha');
		$username = $this->input->post('username');
		$contenido = $this->input->post('contenido');
		$array = array('fecha_com' => $fecha, 'username' => $username, 'contenido' => $contenido);
		if($this->input->post('confirm') === TRUE)
		{
			$this->db->delete('Users',$array);
			$comentarios = $this->db->get('Comentario');
			$this->load->view('main_blog',$comentarios);
		}
	**/

	
}
?>