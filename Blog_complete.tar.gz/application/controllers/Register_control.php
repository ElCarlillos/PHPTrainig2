<?php 
/**
* 
*/
class Register_control extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}
	function index()
	{
		$this->load->view('Tuto/register');
	}

	public function insert()
	{
		$name = $_POST['name'];
		$username = $_POST['username'];
		$data = array('name' => $name,
					'username' => $username);
		if (empty($name) === false && empty($username) === false) {
			$this -> db -> insert('Users', $data);	
		}
		else
		{
			echo "You must type name and username";
		}
		
	}

	

}


?>