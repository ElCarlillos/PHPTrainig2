<?php 

/**
* 
*/
class Ci_session extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('session');
		
	}

	public function index()
	{
			$this->load->view('Project/account');
			
		
	}
}
 ?>