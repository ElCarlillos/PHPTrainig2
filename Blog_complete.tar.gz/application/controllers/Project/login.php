<?php	

/**
* 
*/
class Login extends CI_Model
{
	
	public function login_user()
	{
		//Load form validation library

		//Set rules for form validation

		if ($this->form_validation->run() == FALSE)
		{
			//User didn't validate, reload login view
		}
		else
		{
			// initial check for empty fields ok, start checking db fields
			$result = $this->my_model->login_user();

			switch ($result) {
				case 'logged in':
					redirect('main_blog') //auth complete, redirect to registrated user view

					break;
				case 'incorrect_password'
					//On incorrect or incomplete fields cases, redirect to login view
				break;
				
			
		}
	}
}