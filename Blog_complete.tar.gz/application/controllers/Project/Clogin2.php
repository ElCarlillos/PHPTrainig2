<?php


class Clogin2 extends CI_Controller
{

	public function index()
	{
		log_message('debug', 'hola');		
		$this->load->model('Mlogin');

		$this->load->view('Project/Login2');

		
	}

	



	public function login_validation() 
	{
		$uname = $this->input->post('uname');
		$pass = $this->input->post('pass');


			
			
			$data = array(
				
				'username' 	=>	$uname, 	
				'password' 	=> 	$pass);
			$this->form_validation->set_data($data);
			$this->form_validation->set_rules('username', 'uname','required');
			$this->form_validation->set_rules('password', 'pass','required');




		if ($this->form_validation->run() === FALSE) 
		{ 						
			$this->load->view('Project/Login2');
			
			$this->form_validation->set_error_delimiters('<div class="alert alert-danger"
				style = "
				width:200px;
				position:absolute;
				margin-top:60px;
				margin-left:50px;
				"
				>', '</div>'); 

			echo form_error('username'); 
			
			
			$this->form_validation->set_error_delimiters('<div class="alert alert-danger"
				style = "
				width:200px;
				position:absolute;
				margin-left:50px;
				margin-top:150px;
				"
				>', '</div>'); 
			echo form_error('password');
			
		
			
		} else     
		{
			#Check for empty fields passed, check for matches with DB values
			
			$query = "SELECT * FROM  `Users` WHERE username =  '$uname'";
			$sql = $this->db->query($query);
			$result = $sql->result();
			

			
				
				if ($sql->num_rows() > 0) 
				{
					
					$query = "SELECT * FROM  `Users` WHERE password = '$pass'";
					$sql = $this->db->query($query);
					$result = $sql->result();
			

			
				
					if ($sql->num_rows() > 0) {
						
						echo "Exito";
					}
					else
					{

						$this->load->view('Project/Login view');
						echo '<div class="alert alert-danger" style="padding-bottom:10px;width:175px;width: 240px;position: absolute;top: 140px;left: 44px;height: 25px;}">
						<p style="position:absolute;top:-13px;left:45px;">Invalid password</p></div>';
					}		

				}
				else
				{

					$this->load->view('Project/Login view');
					echo '<div class="alert alert-danger" style="padding-bottom:10px;width:175px;width: 240px;position: absolute;top: 56px;left: 44px;height: 25px;}">
					<p style="position:absolute;top:-13px;left:45px;">Invalid username</p></div>';
				}
		}
	}


	
	
	public function login_user()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('pass');
		$sql = "select * from Users where username = '$username'";
		$result = $this->db->query($sql);	
		$row = $result->row();

		if ($result->num_rows === 1)
		{
			if($row->activated)
			{
				if ($row->password == $password)
				{
					$session_data = array(
						'user_id' => $row->user_id,
						'username' => $row->username,
						'name' => $row->name,
						'activated' => $row->activated
						);
					$this->set_session($session_data);
					return 'logger in';
				}
			}else{
				return 'not activated';
			}
		}else{
			return 'email not found';
		}

	}

	

	

	
}
 ?>