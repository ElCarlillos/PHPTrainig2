<?php 
/**
* 
*/
class Admin_control extends CI_Controller
{
	public function manageLogin()
	{
		$this->load->view('Project/Admin views/Main.php');
	}

	function index()
	{
		$this->load->view('Project/Admin views/Main.php');
	}
	
}
 ?>