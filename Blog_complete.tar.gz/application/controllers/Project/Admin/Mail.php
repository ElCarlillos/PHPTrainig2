<?php 
$config['protocol'] = 'smtp';
$config['smtp_host'] = ssl://smtp.googlemail.com
$config['smtp_port'] = 465;
$config['smtp_user'] = $sender_email; //Email user 
$config['smtp_pass'] = $user_password;
$this->load->library('email', $config);


Hotmail settings

$config['smtp_host'] = smpt.live.com

Yahoo!
$config['smtp_host'] = smpt.mail.yaho.com

Google Gmail 
$config['smtp_host'] = smtp.gmail.com

Lycos Mail
$config['smtp_host'] = smtp.mail.lycos.com

AOL Mail

$config['smtp_host']=smtp.mail.lycos.com

Netscape
$config['smtp_host']=smtp.isp.netscape.com

//Configuring email library

