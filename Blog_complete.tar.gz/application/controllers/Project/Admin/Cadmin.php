	<?php 

/**
* 
*/
class Cadmin extends CI_Controller
{
	
	public function index()
	{
		$this->load->library('session');
		$username = $this->input->post('username');
		$this->session->set_userdata('username', $username);
		
		$data['username'] = $username;		
		$this->session->flashdata('username', $username);
		$this->load->view('Project/Admin views/member_view.php');


	}

	public function equis()
	{
		$this->load->view('Project/Admin views/Prompt.php');
	}
}