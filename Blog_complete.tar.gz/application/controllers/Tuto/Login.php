<?php 
/**
* 
*/
class Login extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function index()
  {
    $this->load->view('view1');
  }

	public function login()
    {

            
            $this->load->library('form_validation');            
            $u = $this->input->post('username');
            $p = $this->input->post('password');
            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
            

            if ($this->form_validation->run() === FALSE) {                
              echo "Username and password are mandatory";
            }                                                                        
            else
            {                
                
                $this->load->model('Tuto/User_model1');
                if($this->User_model1->login($this->input->post('username'),  $this->input->post('password')  )  )
                   {
                        #$this->session->set_userdata('username');
                        $this->load->view('main_blog');    
                        echo "Success";                  
                   } 
                   elseif(  $this->User_model1->login(  $this->input->post('username'), $this->input->post('password')) === FALSE)
                   {
                        
                        
                        echo "Wrong username/password combination";

                   }

                   else
                   {
                      echo "Total error";
                   }
                

            }    
        
    }
}
 ?>